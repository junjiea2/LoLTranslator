# Localized Rendering 数据模型

## 为什么单独建模

OCR locale 只负责读取像素，Expression locale 只负责理解玩家原话，目标 locale 才负责向用户显示什么语言。三者不能绑定。

`Concept.definition` 是旧模型中的单一说明文字，没有 locale，也不适合作为实时短译文。`rendering` 记录把稳定 Concept 映射为经审核的目标语言输出，同时不复制或改写 Expression 匹配规则。

## JSONL 结构

```json
{
  "record_type": "rendering",
  "rendering_id": "rendering.game.lol.lane-caution.zh-cn.001",
  "concept_id": "game.lol:lane.caution",
  "target_locale": "zh-CN",
  "short_text": "小心",
  "explanation": "提醒队友某条线、区域或方向可能存在威胁，应谨慎行动。",
  "slot_template": "{subject}小心",
  "evidence_ids": ["evidence.rendering.game.lol.lane-caution.zh-cn.001"],
  "status": "pending"
}
```

字段作用：

- `short_text`：缺少 slots 或界面空间有限时使用。
- `explanation`：供详细结果、调试或辅助理解使用。
- `slot_template`：仅当所有占位 slot 都有值时使用；否则回退到 `short_text`。
- `target_locale`：输出语言，与 OCR/Expression locale 无关。
- `evidence_ids`、`status`：沿用数据治理与发布门。

## 回退规则

只使用 verified rendering 时，解析顺序为：

1. 完全相同的目标 locale；
2. 相同语言族，例如 `en-GB` 回退到 `en-US`；
3. 已发布的 `en-US`；
4. 没有可用 rendering 时，回退到旧的 `Concept.definition`，并标记为 fallback。

Entity slot 优先使用目标 locale 的 `canonical_names`，其次使用相同语言族、`en-US`，最后使用 OCR 匹配文本。

## 发布规则

- 同一 `concept_id + target_locale` 在组合图中只能有一条 rendering。
- `slot_template` 的占位符必须在 Concept 的 `slot_schema` 中声明。
- 正式 rendering 必须是 verified，拥有 Evidence，且 Evidence 的最新 Review 必须 approved。
- pending rendering 只能在候选测试中通过 `includeDraft: true` 使用。
