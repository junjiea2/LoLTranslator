# SlangGraph 数据架构 v0.2

## 项目重新定位

数据方向的核心产品不是 LoL 翻译词典，而是一个可验证的跨社区黑话语义图谱：

```text
真实表达 / 黑话 / 缩写
  -> 语言与社区上下文
  -> 语义概念与参数
  -> 概念间关系
  -> 其他语言、行业或社区中的对应表达
```

LoL 是第一个领域包 `game.lol`，用于验证高噪声、强上下文、短文本和跨语言场景。OCR 只是 Observation 的一种采集通道，不属于核心模型。

## 保留的正确设计

- 多语言 Expression 共同指向 Concept，不建立语言两两翻译表。
- Pattern 表达带参数的说法，避免穷举所有句子。
- Entity 保存人物、能力、物品、位置或行业对象。
- Relation 连接同义、反义、上下位和常见组合关系。
- Observation、Evidence、Review 和质量门阻止未经验证的数据进入正式结果。

## v0.1 的主要限制

1. 数据代码位于 WPF 项目，命名和运行时都绑定 LoL。
2. 没有 Domain 和 Pack，无法区分游戏、金融、程序员、饭圈等社区。
3. Concept slots 只是字符串，无法声明实体引用、数字、时间、枚举或是否必填。
4. `LaneRegex`、小龙和秒数等规则写死在 matcher，新增领域需要改代码。
5. Source 只表示“来自哪里”，没有独立 Evidence 说明“哪条记录被什么证据支持”。
6. 原始样本模型偏向 OCR，不能自然接纳论坛、字幕、人工访谈或其他文本通道。

## v0.2 核心记录

| 记录 | 职责 |
| --- | --- |
| `pack` | 声明可独立发布和版本化的数据包 |
| `domain` | 定义领域或社区范围，并支持父领域 |
| `concept` | 语言无关语义及有类型的 slot schema |
| `expression` | 某语言、社区、渠道和语体中的实际说法 |
| `pattern` | 带 slots 的结构化表达模式 |
| `entity` | 可被 slots 引用的领域对象和本地化别名 |
| `relation` | 任意节点之间的图关系 |
| `source` | 数据来源和采集政策 |
| `evidence` | 某条记录与来源之间的可审核证据 |
| `observation` | 原始文本、场景、脱敏状态和人工标签 |

## 跨领域连接方式

领域概念不应被强行合并。例如 LoL 的“没闪”和另一游戏的“位移冷却”可以各自保留精确概念，再共同通过 `specialization_of` 指向：

`core.communication:capability.unavailable`

这种结构既保留领域差异，又允许跨领域检索和翻译。

## 兼容策略

- `data/lol-slang-v0.1.jsonl` 暂时冻结为 LoL 兼容数据集。
- 新核心位于 `src/SlangGraph.Core`，不引用 WPF、OCR 或 LoLTranslator.App。
- `data/packs/core/communication.v0.2.jsonl` 提供跨领域核心概念。
- `data/packs/lol/slang-graph.v0.2.example.jsonl` 通过 dependency 引用 core pack，不复制核心节点。
- legacy migrator 当前生成自包含兼容包，便于独立迁移验证；正式领域包使用 dependency。
- 迁移必须由确定性转换器完成，并同时运行 v0.1 与 v0.2 回归，不能人工复制后静默替换。
