# 高精度 OCR：GPU 前置安装与验证

状态：准备完成，尚未安装、尚未启用。此步骤只为本机原生 PP-OCRv5
sidecar 准备 GPU 编译环境；不会修改任何数据 Pack，也不会上传截图。

## 锁定版本

| 组件 | 锁定版本 | 原因 |
| --- | --- | --- |
| CUDA Toolkit | 12.6.0，Windows x86_64 | PaddlePaddle 3.2.2 官方 Windows GPU 安装页提供 CUDA 12.6 通道；现有 RTX 3070 Ti 驱动 595.79 满足此代 Toolkit 的驱动要求。 |
| cuDNN | 9.5.1.17，CUDA 12，Windows x86_64 ZIP | 与现有本机 Paddle GPU benchmark 的 cuDNN 9.5 基线一致，避免把生产 native build 升到未经验证的新版。 |
| Paddle source | 3.2.2 | 已锁定、已完成 CPU `inference_lib_dist` 的同一源码。 |

官方安装源：

- CUDA 12.6 Windows x86_64 local installer：[NVIDIA CUDA 12.6 archive](https://developer.nvidia.com/cuda-12-6-0-download-archive?target_os=Win)
- cuDNN 9.5.1 CUDA 12 Windows ZIP：[NVIDIA cuDNN 9.5.1 archive](https://developer.nvidia.com/cudnn-9-5-1-download-archive)
- CUDA 12.6 Windows 安装/静默模式说明：[NVIDIA installation guide](https://docs.nvidia.com/cuda/archive/12.6.0/cuda-installation-guide-microsoft-windows/index.html)

下载预算：CUDA local installer 约 3–4 GB；cuDNN ZIP 为 532 MB。安装、解压和
GPU Paddle build 请预留至少 45 GB 空闲空间。CUDA Toolkit 安装在默认路径时约为
`C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.6`。

## 最小用户操作

1. 从 CUDA archive 选择 Windows / x86_64 / Windows 10 或 11 / `exe (local)`，下载 CUDA 12.6.0。
2. 安装时保留 Toolkit，**不要安装或降级 Display Driver**（当前 595.79 驱动已验证正常）。
3. 下载 cuDNN 9.5.1.17 CUDA 12 ZIP，解压至一个稳定目录，例如 `C:\Tools\cuDNN\9.5.1-cuda12`；目录内必须直接有 `bin`、`include`、`lib\x64`。
4. 新开 PowerShell，设置当前用户环境变量：

```powershell
[Environment]::SetEnvironmentVariable('CUDNN_ROOT', 'C:\Tools\cuDNN\9.5.1-cuda12', 'User')
```

5. 关闭并重新打开终端后执行下方验证命令。无需安装 Python，也无需启动 Ollama。

静默自动化方案（仅在已下载 CUDA local installer 后使用；不含显卡驱动）：

```powershell
Start-Process -Wait -FilePath .\cuda_12.6.0_560.76_windows.exe -ArgumentList '-s'
```

该命令是 NVIDIA documented silent mode。若组织策略要求精确子组件，请先用该 installer
的 extraction/manifest 确认本机包名，再传入组件列表；不要猜测包名或包含
`Display.Driver`。

## 安装后验证

```powershell
nvcc --version
$env:CUDA_PATH
Test-Path "$env:CUDA_PATH\bin\nvcc.exe"
Test-Path "$env:CUDNN_ROOT\include\cudnn.h"
Test-Path "$env:CUDNN_ROOT\lib\x64\cudnn.lib"
Test-Path "$env:CUDNN_ROOT\bin\cudnn64_9.dll"
nvidia-smi
```

期望：`nvcc` 显示 12.6，四个 `Test-Path` 都为 `True`，且 `nvidia-smi` 继续显示 RTX
3070 Ti。若其中任一项失败，不运行 build。

## CUDA 到位后由 Runtime 执行

```powershell
cmd /d /c .\tools\ppocr-windows-sidecar\build-paddle-gpu.cmd
cmd /d /c .\tools\ppocr-windows-sidecar\build-sidecar-gpu.cmd
powershell -ExecutionPolicy Bypass -File .\tools\ppocr-windows-sidecar\run-gpu-six-line-gate.ps1 -ScreenshotPath C:\absolute\path\to\approved-screenshot.png
```

门只在连续五轮均为 6/6、CER 0、`OCR test` exact、零重复行且 warm latency <= 1 秒时
通过。门未通过时，高精度 provider 保持默认关闭、fail-closed，不回退到 Windows OCR。
