# LoL Slang Dataset v0.1 数据模型

> 状态：Legacy compatibility。新通用模型见 `slang-graph-architecture.md`。本文件和 v0.1 JSONL 暂时冻结，只用于兼容与迁移回归。

这一层只负责把“玩家实际说法”整理成稳定的、与语言无关的语义数据。OCR、向量检索和翻译生成分别位于数据层之外。

## 核心关系

```text
OCR 文本
  -> Expression / Template 候选
  -> Concept（语言无关语义）
  -> slots（位置、目标、秒数等参数）
  -> 目标语言 Template
```

图结构和 HNSW 的职责不同：

- `Concept` 定义“是什么意思”。
- `Expression` 保存各语言、各地区的实际说法。
- `Template` 保存带参数的局内短句模式。
- `Entity` 保存英雄、装备、技能、位置和地图资源等官方对象。
- `Relation` 连接概念或实体，例如 `opposite_of`、`often_combined_with`。
- `Example` 保存正例和容易误判的反例。
- `DataSource` 保存来源、版本、场景和人工核验状态。

## JSONL 约定

`data/lol-slang-v0.1.jsonl` 使用一行一个 JSON 对象，所有记录都有 `record_type`：

文件第一行是 `dataset` 头记录，用于声明 `schema_version`、`dataset_id` 和 `dataset_version`。

| record_type | 主键 | 关键引用 |
| --- | --- | --- |
| `concept` | `concept_id` | 无 |
| `expression` | `expression_id` | `concept_id`, `source_ids` |
| `template` | `template_id` | `concept_id`, `source_ids` |
| `entity` | `entity_id` | `source_ids` |
| `relation` | `relation_id` | `from_id`, `to_id` |
| `example` | `example_id` | `concept_id`, `source_ids` |
| `source` | `source_id` | 无 |

### 记录规则

1. `concept_id`、`expression_id` 等 ID 稳定后不要复用；修订内容只提高数据集版本。
2. 所有表达都必须标注 `locale`、`region`、`register` 和 `status`。
3. `confidence` 是当前数据对该表达的信心，不是模型运行时的最终置信度。
4. 网络资料只能作为候选来源；`human_verified: false` 的记录不能直接作为最终翻译依据。
5. 负例必须写清 `reason`，避免把“我没看到他交闪”误判为“闪现不可用”。
6. 带位置、英雄或秒数的句子优先进入 `template`，不要复制成大量固定短语。
7. 第一版允许使用 `manual_seed`，但必须保持 `status: draft`，等真实局内样本确认后再改为 `verified`。

## 当前种子数据范围

当前文件先放入 15 个高频概念，以及 2 个用于闭合关系图的辅助概念；同时加入少量中/英/韩候选表达。目的是验证引用关系和字段形状，不宣称这些候选已经完成语言学或玩家群体核验。下一步应使用真实局内样本逐条补充来源和人工标注。

## 程序入口

- `LolSlangDatasetLoader.LoadFromJsonl(path)`：读取 JSONL，并在返回前执行引用校验。
- `LolSlangCatalog.FindConcept(id)`：查找语言无关概念。
- `LolSlangCatalog.FindExpressions(conceptId, locale)`：查找某概念在指定语言的表达。
- `LolSlangCatalog.FindTemplates(conceptId, locale)`：查找带参数模板。

加载器只属于数据层，不调用 OCR，不发起网络请求，也不负责把概念生成成目标语言句子。
