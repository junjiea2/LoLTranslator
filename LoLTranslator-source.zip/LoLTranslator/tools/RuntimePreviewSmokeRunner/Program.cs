using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LoLTranslator.App;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length < 1 || !Path.IsPathFullyQualified(args[0])) return 2;
        string reportDirectory = args[0]; Directory.CreateDirectory(reportDirectory);
        var checks = new Dictionary<string, bool>();
        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        // Construct the actual application XAML without showing it or triggering
        // Loaded, so saved-region capture/feedback upload never runs in this test.
        var main = new MainWindow();
        checks["main_window_initializes_with_build_marker"] = main.Title.Contains(RuntimeBuildInfo.Label);
        main.Close();
        var view = new TranslationSidecarWindow();
        var receipts = new List<RuntimeViewReceipt>(); view.ViewReceipt += receipts.Add;
        try
        {
            var items = (ItemsControl)view.FindName("TranslationItems");
            SafeRuntimeDisplayMessage Message(int n) => new("synthetic:" + n, n, new(new[]
            {
                new TranslationSidecarSegment($"04:{n:D2} ", TranslationSidecarTextRole.Muted),
                new TranslationSidecarSegment("艾希", TranslationSidecarTextRole.AlliedIdentity),
                new TranslationSidecarSegment(" 标记了 ", TranslationSidecarTextRole.System),
                new TranslationSidecarSegment("艾瑞莉娅", TranslationSidecarTextRole.EnemyIdentity)
            }));
            // No desktop window, game capture or model is needed for layout replay.
            view.Present(Message(1));
            checks["single_submission_immediate_items"] = items.Items.Count == 1;
            checks["hidden_submission_not_render_ack"] = receipts.Count == 0;
            var text = (TextBlock)items.Items[0];
            var runs = text.Inlines.Cast<Run>().ToArray();
            checks["independent_blue_red_gold_runs"] = runs[1].Foreground is SolidColorBrush blue && blue.Color.B > blue.Color.R &&
                runs[3].Foreground is SolidColorBrush red && red.Color.R > red.Color.B &&
                runs[2].Foreground is SolidColorBrush gold && gold.Color.R > gold.Color.B;
            view.ResetSession(); receipts.Clear();
            view.Present(Message(3)); view.Present(Message(1)); view.Present(Message(2));
            checks["late_completion_inserted_in_sequence_not_appended"] = items.Items.Cast<TextBlock>()
                .Select(block => block.Inlines.Cast<Run>().First().Text).SequenceEqual(new[] { "04:01 ", "04:02 ", "04:03 " });
            checks["same_event_delivery_idempotent"] = view.Present(Message(2)).DuplicateSuppressed == 1 && items.Items.Count == 3;
            view.ResetSession(); receipts.Clear();
            foreach (int n in Enumerable.Range(1, 16)) view.Present(Message(n));
            checks["burst_keeps_latest_eight"] = items.Items.Count == 8 &&
                ((TextBlock)items.Items[0]).Inlines.Cast<Run>().First().Text.StartsWith("04:09");
            checks["burst_eight_evicted_before_draw"] = receipts.Count(r => r.Status == "capacity_evicted_before_render_opportunity") == 8;
            checks["old_completion_does_not_displace_latest_visible_rows"] = view.Present(Message(1)).DisplayedNow == 0 &&
                items.Items.Count == 8 && ((TextBlock)items.Items[0]).Inlines.Cast<Run>().First().Text.StartsWith("04:09");
            var root = (FrameworkElement)view.Content;
            root.Measure(new Size(330, 250)); root.Arrange(new Rect(0, 0, 330, 250)); root.UpdateLayout();
            var bitmap = new RenderTargetBitmap(330, 250, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(root);
            Save(bitmap, Path.Combine(reportDirectory, "offscreen-sidecar.png"));
            checks["offscreen_layout_drawn"] = ((TextBlock)items.Items[0]).ActualHeight > 0;
            view.ResetSession();
            checks["reset_clears_view"] = items.Items.Count == 0;
            view.Present(Message(17));
            checks["new_session_can_submit"] = items.Items.Count == 1;
        }
        finally { view.Close(); app.Shutdown(); }

        string? nativeStatus = null; long? nativeProbeMs = null; int? nativeRows = null; long? warmOcrMs = null;
        bool? rawBodyExact = null;
        if (args.Contains("--native"))
        {
            // This is a synthetic clean UI fixture, NOT real-game OCR ground truth.
            string fixturePath = Path.Combine(reportDirectory, "synthetic-chat.png");
            var visual = new DrawingVisual();
            using (DrawingContext dc = visual.RenderOpen())
            {
                dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(18, 26, 34)), null, new Rect(0, 0, 850, 150));
                string[] rows = { "04:42 [Team] Fixture (Ashe): hello everyone", "04:43 Fixture (Ashe) is on the way", "04:44 Fixture (Ashe) signals that enemies are missing" };
                for (int n = 0; n < rows.Length; n++)
                    dc.DrawText(new FormattedText(rows[n], System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                        new Typeface("Segoe UI"), 20, Brushes.White, 1), new Point(12, 12 + n * 40));
            }
            var fixture = new RenderTargetBitmap(850, 150, 96, 96, PixelFormats.Pbgra32); fixture.Render(visual); Save(fixture, fixturePath);
            using var provider = new NativePpOcrV5SidecarProvider();
            var timer = System.Diagnostics.Stopwatch.StartNew();
            var capability = provider.ProbeAsync(default).GetAwaiter().GetResult();
            nativeProbeMs = timer.ElapsedMilliseconds; nativeStatus = capability.State;
            checks["local_native_component_ready"] = capability.Ready;
            if (capability.Ready)
            {
                try
                {
                    bool Exact(IReadOnlyList<StructuredOcrLine> rows) => new[] { "hello everyone", "is on the way", "enemies are missing" }
                        .All(body => rows.Any(row => row.Text.Contains(body, StringComparison.OrdinalIgnoreCase)));
                    rawBodyExact = Exact(provider.RecognizeLinesAsync(fixturePath, "auto", 1, default).GetAwaiter().GetResult());
                    // Exercise the same preprocessing as continuous MainWindow,
                    // preserving the raw baseline separately (not a tuning sweep).
                    string processed = OcrChatPreprocessor.CreateLolChatHighContrastCandidate(fixturePath);
                    try
                    {
                        _ = provider.RecognizeLinesAsync(processed, "auto", 2, default).GetAwaiter().GetResult();
                        timer.Restart();
                        var recognized = provider.RecognizeLinesAsync(processed, "auto", 3, default).GetAwaiter().GetResult();
                        warmOcrMs = timer.ElapsedMilliseconds; nativeRows = recognized.Count;
                        checks["native_synthetic_chat_bodies"] = Exact(recognized);
                        if (!checks["native_synthetic_chat_bodies"])
                            foreach (var row in recognized) Console.WriteLine("SYNTHETIC OCR: " + row.Text);
                    }
                    finally { ScreenCaptureService.DeleteTransient(processed); }
                }
                catch (Exception exception) { nativeStatus = exception.GetType().Name; checks["native_synthetic_chat_bodies"] = false; }
            }
        }
        string? modelStatus = null, modelOutput = null; long? modelMs = null;
        var conversationResults = new List<object>();
        if (args.Contains("--model"))
        {
            var ready = Task.Run(() => LocalModelManager.EnsureQwen3Async()).GetAwaiter().GetResult();
            modelStatus = ready.State; checks["local_ollama_auto_start_and_digest"] = ready.Ready;
            if (ready.Ready)
            {
                var semantics = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
                var row = new OcrShadowLineResult(1, "04:42 [Team] Fixture (Ashe): hello everyone", [], [],
                    new("fused", 1, []));
                var events = new RuntimeChatEventLedger().Observe(new[] { row }).Inserted;
                var timer = System.Diagnostics.Stopwatch.StartNew();
                var result = Task.Run(() => IncrementalGeneralChatShadowService.CreateExplicit(semantics)
                    .ProcessEvents(events, new("test", "lol.global", "in_game_chat"), "zh-CN")).GetAwaiter().GetResult();
                modelMs = timer.ElapsedMilliseconds; modelOutput = result.Lines.Single().FinalOutput;
                checks["real_model_synthetic_chat_safe_output"] = result.Lines.Single().SafeDisplay is not null &&
                    modelOutput is not null && modelOutput.Any(c => c >= 0x4e00 && c <= 0x9fff) && !modelOutput.Contains("Fixture");
                var service = IncrementalGeneralChatShadowService.CreateExplicit(semantics);
                foreach (var sample in new[]
                {
                    (Body: "wp boys", Actor: "Aliscar"), (Body: "sry", Actor: "Zer1"),
                    (Body: "ty for help", Actor: "Ashe"), (Body: "brb", Actor: "Ashe")
                })
                {
                    var samples = new RuntimeChatEventLedger().Observe(new[] { row with
                        { Text = $"13:06 [Team] Fixture ({sample.Actor}): {sample.Body}" } }).Inserted;
                    timer.Restart();
                    var translated = Task.Run(() => service.ProcessEvents(samples, new("test", "lol.global", "in_game_chat"), "zh-CN"))
                        .GetAwaiter().GetResult().Lines.Single();
                    long elapsed = timer.ElapsedMilliseconds;
                    checks["runtime_conversation_" + sample.Body.Replace(' ', '_')] = translated.SafeDisplay is not null &&
                        translated.FinalOutput?.Any(c => c >= 0x4e00 && c <= 0x9fff) == true;
                    if (sample.Body == "wp boys") checks["praise_meaning_not_jungle"] = translated.FinalOutput == "打得好，兄弟们";
                    if (sample.Body == "sry") checks["apology_meaning"] = translated.FinalOutput == "抱歉";
                    conversationResults.Add(new { input = sample.Body, output = translated.FinalOutput, elapsed_ms = elapsed,
                        failure = translated.FailureReason, route = translated.Route, model_called = translated.ModelCalled, kind = "synthetic_text_not_ocr" });
                }
            }
        }
        File.WriteAllText(Path.Combine(reportDirectory, "smoke-report.json"), JsonSerializer.Serialize(new
        {
            build_id = RuntimeBuildInfo.Id, origin = "synthetic_fixture_not_game_replay", checks,
            native_status = nativeStatus, native_probe_ms = nativeProbeMs, native_rows = nativeRows, warm_ocr_ms = warmOcrMs,
            raw_input_body_exact = rawBodyExact, preprocessing = "production_lol_color_contrast_2x",
            model_status = modelStatus, model_elapsed_ms = modelMs, synthetic_model_output = modelOutput,
            conversation_results = conversationResults,
            game_recall = (double?)null, actual_screen_visible = (bool?)null
        }, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine($"Preview smoke checks: {checks.Count(pair => pair.Value)}/{checks.Count}");
        foreach (var check in checks.Where(pair => !pair.Value)) Console.WriteLine("FAIL " + check.Key);
        return checks.All(pair => pair.Value) ? 0 : 1;
    }

    private static void Save(BitmapSource bitmap, string path)
    {
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var stream = File.Create(path); encoder.Save(stream);
    }
}
