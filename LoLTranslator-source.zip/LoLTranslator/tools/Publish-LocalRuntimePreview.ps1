param([string]$Name = 'runtime-p2h-local-preview-20260904')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if ($Name -notmatch '^runtime-[a-z0-9-]+$') { throw 'Use a single runtime-* directory name.' }
$outputRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot 'outputs'))
$destination = [IO.Path]::GetFullPath((Join-Path $outputRoot $Name))
if (!( $destination.StartsWith($outputRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase))) { throw 'Output escaped workspace.' }
if (Test-Path -LiteralPath $destination) { throw 'Preview already exists. Choose a new name; never overwrite an earlier build.' }

# Local-machine preview only. No models, raw captures or local diagnostics are copied.
& dotnet run --project (Join-Path $projectRoot 'tests/LoLTranslator.DataChecks') -c Release
if ($LASTEXITCODE -ne 0) { throw 'Regression checks failed.' }
& dotnet publish (Join-Path $projectRoot 'src/LoLTranslator.App/LoLTranslator.App.csproj') -c Release -r win-x64 --self-contained false -o $destination
if ($LASTEXITCODE -ne 0) { throw 'Publish failed; directory is incomplete and must not be used.' }
Copy-Item -LiteralPath (Join-Path $projectRoot 'docs/runtime-milestones/2026-09-04-p2h-local-preview-test-guide.md') -Destination (Join-Path $destination 'TEST-GUIDE.md')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'runtime-preview-start.cmd') -Destination (Join-Path $destination 'START.cmd')

$semantic = Get-FileHash -LiteralPath (Join-Path $destination 'data/packs/lol/slang-graph.v0.3.0.jsonl')
$rendering = Get-FileHash -LiteralPath (Join-Path $destination 'data/packs/localization/lol-renderings.v0.1.0.jsonl')
if ($semantic.Hash -ne '6C8FB1F090956F0F26A92836D3E8C160E02E992A389AC74CA2263CAAE8424FAB' -or
    $rendering.Hash -ne '54E9826497A84D19D2B5054B42C9D0AF7A348558FD40325495856B52C39DC755') { throw 'Frozen pack hash mismatch.' }
$files = Get-ChildItem -LiteralPath $destination -Recurse -File | ForEach-Object {
    # Compatible with Windows PowerShell 5.1 (.NET Framework has no GetRelativePath).
    [ordered]@{ path = $_.FullName.Substring($destination.Length + 1); bytes = $_.Length; sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash }
}
$manifest = [ordered]@{
    build_id = '2026.09.04-p2h'; built_at_utc = [DateTimeOffset]::UtcNow.ToString('o')
    purpose = 'local_internal_test_not_public_distribution'; self_contained = $false
    dependencies = @('.NET 10 Windows Desktop x64', 'existing repository native PP-OCR GPU sidecar and local models', 'installed Ollama and approved qwen3:8b')
    privacy = 'No user screenshots, OCR diagnostic logs or model cache included.'
    files = @($files)
}
[IO.File]::WriteAllText((Join-Path $destination 'build-manifest.json'), ($manifest | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
Write-Output "READY: $destination"
