using System.Text.Json;
using System.Windows;
using LoLTranslator.App;
using SlangGraph.Core;

const string RcRelative = "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.2.jsonl";
const string NormalizationArtifactRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-normalization-candidate.jsonl";
const string NormalizationReviewRelative = "data/collection/lol/real-screenshot-shadow-001/run005-review-normalization.jsonl";
const string OutputRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-shadow/incremental-general-chat-shadow-fixture-v0.1.json";

string root = Directory.GetCurrentDirectory();
string Resolve(string relative) => Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar));
string rcPath = Resolve(RcRelative);
DomainLexicon lexicon = DomainLexiconLoader.LoadJsonl(rcPath);
DomainLexiconEntry hero = lexicon.Entries.OrderBy(entry => entry.CanonicalId, StringComparer.Ordinal).First();
string heroEnglish = hero.Aliases.Single(alias => alias.Locale == "en-US").Surface;
string heroChinese = hero.Aliases.Single(alias => alias.Locale == "zh-CN").Surface;

OcrShadowSemanticService semantic = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
ShadowMatchContextOption context = new("fixture", "lol.global", "in_game_chat", new[] { "lol.global" });
var provider = new RecordingProvider();
IncrementalGeneralChatShadowService service = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, provider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32);

OcrShadowLineResult[] initial =
[
    FusedLine(1, "00:01 [Team] (FixturePlayer): hold the wave", "en-US"),
    FusedLine(2, $"00:02 [Team] (FixturePlayer): {heroEnglish.ToLowerInvariant()} go top", "zh-CN"),
    FusedLine(3, "00:03 [Team] (FixturePlayer): top care", "en-US"),
    FusedLine(4, $"00:04 [Team] (FixturePlayer): {heroChinese} is here", "zh-CN")
];
IncrementalGeneralChatShadowResult first = service.Process(initial, context, "zh-CN");
IncrementalGeneralChatShadowResult exactRepeat = service.Process(initial, context, "zh-CN");
IncrementalGeneralChatShadowResult newLine = service.Process(
    new[] { FusedLine(5, "00:05 [Team] (FixturePlayer): wait for me", "en-US") }, context, "zh-CN");
IncrementalGeneralChatShadowResult rollingWindow = service.Process(
    new[]
    {
        FusedLine(20, $"00:02 [Team] (DifferentOcrName): {heroEnglish.ToLowerInvariant()} go top", "zh-CN"),
        FusedLine(21, "00:06 [Team] (FixturePlayer): group now", "en-US")
    }, context, "zh-CN");
IncrementalGeneralChatShadowResult ambiguous = service.Process(
    new[] { AmbiguousLine(30, "same timestamp conflicting transcription") }, context, "zh-CN");
IncrementalGeneralChatShadowResult unreliableFusion = service.Process(
    new[] { UnreliableLine(30, "non-fused OCR candidate") }, context, "zh-CN");
IncrementalGeneralChatShadowResult weakEnvelope = service.Process(
    new[] { FusedLine(31, ": 29 [Team] (FixturePlayer) body without final separator", "en-US") }, context, "zh-CN");
IncrementalGeneralChatShadowResult systemNotification = service.Process(
    new[] { FusedLine(32, "玩家已选择路线：上路", "zh-CN") }, context, "zh-CN");

var offlineProvider = new OfflineProvider();
IncrementalGeneralChatShadowResult offline = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, offlineProvider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32)
    .Process(new[] { FusedLine(40, "plain fresh body", "en-US") }, context, "zh-CN");
var prefixProvider = new PrefixProvider();
IncrementalGeneralChatShadowResult prefixInjection = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, prefixProvider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32)
    .Process(new[] { FusedLine(41, "plain fresh body", "en-US") }, context, "zh-CN");

var lifecycleProvider = new RecordingProvider();
IncrementalGeneralChatShadowService lifecycleService = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, lifecycleProvider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32);
IncrementalGeneralChatShadowResult lifecycleFirst = lifecycleService.Process(
    new[] { FusedLine(50, "keep current region", "en-US") }, context, "zh-CN");
int cachedBeforeCancelledRegionChange = lifecycleService.CachedBodyCount;
bool cancellationKeepsSession = IncrementalGeneralChatSessionResetPolicy.RequiresRegionReplacementConfirmation(cachedBeforeCancelledRegionChange) &&
    !IncrementalGeneralChatSessionResetPolicy.ShouldApplyRegionReplacement(cachedBeforeCancelledRegionChange, false) &&
    lifecycleService.CachedBodyCount == cachedBeforeCancelledRegionChange;
bool confirmedRegionChangeCanReset = IncrementalGeneralChatSessionResetPolicy.ShouldApplyRegionReplacement(cachedBeforeCancelledRegionChange, true);
if (confirmedRegionChangeCanReset) lifecycleService.ResetSession();
bool explicitResetClearsSession = lifecycleService.CachedBodyCount == 0;
IncrementalGeneralChatShadowResult lifecycleAfterReset = lifecycleService.Process(
    new[] { FusedLine(51, "keep current region", "en-US") }, context, "zh-CN");

IReadOnlyList<OcrShadowLineResult> screenshotLikeFusion = semantic.MatchCandidates(
[
    new OcrRecognitionResult("[队伍] 玩家（布郎姆）: Hi OCR test\n[队伍] 玩家（布郎姆）: I am braum and I am top\n[队伍] 玩家（布郎姆）: waiting for test\n[队伍] 玩家（布郎姆）: where is my translation?", "zh-CN"),
    new OcrRecognitionResult("[队伍] 玩家（布郎姆）: Hi OCR test\n[队伍] 玩家（布郎姆）: I am Braum and I am top\n[队伍] 玩家（布郎姆）: waiting for test\n[队伍] 玩家（布郎姆）: where is my translation?", "en-US")
], OcrShadowSemanticService.AutoSemanticLocale, context);
var screenshotProvider = new RecordingProvider();
IncrementalGeneralChatShadowResult screenshotLike = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, screenshotProvider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32)
    .Process(screenshotLikeFusion, context, "zh-CN");

DateTimeOffset retryNow = DateTimeOffset.Parse("2026-08-08T12:00:00Z");
var recoveryProvider = new RecoveringProvider();
IncrementalGeneralChatShadowService retryService = IncrementalGeneralChatShadowService.CreateExplicit(
    semantic, rcPath, recoveryProvider, Resolve(NormalizationArtifactRelative), Resolve(NormalizationReviewRelative), 32, () => retryNow);
OcrShadowLineResult retryLine = FusedLine(60, "[Team] (FixturePlayer): retry after provider returns", "en-US");
IncrementalGeneralChatShadowResult retryFirst = retryService.Process(new[] { retryLine }, context, "zh-CN");
IncrementalGeneralChatShadowResult retryCooldown = retryService.Process(new[] { retryLine }, context, "zh-CN");
retryNow = retryNow.AddSeconds(11); recoveryProvider.Available = true;
IncrementalGeneralChatShadowResult retryRecovered = retryService.Process(new[] { retryLine }, context, "zh-CN");
IncrementalGeneralChatShadowResult retryDeduplicated = retryService.Process(new[] { retryLine }, context, "zh-CN");

IncrementalGeneralChatShadowLine heroLine = first.Lines.Single(line => line.LineNumber == 2);
IncrementalGeneralChatShadowLine semanticLine = first.Lines.Single(line => line.LineNumber == 3);
bool initialPass = first.ModelCallCount == 4 && provider.CallCount == 6 &&
    first.Lines.Single(line => line.LineNumber == 1).Route == "general_translation" &&
    heroLine.Route == "hybrid" && heroLine.CanonicalIds.Contains(hero.CanonicalId) &&
    heroLine.VerifiedTypedEntityIds.Contains("game.lol:lane.top") &&
    heroLine.FinalOutput?.Contains(heroChinese, StringComparison.Ordinal) == true &&
    semanticLine.Route == "hybrid" && semanticLine.SemanticConceptIds.Count > 0 &&
    first.Lines.Single(line => line.LineNumber == 4).CanonicalIds.Contains(hero.CanonicalId);
bool dedupPass = exactRepeat.ModelCallCount == 0 && exactRepeat.DeduplicatedCount == 4 &&
    exactRepeat.Lines.All(line => line.Route == "deduplicated") &&
    newLine.ModelCallCount == 1 && rollingWindow.ModelCallCount == 1 &&
    rollingWindow.Lines.Single(line => line.LineNumber == 20).Route == "deduplicated" &&
    rollingWindow.Lines.Single(line => line.LineNumber == 21).Route == "general_translation";
bool safetyPass = ambiguous.ModelCallCount == 0 && ambiguous.Lines.Single().FailureReason == "fusion_ambiguous_no_provider_call" &&
    unreliableFusion.ModelCallCount == 0 && unreliableFusion.Lines.Single().FailureReason == "fusion_not_reliable_no_provider_call" &&
    weakEnvelope.ModelCallCount == 0 && weakEnvelope.Lines.Single().FailureReason == "unreliable_chat_envelope_requires_review" &&
    systemNotification.ModelCallCount == 0 && systemNotification.Lines.Single().FailureReason == "system_notification_no_provider_call" &&
    offline.ModelCallCount == 1 && offline.Lines.Single().FinalOutput is null && offline.Lines.Single().FailureReason == "local_provider_unavailable" &&
    prefixInjection.ModelCallCount == 1 && prefixInjection.Lines.Single().FinalOutput is null && prefixInjection.Lines.Single().FailureReason == "model_added_chat_envelope";
bool lifecyclePass = lifecycleFirst.ModelCallCount == 1 && cancellationKeepsSession &&
    confirmedRegionChangeCanReset && explicitResetClearsSession && lifecycleAfterReset.ModelCallCount == 1 &&
    lifecycleProvider.CallCount == 2;
bool screenshotLikePass = screenshotLikeFusion.Count == 4 && screenshotLikeFusion.All(line => !line.Fusion.IsAmbiguous) &&
    screenshotLike.Lines.Count == 4 && screenshotLike.DisplayedNewCount == 4 && screenshotLike.Lines.All(line => line.FinalOutput is not null);
bool retryPass = retryFirst.Lines.Single().DedupStatus == "fail_closed" && retryService.CachedBodyCount == 1 &&
    retryCooldown.Lines.Single().DedupStatus == "retry_cooldown" && retryRecovered.DisplayedNewCount == 1 &&
    retryDeduplicated.Lines.Single().Route == "deduplicated";
var coordinator = new ContinuousTranslationSessionCoordinator();
coordinator.Start();
bool nonOverlap = coordinator.TryBeginTick() && !coordinator.TryBeginTick();
coordinator.CompleteTick(first, false);
coordinator.Pause();
bool pausePass = coordinator.State == ContinuousTranslationState.Paused && !coordinator.TryBeginTick();
coordinator.Resume();
bool resumePass = coordinator.TryBeginTick();
coordinator.CompleteTick(null, true);
coordinator.Stop();
bool stopPass = coordinator.State == ContinuousTranslationState.Stopped && !coordinator.TryBeginTick();
Rect workArea = new(0, 0, 1920, 1080);
Rect rightPosition = TranslationSidecarPositioner.Calculate(new Rect(100, 100, 500, 220), workArea, 330, 300);
Rect leftPosition = TranslationSidecarPositioner.Calculate(new Rect(1700, 100, 180, 220), workArea, 330, 300);
var savedRegion = new PersistedTranslationRegion(100, 100, 500, 220, 0, 0, 1920, 1080, 1920, 1080, 1.0);
bool positioningPass = rightPosition.Left > 600 && leftPosition.Left < 1700;
bool persistencePass = ContinuousTranslationRegionStore.IsCompatible(savedRegion, workArea, 1920, 1080, 1.0) &&
    !ContinuousTranslationRegionStore.IsCompatible(savedRegion, workArea, 1600, 900, 1.0) &&
    !ContinuousTranslationRegionStore.IsCompatible(savedRegion, workArea, 1920, 1080, 1.5);
bool continuousFrameworkPass = nonOverlap && pausePass && resumePass && stopPass && positioningPass && persistencePass;
var changeGate = new ContinuousChatChangeGate();
OcrShadowLineResult stableChat = new(70, "[Team] (VeryWrongName): body is correct", Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "en-US", 1, "[Team] (VeryWrongName): body is correct", null), new OcrShadowLineSource(1, "zh-CN", 1, "[Team] (BadName): body is correct", null) },
    new OcrFusionMetadata("fused", .92, Array.Empty<string>()));
ContinuousChatGateDecision gateFirst = changeGate.Observe(new[] { stableChat });
ContinuousChatGateDecision gateSame = changeGate.Observe(new[] { stableChat });
OcrShadowLineResult newStableChat = stableChat with { LineNumber = 71, Text = "[Team] (Unreadable): second body", Sources = stableChat.Sources.Select(source => source with { Text = "[Team] (Unreadable): second body" }).ToArray() };
ContinuousChatGateDecision gateNew = changeGate.Observe(new[] { stableChat, newStableChat });
var weakGate = new ContinuousChatChangeGate();
OcrShadowLineResult weakFirstLine = new(72, "[队伍] （乱码）: I am braum", Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "zh-CN", 1, "[队伍] （乱码）: I am braum", null) }, new OcrFusionMetadata("single_source", .90, new[] { "structured_chat_envelope_anchor" }));
OcrShadowLineResult weakSecondLine = weakFirstLine with { LineNumber = 73, Text = "[队伍] （乱玛）: I AM TOP", Sources = new[] { new OcrShadowLineSource(0, "zh-CN", 2, "[队伍] （乱玛）: I AM TOP", null) } };
ContinuousChatGateDecision weak1 = weakGate.Observe(new[] { weakFirstLine });
ContinuousChatGateDecision weak2 = weakGate.Observe(new[] { weakFirstLine });
ContinuousChatGateDecision weak3 = weakGate.Observe(new[] { weakFirstLine });
ContinuousChatGateDecision weakAppend1 = weakGate.Observe(new[] { weakFirstLine, weakSecondLine });
ContinuousChatGateDecision weakAppend2 = weakGate.Observe(new[] { weakFirstLine, weakSecondLine });
ContinuousChatGateDecision weakAppend3 = weakGate.Observe(new[] { weakFirstLine, weakSecondLine });
bool weakGatePass = weak1.Status == "waiting_text_stability" && weak2.AcceptedLines.Select(line => line.Text).Single() == weakFirstLine.Text &&
    weak3.Status == "frame_unchanged" && weakAppend1.Status == "waiting_text_stability" &&
    weakAppend2.AcceptedLines.Select(line => line.Text).Single() == weakSecondLine.Text && weakAppend3.Status == "frame_unchanged";
var modelStateMachine = new LocalModelReadinessStateMachine();
var modelPendingGate = new ContinuousChatChangeGate();
modelStateMachine.Apply(new LocalModelStatus("starting", "fixture starting", false));
ContinuousChatGateDecision pendingWhileStarting1 = modelPendingGate.Observe(new[] { weakFirstLine }, modelStateMachine.Ready);
ContinuousChatGateDecision pendingWhileStarting2 = modelPendingGate.Observe(new[] { weakFirstLine }, modelStateMachine.Ready);
modelStateMachine.Apply(new LocalModelStatus("ready", "fixture ready", true));
ContinuousChatGateDecision acceptedAfterReady = modelPendingGate.Observe(new[] { weakFirstLine }, modelStateMachine.Ready);
ContinuousChatGateDecision unchangedAfterReady = modelPendingGate.Observe(new[] { weakFirstLine }, modelStateMachine.Ready);
bool modelLifecyclePass = modelStateMachine.Ready && pendingWhileStarting1.AcceptedLines.Count == 0 && pendingWhileStarting2.AcceptedLines.Count == 0 &&
    acceptedAfterReady.AcceptedLines.Count == 1 && unchangedAfterReady.Status == "frame_unchanged";
bool changeGatePass = gateFirst.AcceptedLines.Count == 1 && gateSame.Status == "frame_unchanged" && gateNew.AcceptedLines.Count == 1 && weakGatePass &&
    OutputGroundingValidator.HasUngroundedDesktopUiTerm("where is translation", "Windows PowerShell says Ollama") &&
    !OutputGroundingValidator.HasUngroundedDesktopUiTerm("奥拉玛 已就绪", "奥拉玛 已就绪");
string[] v03Bodies = new[] { "I am braum", "where is my translation", "i am braum", "bro", "translate this", "translate this", "your idiot translation", "hey", "keep translating" };
OcrShadowLineResult[] v03Lines = v03Bodies.Select((body, index) => new OcrShadowLineResult(
    index + 1, $"00:20 [Team] (garbled): {body}", Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "en-US", index + 1, body, index % 2 == 0 ? "00:20" : null) },
    new OcrFusionMetadata("fused", .95, new[] { "fixture" }))).ToArray();
var v03Differ = new VisibleMessageSequenceDiffer();
VisibleMessageDiffResult v03Initial = v03Differ.Observe(v03Lines);
VisibleMessageDiffResult v03Repeat = v03Differ.Observe(v03Lines);
VisibleMessageDiffResult v03Append = v03Differ.Observe(v03Lines.Concat(new[] { v03Lines[0] with { LineNumber = 10, Text = "00:20 [Team] (garbled): final message" } }).ToArray());
bool sequenceDiffPass = v03Initial.Inserted.Count == 9 && v03Initial.Inserted[4].OccurrenceKey != v03Initial.Inserted[5].OccurrenceKey && v03Repeat.Inserted.Count == 0 && v03Append.Inserted.Count == 1;
var visualWatcher = new VisualChatChangeWatcher(TimeSpan.FromMilliseconds(300), 10);
byte[] staticFrame = new byte[16];
VisualChatWatchDecision visualBaseline = visualWatcher.Observe(staticFrame, DateTimeOffset.UnixEpoch);
bool visualStatic = Enumerable.Range(0, 20).All(index => !visualWatcher.Observe(staticFrame, DateTimeOffset.UnixEpoch.AddMilliseconds(index * 50)).ShouldRunOcr);
byte[] microFrame = new byte[16]; microFrame[0] = 1;
bool visualMicro = !visualWatcher.Observe(microFrame, DateTimeOffset.UnixEpoch.AddSeconds(2)).ShouldRunOcr;
byte[] changedFrame = new byte[16]; changedFrame[0] = 16;
VisualChatWatchDecision visualChange = visualWatcher.Observe(changedFrame, DateTimeOffset.UnixEpoch.AddSeconds(3));
VisualChatWatchDecision visualDebounce = visualWatcher.Observe(changedFrame, DateTimeOffset.UnixEpoch.AddMilliseconds(3200));
VisualChatWatchDecision visualStable = visualWatcher.Observe(changedFrame, DateTimeOffset.UnixEpoch.AddMilliseconds(3400));
bool visualWatcherPass = visualBaseline.Status == "baseline" && visualStatic && visualMicro && visualChange.Status == "change_detected" && !visualDebounce.ShouldRunOcr && visualStable.ShouldRunOcr;
var coordinateRows = CoordinateOcrLineFusion.Fuse(new StructuredOcrLine[]
{
    new("[队伍] (玩家): OC 日测试", new OcrBoundingBox(2, 20, 200, 16), Array.Empty<StructuredOcrWord>(), "auto", 1),
    new("[Team] (player): OCR test", new OcrBoundingBox(3, 21, 200, 16), Array.Empty<StructuredOcrWord>(), "en-US", 1),
    new("[Team] (player): middle", new OcrBoundingBox(2, 42, 200, 16), Array.Empty<StructuredOcrWord>(), "en-US", 1),
    new("[Team] (player): last", new OcrBoundingBox(2, 64, 200, 16), Array.Empty<StructuredOcrWord>(), "en-US", 1)
});
bool coordinateFusionPass = coordinateRows.Count == 3 && coordinateRows[0].Preferred.Text.Contains("OCR test", StringComparison.Ordinal) && coordinateRows[1].Candidates.Count == 1;
var visualDiffer = new VisibleMessageSequenceDiffer();
OcrShadowLineResult visualLineA = FusedLine(1, "[Team] (player): OCR test", "en-US");
OcrShadowLineResult visualLineB = FusedLine(1, "[Team] (player): OC 日测试", "auto");
var visualMap = new Dictionary<int, (string Hash, OcrBoundingBox Bounds)> { [1] = ("same-row-hash", new OcrBoundingBox(0, 0, 100, 14)) };
bool visualFingerprintPass = visualDiffer.Observe(new[] { visualLineA }, visualMap).Inserted.Count == 1 &&
    visualDiffer.Observe(new[] { visualLineB }, visualMap).Inserted.Count == 0;
string[] realViewportBodies = new[] { "Hi", "OCR test", "hello", "where is my translation", "hi", "hey" };
OcrShadowLineResult[] realViewportLines = realViewportBodies.Select((body, index) => new OcrShadowLineResult(
    index + 1, $"00:20 [队伍] (乱码昵称): {body}", Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(index % 2, "en-US", index + 1, body, "00:20") },
    new OcrFusionMetadata("fused", .95, new[] { "fixture" }))).ToArray();
var realViewportDiffer = new VisibleMessageSequenceDiffer();
VisibleMessageDiffResult realViewportInitial = realViewportDiffer.Observe(realViewportLines);
bool realViewportPass = realViewportInitial.Inserted.Count == 6 && realViewportDiffer.Observe(realViewportLines).Inserted.Count == 0;
bool passed = initialPass && dedupPass && safetyPass && lifecyclePass && screenshotLikePass && retryPass && continuousFrameworkPass && changeGatePass && modelLifecyclePass && sequenceDiffPass && visualWatcherPass && realViewportPass && coordinateFusionPass && visualFingerprintPass;

string outputPath = Resolve(OutputRelative);
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
File.WriteAllText(outputPath, JsonSerializer.Serialize(new
{
    fixture = "incremental_general_chat_shadow_fixture_v0.1",
    input_mode = "synthetic_fused_ocr_lines_no_image_no_network",
    formal_eligibility = "not_eligible",
    semantic_pack_sha256 = OcrShadowSemanticService.ExpectedPackSha256,
    rendering_pack_sha256 = OcrShadowSemanticService.ExpectedRenderingPackSha256,
    rc2_sha256 = ChampionOfficialRc2RealScreenshotShadowService.ExpectedRcSha256,
    model_digest = ControlledShadowQwen3Profile.ExpectedDigest,
    initial_model_calls = first.ModelCallCount,
    exact_repeat_model_calls = exactRepeat.ModelCallCount,
    new_line_model_calls = newLine.ModelCallCount,
    rolling_window_model_calls = rollingWindow.ModelCallCount,
    provider_calls = provider.CallCount,
    plain_general_translation = first.Lines.Single(line => line.LineNumber == 1).Route,
    hero_lane_route = heroLine.Route,
    formal_semantic_route = semanticLine.Route,
    mixed_language_route = first.Lines.Single(line => line.LineNumber == 4).Route,
    fusion_ambiguous_no_call = ambiguous.Lines.Single().FailureReason,
    non_fused_no_call = unreliableFusion.Lines.Single().FailureReason,
    provider_offline_no_output = offline.Lines.Single().FailureReason,
    model_prefix_no_output = prefixInjection.Lines.Single().FailureReason,
    system_notification_no_call = systemNotification.Lines.Single().FailureReason,
    repeated_capture_keeps_session = exactRepeat.DeduplicatedCount == 4,
    cancelled_region_change_keeps_session = cancellationKeepsSession,
    confirmed_region_change_resets_session = confirmedRegionChangeCanReset && explicitResetClearsSession,
    explicit_reset_allows_same_body_again = lifecycleAfterReset.ModelCallCount == 1,
    continuous_non_overlap = nonOverlap,
    continuous_pause_resume_stop = pausePass && resumePass && stopPass,
    sidecar_right_left_positioning = positioningPass,
    persisted_region_validation = persistencePass,
    focus_safe_no_self_capture_contract = "sidecar adjacent_to_region_noactivate_draggable; transient_capture_deleted_by_loop",
    screenshot_like_accepted = screenshotLike.Lines.Count,
    screenshot_like_displayed = screenshotLike.DisplayedNewCount,
    screenshot_like_fail_closed = screenshotLike.FailClosedCount,
    offline_recovery_retry = retryFirst.Lines.Single().DedupStatus + ">" + retryCooldown.Lines.Single().DedupStatus + ">" + retryRecovered.Lines.Single().DedupStatus + ">" + retryDeduplicated.Lines.Single().DedupStatus,
    unchanged_frame_zero_model_gate = gateSame.Status,
    new_message_gate = gateNew.Status,
    weak_anchor_sequence = weak1.Status + ">" + weak2.Status + ">" + weak3.Status + ">" + weakAppend1.Status + ">" + weakAppend2.Status + ">" + weakAppend3.Status,
    local_model_pending_then_ready = pendingWhileStarting1.Status + ">" + pendingWhileStarting2.Status + ">" + acceptedAfterReady.Status + ">" + unchangedAfterReady.Status,
    output_grounding_rejects_desktop_hallucination = changeGatePass,
    v03_sequence_diff_pass = sequenceDiffPass,
    v03_sequence = new { initial = v03Initial.Inserted.Count, repeat = v03Repeat.Inserted.Count, append = v03Append.Inserted.Count },
    v03_visual_watcher_pass = visualWatcherPass,
    v03_visual = new { baseline = visualBaseline.Status, change = visualChange.Status, debounce = visualDebounce.Status, stable = visualStable.Status },
    v031_real_viewport = new { inserted = realViewportInitial.Inserted.Count, repeated_inserted = realViewportDiffer.Observe(realViewportLines).Inserted.Count, passed = realViewportPass },
    passed
}, new JsonSerializerOptions { WriteIndented = true }));

Console.WriteLine($"Fixture passed: {passed}; first calls: {first.ModelCallCount}; duplicate calls: {exactRepeat.ModelCallCount}; rolling calls: {rollingWindow.ModelCallCount}");
return passed ? 0 : 1;

static OcrShadowLineResult FusedLine(int lineNumber, string text, string locale) => new(
    lineNumber, text, Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, locale, 1, text, null) },
    new OcrFusionMetadata("fused", 0.95, new[] { "fixture" }));

static OcrShadowLineResult AmbiguousLine(int lineNumber, string text) => new(
    lineNumber, text, Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "en-US", 1, text, "00:07") },
    new OcrFusionMetadata("ambiguous", 0.20, new[] { "fixture_conflict" }));

static OcrShadowLineResult UnreliableLine(int lineNumber, string text) => new(
    lineNumber, text, Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "en-US", 1, text, null) },
    new OcrFusionMetadata("unresolved", 0.60, new[] { "fixture_unreliable" }));

sealed class RecordingProvider : ILocalTranslationAttemptProvider
{
    public int CallCount { get; private set; }
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) =>
        new("succeeded", TranslateWithDiagnostics(request).FinalOutput, "fixture-recording", null);

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        CallCount++;
        string output = request.Text + " fixture";
        return new LocalTranslationAttempt("fixture-recording", "qwen3:8b", ControlledShadowQwen3Profile.ExpectedDigest,
            "fixture-v1", request.Text, request.Text, output, output, 1, null, false);
    }
}

sealed class OfflineProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) => new("unavailable", null, "fixture-offline", "ollama_local_provider_error:HttpRequestException");
    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request) => new("fixture-offline", "qwen3:8b", ControlledShadowQwen3Profile.ExpectedDigest,
        "fixture-v1", request.Text, request.Text, null, null, 1, "ollama_local_provider_error:HttpRequestException", false);
}

sealed class PrefixProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) => new("succeeded", TranslateWithDiagnostics(request).FinalOutput, "fixture-prefix", null);
    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        string output = "00:12 [Team] (Injected): " + request.Text;
        return new LocalTranslationAttempt("fixture-prefix", "qwen3:8b", ControlledShadowQwen3Profile.ExpectedDigest,
            "fixture-v1", request.Text, request.Text, output, output, 1, null, false);
    }
}

sealed class RecoveringProvider : ILocalTranslationAttemptProvider
{
    public bool Available { get; set; }
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) =>
        new(Available ? "succeeded" : "unavailable", Available ? request.Text + " recovered" : null, "fixture-recovering",
            Available ? null : "ollama_local_provider_error:HttpRequestException");
    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request) => new(
        "fixture-recovering", "qwen3:8b", ControlledShadowQwen3Profile.ExpectedDigest, "fixture-v1", request.Text, request.Text,
        Available ? request.Text + " recovered" : null, Available ? request.Text + " recovered" : null, 1,
        Available ? null : "ollama_local_provider_error:HttpRequestException", false);
}
