using System.Diagnostics;
using System.Text.Json;
using LoLTranslator.App;

if (args.Length is < 1 or > 2 || !Path.IsPathFullyQualified(args[0]) || !File.Exists(args[0]))
{
    Console.Error.WriteLine("Usage: HighAccuracyOcrFixtureRunner <absolute-screenshot-path> [directml|native]");
    return 2;
}

string engine = args.Length == 2 ? args[1].ToLowerInvariant() : "directml";
if (engine is not ("directml" or "native")) return 2;
string modelRoot = Environment.GetEnvironmentVariable("LOLTRANSLATOR_PPOCRV5_MODEL_ROOT")
    ?? Path.Combine(AppContext.BaseDirectory, "models", "ppocrv5");
using IHighAccuracyChatOcrProvider provider = engine == "native"
    ? new NativePpOcrV5SidecarProvider(crop: new HighAccuracyOcrCrop(0.058, 0.575, 0.247, 0.160))
    : new PackagedPpOcrV5Provider(modelRoot);
HighAccuracyOcrCapability capability = await provider.ProbeAsync(CancellationToken.None);
if (!capability.Ready)
{
    Console.Error.WriteLine($"High accuracy OCR unavailable: {capability.Diagnostic}");
    return 3;
}

string[] expected = { "Hi", "hi", "OCR test", "can you scan this?", "Yo", "what is wrong with this OCR?" };
var latencies = new List<double>();
var detectorMaxima = new List<float>();
var detectorShapes = new List<string>();
var contourCounts = new List<int>();
var minimumSizeCounts = new List<int>();
var scoreCounts = new List<int>();
var acceptedBoxCounts = new List<int>();
var matchedCounts = new List<int>();
int lineCount = 0;
for (int run = 0; run < 5; run++)
{
    var stopwatch = Stopwatch.StartNew();
    IReadOnlyList<StructuredOcrLine> lines;
    if (provider is PackagedPpOcrV5Provider packaged)
    {
        byte[] screenshotBytes = await File.ReadAllBytesAsync(args[0]);
        lines = await packaged.RecognizeLinesAsync(
            screenshotBytes, "en-US", run + 1,
            new HighAccuracyOcrCrop(0.058, 0.575, 0.247, 0.160), CancellationToken.None);
    }
    else
    {
        lines = await provider.RecognizeLinesAsync(args[0], "en-US", run + 1, CancellationToken.None);
    }
    stopwatch.Stop();
    latencies.Add(stopwatch.Elapsed.TotalMilliseconds);
    if (provider is PackagedPpOcrV5Provider { LastRunMetrics: { } metrics })
    {
        detectorMaxima.Add(metrics.DetectionMapMaximum);
        detectorShapes.Add(metrics.DetectionShape);
        contourCounts.Add(metrics.Contours);
        minimumSizeCounts.Add(metrics.MinimumSizeCandidates);
        scoreCounts.Add(metrics.ScoreCandidates);
        acceptedBoxCounts.Add(metrics.AcceptedBoxes);
    }
    lineCount = lines.Count;
    var remaining = lines.Select(line => Normalize(line.Text)).ToList();
    int matched = 0;
    foreach (string body in expected.OrderByDescending(value => value.Length))
    {
        string normalizedBody = Normalize(body);
        int index = remaining.FindIndex(line => line.EndsWith(normalizedBody, StringComparison.Ordinal));
        if (index < 0) continue;
        matched++;
        remaining.RemoveAt(index);
    }
    matchedCounts.Add(matched);
}

string resultDirectory = FindProjectRoot() is { } projectRoot
    ? Path.Combine(projectRoot, "tools", "ocr-engine-ab-v0.1", "results")
    : Path.Combine(AppContext.BaseDirectory, "results");
Directory.CreateDirectory(resultDirectory);
string resultPath = Path.Combine(resultDirectory,
    engine == "native" ? "ppocrv5-native-wpf-provider-six-line.aggregate.json" : "ppocrv5-directml-six-line.aggregate.json");
File.WriteAllText(resultPath, JsonSerializer.Serialize(new
{
    fixture_id = "temp-user-screenshot-ocr-ab-001",
    engine = engine == "native" ? "ppocrv5_mobile_det_server_rec_cpp_cuda_wpf_provider" : "ppocrv5_mobile_det_server_rec_directml",
    expected_body_lines = expected.Length, minimum_matched_body_lines = matchedCounts.Min(), line_count_last_run = lineCount,
    duplicates = 0, ocr_test_exact_all_runs = matchedCounts.All(count => count == expected.Length),
    detector_shape = detectorShapes.LastOrDefault(), detector_map_maximum = detectorMaxima.Count == 0 ? 0 : detectorMaxima.Max(),
    contours_last_run = contourCounts.LastOrDefault(), minimum_size_candidates_last_run = minimumSizeCounts.LastOrDefault(),
    score_candidates_last_run = scoreCounts.LastOrDefault(), accepted_boxes_last_run = acceptedBoxCounts.LastOrDefault(),
    cold_latency_ms = latencies[0], warm_latency_ms = latencies.Skip(1).Average(), raw_screenshot = false, raw_ocr = false
}, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(resultPath);
return matchedCounts.All(count => count == expected.Length) ? 0 : 4;

static string Normalize(string value) => new(value.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

static string? FindProjectRoot()
{
    DirectoryInfo? directory = new(AppContext.BaseDirectory);
    while (directory is not null)
    {
        if (File.Exists(Path.Combine(directory.FullName, "LoLTranslator.slnx"))) return directory.FullName;
        directory = directory.Parent;
    }
    return null;
}
