using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using System.Text.Json;
using LoLTranslator.App;
using SlangGraph.Core;

const string HoldoutRelative = "data/collection/lol/domain-lexicon-v0.1/rc-1-champion-official/holdout.jsonl";
const string Rc2HumanReviewRelative = "data/collection/lol/domain-lexicon-v0.1/rc-1-human-review/official-name-human-review.jsonl";
const string ExpectedRc2HumanReviewHash = "B2ED8E5D9DBEFEC46A6D69EE5DDB5D6D89BF45B3EE146C7025B7FF575DA6BD57";
const string ExpectedWorkbookHash = "67397B24662686D651D5EC5D40E67F46C9C2B5BAF2D141EC0EF0CB151B1138F7";

RcRunConfiguration configuration = ParseConfiguration(args);
bool qwen = configuration.UseQwen;
bool recording = !qwen;

string root = Directory.GetCurrentDirectory();
string rcPath = Path.Combine(root, configuration.RcRelative.Replace('/', Path.DirectorySeparatorChar));
string holdoutPath = Path.Combine(root, HoldoutRelative.Replace('/', Path.DirectorySeparatorChar));
string outputDirectory = Path.Combine(root, configuration.OutputDirectoryRelative.Replace('/', Path.DirectorySeparatorChar));
string rcHash = Hash(rcPath);
if (!string.Equals(rcHash, configuration.ExpectedRcHash, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("RC hash mismatch.");
Directory.CreateDirectory(outputDirectory);

DomainLexicon lexicon = DomainLexiconLoader.LoadJsonl(rcPath);
var index = new DomainLexiconIndex(lexicon);
var semantic = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
var validation = new List<string>();
ValidateRcShape(rcPath, lexicon, validation);
if (configuration.RequiresHumanReviewValidation)
{
    ValidateRc2HumanReview(rcPath, Path.Combine(root, Rc2HumanReviewRelative.Replace('/', Path.DirectorySeparatorChar)), validation);
}

if (recording)
{
    var provider = new RecordingProvider();
    var aggregator = new ProtectedHybridTranslationAggregator(provider);
    var orchestrator = new ChatProcessingRouteOrchestrator(semantic, provider, aggregator);
    var processor = new DomainLexiconRcShadowProcessor(index, DomainLexiconRcShadowProfile.ExplicitTestOnly(), orchestrator);
    var aliasLogs = new List<object>();
    foreach (DomainLexiconEntry entry in lexicon.Entries.OrderBy(entry => entry.CanonicalId, StringComparer.OrdinalIgnoreCase))
    {
        foreach (DomainLexiconAlias alias in entry.Aliases.OrderBy(alias => alias.Locale, StringComparer.OrdinalIgnoreCase))
        {
            string input = alias.Surface + " move now";
            DomainLexiconRcShadowResult result = processor.Process(
                new ChatProcessingRequest(input, alias.Locale, "zh-CN", ShadowContext(),
                    new ChatProcessingPolicy(ChatProcessingRoutes.GeneralTranslation, new ChatSemanticPolicy("optional", Array.Empty<string>(), Array.Empty<string>()))),
                Context(entry, "16.15.1"));
            HybridLockedSpan? span = result.RcLockedSpans.SingleOrDefault();
            LocalTranslationAttempt? attempt = aggregator.LastAttempt;
            bool pass = result.RcShadowMatches.Count == 1 && result.RcShadowMatches[0].CanonicalId == entry.CanonicalId &&
                result.RcShadowMatches[0].ToSlotValue().EntityId == entry.CanonicalId && span is not null &&
                span.VerifiedRendering == index.RenderShadow(entry.CanonicalId, "zh-CN").Text &&
                attempt?.Input.Contains(span.Marker, StringComparison.Ordinal) == true &&
                !attempt.Input.Contains(alias.Surface, StringComparison.Ordinal) &&
                result.Processing.OutputText?.Contains(span.VerifiedRendering, StringComparison.Ordinal) == true &&
                result.Processing.Status == "hybrid_completed";
            if (!pass) validation.Add("alias_protection_failed:" + alias.AliasId);
            aliasLogs.Add(new AliasLog("alias_shadow", entry.CanonicalId, alias.AliasId, alias.Locale, alias.Surface, span?.VerifiedRendering,
                result.RcShadowMatches.SingleOrDefault()?.ToSlotValue().EntityId, aggregator.LastProtectedInput, attempt?.RawOutput,
                result.Processing.OutputText, attempt?.ElapsedMilliseconds ?? 0, attempt?.Error, pass));
        }
    }

    HoldoutLog[] holdouts = EvaluateHoldouts(holdoutPath, index);
    foreach (HoldoutLog holdout in holdouts.Where(item => !item.Passed)) validation.Add("holdout_failed:" + holdout.HoldoutId);
    FailureLog[] failureModes = EvaluateFailureModes(index, semantic, lexicon.Entries[0]);
    foreach (FailureLog failure in failureModes.Where(item => !item.Passed)) validation.Add("failure_mode_failed:" + failure.Mode);
    string gate = validation.Count == 0 ? configuration.PassingGate : "blocked";
    WriteJsonl(Path.Combine(outputDirectory, configuration.RecordingOutputName), new[]
    {
        new RunHeader(configuration.RecordingRecordType, DateTimeOffset.UtcNow, rcHash, "recording_only_no_model", gate, configuration.CandidateLoadState, provider.CallCount, 0, validation)
    }.Concat(aliasLogs).Concat(holdouts.Cast<object>()).Concat(failureModes.Cast<object>()));
    Console.WriteLine($"{configuration.Name} recording aliases: {aliasLogs.Count}/346; holdouts: {holdouts.Length}/1054; gate: {gate}");
    return gate == configuration.PassingGate ? 0 : 1;
}

DomainLexiconEntry[] sample = SelectSample(lexicon.Entries, 20260804, 24).ToArray();
ControlledShadowRuntimeDependencies dependencies = ControlledShadowQwen3RuntimeFactory.Create(ControlledShadowQwen3Profile.ExplicitTestOnly());
var qwenProvider = (OllamaLocalTranslationProvider)dependencies.GeneralTranslationProvider;
var qwenAggregator = (ProtectedHybridTranslationAggregator)dependencies.HybridTranslationAggregator;
var qwenOrchestrator = new ChatProcessingRouteOrchestrator(semantic, qwenProvider, qwenAggregator);
var qwenProcessor = new DomainLexiconRcShadowProcessor(index, DomainLexiconRcShadowProfile.ExplicitTestOnly(), qwenOrchestrator);
var qwenLogs = new List<object>();
foreach ((DomainLexiconEntry entry, int sampleIndex) in sample.Select((entry, index) => (entry, index)))
{
    DomainLexiconAlias alias = entry.Aliases.First(item => string.Equals(item.Locale, "en-US", StringComparison.OrdinalIgnoreCase));
    (string input, string remainderTemplate) = BuildQwenInput(alias.Surface, sampleIndex);
    DomainLexiconRcShadowResult result = qwenProcessor.Process(
        new ChatProcessingRequest(input, "en-US", "zh-CN", ShadowContext(),
            new ChatProcessingPolicy(ChatProcessingRoutes.GeneralTranslation, new ChatSemanticPolicy("optional", Array.Empty<string>(), Array.Empty<string>()))),
        Context(entry, "16.15.1"));
    LocalTranslationAttempt? attempt = qwenAggregator.LastAttempt;
    HybridLockedSpan? span = result.RcLockedSpans.SingleOrDefault();
    bool pass = result.Processing.Status == "hybrid_completed" && span is not null && attempt is not null && attempt.Error is null &&
        attempt.Input.Contains(span.Marker, StringComparison.Ordinal) && !attempt.Input.Contains(alias.Surface, StringComparison.Ordinal) &&
        result.Processing.OutputText?.Contains(span.VerifiedRendering, StringComparison.Ordinal) == true;
    qwenLogs.Add(new QwenLog(configuration.QwenRecordType, entry.CanonicalId, alias.AliasId, Features(alias.Surface), remainderTemplate, input,
        qwenAggregator.LastProtectedInput, attempt?.Prompt, attempt?.RawOutput, result.Processing.OutputText,
        attempt?.ElapsedMilliseconds ?? 0, attempt?.Error, attempt?.ModelDigest ?? ControlledShadowQwen3Profile.ExpectedDigest,
        "not_automatically_scored_requires_human_review", pass));
    if (!pass) validation.Add("qwen_shadow_failed:" + entry.CanonicalId);
}
string qwenGate = validation.Count == 0 ? configuration.PassingGate : "blocked";
var qwenRecords = new List<object>
{
    new RunHeader(configuration.QwenHeaderRecordType, DateTimeOffset.UtcNow, rcHash, "explicit_qwen3_controlled_shadow", qwenGate, configuration.CandidateLoadState, 0, qwenLogs.Count, validation)
};
qwenRecords.AddRange(qwenLogs);
if (configuration.IncludeRotateOpenIssue)
{
    qwenRecords.Add(new OpenIssueLog("separate_open_issue", "rotate_tactical_map_movement", "legacy_rc1_qwen_shadow_samples", 24,
        "地图移动/转线/支援，不是转圈；待独立 Concept evidence 与 RC。此问题不否决官方英雄名 RC.2，且未被送入本次 Qwen 样本。"));
}
WriteJsonl(Path.Combine(outputDirectory, configuration.QwenOutputName), qwenRecords);
Console.WriteLine($"{configuration.Name} Qwen sample: {qwenLogs.Count}; passed {qwenLogs.OfType<QwenLog>().Count(item => item.Passed)}; gate: {qwenGate}");
return qwenGate == configuration.PassingGate ? 0 : 1;

static void ValidateRcShape(string path, DomainLexicon lexicon, ICollection<string> failures)
{
    if (lexicon.Entries.Count != 173 || lexicon.Entries.Any(entry => entry.Kind != "entity" || entry.Type != "champion" || entry.Aliases.Count != 2 || entry.LocalizedRenderings.Count != 2)) failures.Add("rc_scope_or_count_invalid");
    if (lexicon.Entries.SelectMany(entry => entry.Aliases).Count() != 346 || lexicon.Entries.SelectMany(entry => entry.LocalizedRenderings).Count() != 346) failures.Add("rc_alias_or_rendering_count_invalid");
    if (lexicon.Entries.Any(entry => entry.Aliases.Select(alias => alias.Locale).OrderBy(locale => locale).SequenceEqual(new[] { "en-US", "zh-CN" }) == false)) failures.Add("rc_locale_pair_invalid");
    if (lexicon.Entries.Any(entry => entry.Aliases.Any(alias => !string.IsNullOrEmpty(alias.Ambiguity?.Group)) || entry.Aliases.Any(alias => alias.PatchValidity?.From != "16.15.1" || alias.PatchValidity?.To != "16.15.1"))) failures.Add("rc_conflict_or_patch_invalid");
    if (File.ReadLines(path).Count() != 174) failures.Add("rc_line_count_invalid");
}

static void ValidateRc2HumanReview(string rcPath, string reviewPath, ICollection<string> failures)
{
    if (!File.Exists(reviewPath) || !string.Equals(Hash(reviewPath), ExpectedRc2HumanReviewHash, StringComparison.OrdinalIgnoreCase))
    {
        failures.Add("rc2_human_review_artifact_hash_invalid");
        return;
    }

    using JsonDocument rcHeaderDocument = JsonDocument.Parse(File.ReadLines(rcPath).First());
    JsonElement rcHeader = rcHeaderDocument.RootElement;
    if (Text(rcHeader, "lexicon_version") != "0.1.0-champion-official-rc.2" ||
        Text(rcHeader, "formal_eligibility") != "candidate_only" ||
        Text(rcHeader.GetProperty("review_gates").GetProperty("human_language_review"), "status") != "approved_no_correction_reported" ||
        Text(rcHeader.GetProperty("provenance").GetProperty("human_review"), "workbook_sha256") != ExpectedWorkbookHash ||
        rcHeader.GetProperty("alias_policy").GetProperty("user_supplied_player_aliases_excluded").ValueKind != JsonValueKind.True)
    {
        failures.Add("rc2_header_or_review_status_invalid");
    }

    var canonicalIds = new HashSet<string>(StringComparer.Ordinal);
    var reviewIds = new HashSet<string>(StringComparer.Ordinal);
    foreach (string line in File.ReadLines(rcPath).Skip(1))
    {
        using JsonDocument document = JsonDocument.Parse(line);
        JsonElement entry = document.RootElement;
        string canonicalId = Text(entry, "canonical_id") ?? string.Empty;
        canonicalIds.Add(canonicalId);
        if (Text(entry, "kind") != "entity" || Text(entry, "type") != "champion" ||
            Text(entry, "review_status") != "approved_no_correction_reported" ||
            Text(entry, "formal_eligibility") != "candidate_only" ||
            Text(entry, "rc_eligibility") != "runtime_revalidation_required")
        {
            failures.Add("rc2_entry_status_or_scope_invalid:" + canonicalId);
        }

        foreach (JsonElement alias in entry.GetProperty("aliases").EnumerateArray())
        {
            if (Text(alias, "alias_type") != "official_display_name" || Text(alias, "review_status") != "approved_no_correction_reported" ||
                Text(alias, "formal_eligibility") != "candidate_only" || Text(alias, "rc_eligibility") != "runtime_revalidation_required" ||
                Text(alias.GetProperty("governance"), "human_review_record_id") is not string reviewId)
            {
                failures.Add("rc2_alias_status_or_alias_leak:" + canonicalId);
            }
            else
            {
                reviewIds.Add(reviewId);
            }
        }
    }

    var reviewedCanonicalIds = new HashSet<string>(StringComparer.Ordinal);
    var reviewedIds = new HashSet<string>(StringComparer.Ordinal);
    string[] reviewLines = File.ReadAllLines(reviewPath);
    using (JsonDocument reviewHeaderDocument = JsonDocument.Parse(reviewLines[0]))
    {
        JsonElement reviewHeader = reviewHeaderDocument.RootElement;
        if (Text(reviewHeader, "workbook_sha256") != ExpectedWorkbookHash || Text(reviewHeader, "formal_eligibility") != "not_eligible")
        {
            failures.Add("rc2_human_review_header_invalid");
        }
    }
    foreach (string line in reviewLines.Skip(1))
    {
        using JsonDocument document = JsonDocument.Parse(line);
        JsonElement record = document.RootElement;
        if (Text(record, "decision") != "approved_no_correction_reported" || Text(record, "formal_eligibility") != "not_eligible" ||
            Text(record.GetProperty("reviewed_at_source"), "workbook_sha256") != ExpectedWorkbookHash)
        {
            failures.Add("rc2_human_review_record_invalid");
        }
        reviewedCanonicalIds.Add(Text(record, "canonical_id") ?? string.Empty);
        reviewedIds.Add(Text(record, "review_id") ?? string.Empty);
    }

    if (canonicalIds.Count != 173 || reviewedCanonicalIds.Count != 173 || reviewedIds.Count != 173 || !canonicalIds.SetEquals(reviewedCanonicalIds) ||
        reviewIds.Count != 173 || !reviewIds.SetEquals(reviewedIds))
    {
        failures.Add("rc2_human_review_reference_count_or_alignment_invalid");
    }
}

static HoldoutLog[] EvaluateHoldouts(string path, DomainLexiconIndex index) => File.ReadLines(path).Skip(1).Select(line =>
{
    using JsonDocument document = JsonDocument.Parse(line);
    JsonElement item = document.RootElement;
    string id = Text(item, "holdout_id")!;
    string input = Text(item, "input_text")!;
    string locale = Text(item, "locale")!;
    string? patch = Text(item, "patch");
    string[] tags = item.GetProperty("context_scope").EnumerateArray().Select(value => value.GetString()!).ToArray();
    DomainLexiconMatchResult result = index.Match(input, locale, new DomainLexiconMatchContext(null, null, null, patch, tags), new DomainLexiconMatchOptions(true));
    bool passed = result.FormalMatches.Count == 0 && result.CandidateShadowMatches.Count == 0;
    return new HoldoutLog("holdout", id, Text(item, "category")!, input, locale, patch, result.FormalMatches.Count, result.CandidateShadowMatches.Count, result.AmbiguityReasons, passed);
}).ToArray();

static FailureLog[] EvaluateFailureModes(DomainLexiconIndex index, OcrShadowSemanticService semantic, DomainLexiconEntry entry)
{
    DomainLexiconAlias alias = entry.Aliases.First(item => item.Locale == "en-US");
    var cases = new[]
    {
        ("provider_timeout", new FailureProvider("ollama_local_provider_error:TaskCanceledException", corruptMarker: false), "ollama_local_provider_error:TaskCanceledException"),
        ("format_violation", new FailureProvider("local_translation_format_violation_multiline", corruptMarker: false), "local_translation_format_violation_multiline"),
        ("lock_corruption", new FailureProvider(null, corruptMarker: true), "hybrid_locked_marker_not_preserved")
    };
    return cases.Select(item =>
    {
        var aggregator = new ProtectedHybridTranslationAggregator(item.Item2);
        var processor = new DomainLexiconRcShadowProcessor(index, DomainLexiconRcShadowProfile.ExplicitTestOnly(), new ChatProcessingRouteOrchestrator(semantic, item.Item2, aggregator));
        DomainLexiconRcShadowResult result = processor.Process(
            new ChatProcessingRequest(alias.Surface + " move now", "en-US", "zh-CN", ShadowContext(),
                new ChatProcessingPolicy(ChatProcessingRoutes.GeneralTranslation, new ChatSemanticPolicy("optional", Array.Empty<string>(), Array.Empty<string>()))),
            Context(entry, "16.15.1"));
        string? reason = result.Processing.HybridAggregation?.FailureReason;
        bool pass = result.Processing.Status == "hybrid_unavailable" && result.Processing.OutputText is null && reason == item.Item3;
        return new FailureLog("failure_mode", item.Item1, reason, result.Processing.OutputText, item.Item2.CallCount, item.Item2.UsedFallback, pass);
    }).ToArray();
}

static IEnumerable<DomainLexiconEntry> SelectSample(IReadOnlyList<DomainLexiconEntry> entries, int seed, int maximum)
{
    var random = new Random(seed);
    var selected = new List<DomainLexiconEntry>();
    string[] features = { "space", "apostrophe", "period", "hyphen", "unicode", "mixed_case" };
    foreach (string feature in features)
    {
        DomainLexiconEntry? pick = entries.Where(entry => Features(entry.Aliases.First(alias => alias.Locale == "en-US").Surface).Contains(feature, StringComparer.Ordinal))
            .OrderBy(_ => random.Next()).FirstOrDefault();
        if (pick is not null && !selected.Contains(pick)) selected.Add(pick);
    }
    selected.AddRange(entries.Where(entry => !selected.Contains(entry)).OrderBy(_ => random.Next()).Take(Math.Max(0, maximum - selected.Count)));
    return selected.Take(maximum);
}

static (string Input, string RemainderTemplate) BuildQwenInput(string officialName, int sampleIndex)
{
    string[] templates =
    {
        "{name} is here.",
        "{name} is coming.",
        "Wait for {name}.",
        "{name} is still here."
    };
    string template = templates[sampleIndex % templates.Length];
    return (template.Replace("{name}", officialName, StringComparison.Ordinal), template);
}

static RcRunConfiguration ParseConfiguration(string[] args)
{
    if (args.Length != 1) throw new ArgumentException("Use an explicit RC.1 or RC.2 recording/Qwen mode.");
    return args[0] switch
    {
        "--recording-shadow" => new RcRunConfiguration("RC.1", false,
            "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.1.jsonl",
            "data/collection/lol/domain-lexicon-v0.1/rc-1-champion-official/runtime-shadow",
            "368D87211E219D9E31AA4FA3C74BFF6B58AF4F2D5D64EAB11B2AF6866C3856F9",
            "ready_for_human_language_review", "candidate1_and_candidate2_not_loaded", "champion-official-rc.1-recording-shadow.jsonl",
            "champion-official-rc.1-qwen3-shadow-sample.jsonl", "champion_rc_recording_shadow", "champion_rc_qwen3_shadow", "qwen3_rc_shadow", false, false),
        "--enable-qwen3-controlled-shadow" => new RcRunConfiguration("RC.1", true,
            "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.1.jsonl",
            "data/collection/lol/domain-lexicon-v0.1/rc-1-champion-official/runtime-shadow",
            "368D87211E219D9E31AA4FA3C74BFF6B58AF4F2D5D64EAB11B2AF6866C3856F9",
            "ready_for_human_language_review", "candidate1_and_candidate2_not_loaded", "champion-official-rc.1-recording-shadow.jsonl",
            "champion-official-rc.1-qwen3-shadow-sample.jsonl", "champion_rc_recording_shadow", "champion_rc_qwen3_shadow", "qwen3_rc_shadow", false, false),
        "--rc2-recording-shadow" => new RcRunConfiguration("RC.2", false,
            "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.2.jsonl",
            "data/collection/lol/domain-lexicon-v0.1/rc-1-human-review/runtime-shadow",
            "040181DD0464CCE8D1131A1AA47AB0D2A0B07CA69D4DEADD3316A626A1FFB5EE",
            "ready_for_real_screenshot_shadow", "candidate1_candidate2_and_rc1_not_loaded", "champion-official-rc.2-revalidation-recording-shadow.jsonl",
            "champion-official-rc.2-revalidation-qwen3-shadow-sample.jsonl", "champion_rc2_recording_shadow", "champion_rc2_qwen3_shadow", "qwen3_rc2_shadow", true, true),
        "--rc2-enable-qwen3-controlled-shadow" => new RcRunConfiguration("RC.2", true,
            "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.2.jsonl",
            "data/collection/lol/domain-lexicon-v0.1/rc-1-human-review/runtime-shadow",
            "040181DD0464CCE8D1131A1AA47AB0D2A0B07CA69D4DEADD3316A626A1FFB5EE",
            "ready_for_real_screenshot_shadow", "candidate1_candidate2_and_rc1_not_loaded", "champion-official-rc.2-revalidation-recording-shadow.jsonl",
            "champion-official-rc.2-revalidation-qwen3-shadow-sample.jsonl", "champion_rc2_recording_shadow", "champion_rc2_qwen3_shadow", "qwen3_rc2_shadow", true, true),
        _ => throw new ArgumentException("Use --recording-shadow, --enable-qwen3-controlled-shadow, --rc2-recording-shadow, or --rc2-enable-qwen3-controlled-shadow.")
    };
}

static string[] Features(string value) => new[]
{
    value.Any(char.IsWhiteSpace) ? "space" : null,
    value.Contains('\'') || value.Contains('’') ? "apostrophe" : null,
    value.Contains('.') ? "period" : null,
    value.Any(character => character is '-' or '‐' or '‑' or '–' or '—') ? "hyphen" : null,
    value.Any(character => character > 127) ? "unicode" : null,
    value.Any(char.IsUpper) && value.Any(char.IsLower) ? "mixed_case" : null
}.Where(value => value is not null).Cast<string>().ToArray();

static DomainLexiconMatchContext Context(DomainLexiconEntry entry, string patch) => new(null, null, null, patch, entry.ContextScopes.SelectMany(scope => scope.Tags ?? Array.Empty<string>()).ToArray());
static ShadowMatchContextOption ShadowContext() => new("rc-shadow", "lol.global", "in_game_chat");
static string? Text(JsonElement value, string property) => value.TryGetProperty(property, out JsonElement item) && item.ValueKind == JsonValueKind.String ? item.GetString() : null;
static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));
static void WriteJsonl(string path, IEnumerable<object> records)
{
    var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
    File.WriteAllLines(path, records.Select(record => JsonSerializer.Serialize(record, options)));
}

sealed record RunHeader(string RecordType, DateTimeOffset GeneratedAt, string RcSha256, string Mode, string Gate, string CandidateLoadState, int RecordingProviderCalls, int QwenCalls, IReadOnlyList<string> Failures);
sealed record AliasLog(string RecordType, string CanonicalId, string AliasId, string Locale, string Surface, string? ZhRendering, string? TypedEntityId, string? ProtectedInput, string? RawOutput, string? FinalOutput, long ElapsedMilliseconds, string? Error, bool Passed);
sealed record HoldoutLog(string RecordType, string HoldoutId, string Category, string Input, string Locale, string? Patch, int FormalMatches, int CandidateMatches, IReadOnlyList<string> Reasons, bool Passed);
sealed record RcRunConfiguration(string Name, bool UseQwen, string RcRelative, string OutputDirectoryRelative, string ExpectedRcHash, string PassingGate, string CandidateLoadState, string RecordingOutputName, string QwenOutputName, string RecordingRecordType, string QwenHeaderRecordType, string QwenRecordType, bool RequiresHumanReviewValidation, bool IncludeRotateOpenIssue);
sealed record QwenLog(string RecordType, string CanonicalId, string AliasId, IReadOnlyList<string> Features, string RemainderTemplate, string Input, string? ProtectedInput, string? Prompt, string? RawOutput, string? FinalOutput, long ElapsedMilliseconds, string? Error, string ModelDigest, string NaturalnessObservation, bool Passed);
sealed record FailureLog(string RecordType, string Mode, string? FailureReason, string? OutputText, int ProviderCalls, bool UsedFallback, bool Passed);
sealed record OpenIssueLog(string RecordType, string IssueId, string Source, int AffectedCaseCount, string Description);

sealed class RecordingProvider : ILocalTranslationAttemptProvider
{
    public int CallCount { get; private set; }
    public GeneralTranslationResult Translate(GeneralTranslationRequest request)
    {
        LocalTranslationAttempt attempt = TranslateWithDiagnostics(request);
        return new GeneralTranslationResult("succeeded", attempt.FinalOutput, "rc-recording", null);
    }
    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        CallCount++;
        string output = request.Text + " 继续";
        return new LocalTranslationAttempt("rc-recording", "none", "none", "recording-v1", request.Text, request.Text, output, output, 0, null, false);
    }
}

sealed class FailureProvider : ILocalTranslationAttemptProvider
{
    private readonly string? _error;
    private readonly bool _corruptMarker;
    public FailureProvider(string? error, bool corruptMarker) { _error = error; _corruptMarker = corruptMarker; }
    public int CallCount { get; private set; }
    public bool UsedFallback => false;
    public GeneralTranslationResult Translate(GeneralTranslationRequest request)
    {
        LocalTranslationAttempt attempt = TranslateWithDiagnostics(request);
        return new GeneralTranslationResult(attempt.Error is null ? "succeeded" : "unavailable", attempt.FinalOutput, "rc-failure-test", attempt.Error);
    }
    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        CallCount++;
        string? output = _error is null
            ? request.Text.Replace("[[RC_LOCKED_1]]", "[[RC_LOCKED_1]", StringComparison.Ordinal)
            : null;
        return new LocalTranslationAttempt("rc-failure-test", "none", "none", "failure-test", request.Text, request.Text, output, output, 0, _error, false);
    }
}
