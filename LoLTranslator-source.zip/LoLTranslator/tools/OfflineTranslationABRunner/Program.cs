using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using LoLTranslator.App;

const string InputRelativePath = "data/collection/lol/synthetic-chat-v0.1/drafts/synthetic-chat-evaluation.v0.2-rc.1.jsonl";
const string OutputRelativePath = "data/collection/lol/synthetic-chat-v0.1/runs/offline-translation-ab-v0.1-r2";
const string ExpectedInputHash = "73A2FAFBF53ECEFD2644653824494FC3B2B3830CDF87B7320328939F92F15A17";

string? profileName = args.Length == 2 && args[0] == "--profile" ? args[1] : null;
if (profileName is not ("translategemma-4b" or "qwen3-8b"))
{
    throw new ArgumentException("Usage: --profile translategemma-4b|qwen3-8b");
}

OllamaTranslationProfile profile = profileName switch
{
    "translategemma-4b" => new OllamaTranslationProfile(
        "ollama.translategemma.4b.q4_k_m",
        "translategemma:4b",
        "translategemma-official-direct-v1",
        "c49d986b0764f5881c476eb21435bb62b7abc62347aab3d4a6071e811be510a1",
        DisableThinking: false,
        TemplateKind: "translategemma_direct"),
    "qwen3-8b" => new OllamaTranslationProfile(
        "ollama.qwen3.8b.q4_k_m",
        "qwen3:8b",
        "qwen3-non-thinking-strict-zh-hans-v1",
        "500a1f067a9f782620b40bee6f7b0c89e17ae61f686b92c24933e4ca4b2b8b41",
        DisableThinking: true,
        TemplateKind: "qwen3_non_thinking"),
    _ => throw new InvalidOperationException("Unsupported A/B profile.")
};

string root = Directory.GetCurrentDirectory();
string inputPath = Path.Combine(root, InputRelativePath.Replace('/', Path.DirectorySeparatorChar));
string outputDirectory = Path.Combine(root, OutputRelativePath.Replace('/', Path.DirectorySeparatorChar));
if (!string.Equals(ComputeSha256(inputPath), ExpectedInputHash, StringComparison.OrdinalIgnoreCase))
{
    throw new InvalidDataException("Frozen v0.2-rc.1 evaluation file hash does not match its release contract.");
}

var json = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true,
    PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = false
};
EvaluationCase[] cases = File.ReadLines(inputPath)
    .Where(line => !string.IsNullOrWhiteSpace(line))
    .Select(line => JsonSerializer.Deserialize<EvaluationCase>(line, json) ?? throw new InvalidDataException("Invalid evaluation JSONL."))
    .Where(item => item.EvaluationAxes.ProcessingRoute is ChatProcessingRoutes.GeneralTranslation or ChatProcessingRoutes.Hybrid)
    .ToArray();
if (cases.Length != 109 || cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.GeneralTranslation) != 70 || cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.Hybrid) != 39)
{
    throw new InvalidDataException("The A/B set must be exactly 70 general_translation plus 39 hybrid cases.");
}
if (cases.Any(item => item.RecordOrigin != "synthetic_generation" || item.FormalEligibility != "not_eligible"))
{
    throw new InvalidDataException("Synthetic eligibility boundary changed.");
}

var provider = new OllamaLocalTranslationProvider(profile);
var aggregator = new ProtectedHybridTranslationAggregator(provider);
var service = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
var orchestrator = new ChatProcessingRouteOrchestrator(service, provider, aggregator);
var results = new List<OfflineTranslationResult>();

foreach (EvaluationCase item in cases)
{
    ShadowMatchContextOption context = item.Channel == "team"
        ? new ShadowMatchContextOption("Synthetic team chat", "lol.global", "in_game_chat", new[] { "lol.global", "lol.eu_or_global" })
        : new ShadowMatchContextOption("Synthetic non-in-game chat", "lol.global", item.Channel);
    ChatSemanticPolicy policy = new(
        item.EvaluationAxes.SemanticExpectation.Mode,
        item.EvaluationAxes.SemanticExpectation.ConceptIds ?? Array.Empty<string>(),
        item.EvaluationAxes.SemanticExpectation.ForbiddenConceptIds ?? Array.Empty<string>());
    ChatProcessingResult processed = orchestrator.Process(new ChatProcessingRequest(
        item.RawText,
        item.SourceLocale,
        item.TargetLocale,
        context,
        new ChatProcessingPolicy(item.EvaluationAxes.ProcessingRoute, policy)));
    LocalTranslationAttempt? attempt = item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.Hybrid
        ? aggregator.LastAttempt
        : provider.LastAttempt;
    string? final = processed.OutputText;
    OutputChecks checks = EvaluateOutput(item.RawText, attempt?.RawOutput, final);
    results.Add(new OfflineTranslationResult(
        "offline_translation_ab_result",
        "offline-translation-ab/0.1",
        item.CaseId,
        item.EvaluationAxes.ProcessingRoute,
        processed.ProcessingRoute,
        profile.ProfileId,
        profile.ModelTag,
        profile.ModelDigest,
        profile.PromptTemplateVersion,
        item.RawText,
        item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.Hybrid ? aggregator.LastProtectedInput : item.RawText,
        attempt?.RawOutput,
        final,
        attempt?.ElapsedMilliseconds,
        attempt?.Error ?? (processed.Status.EndsWith("completed", StringComparison.Ordinal) ? null : processed.Status),
        attempt?.UsedFallback ?? false,
        processed.SemanticMatches.Select(match => match.ConceptId).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
        processed.SemanticRenderings.Select(rendering => rendering.Text).ToArray(),
        processed.Status,
        checks,
        item.RecordOrigin,
        item.FormalEligibility,
        "synthetic_generation_only_not_observation_evidence_or_batch_003_count"));
}

Directory.CreateDirectory(outputDirectory);
string resultPath = Path.Combine(outputDirectory, $"{profileName}.jsonl");
string reportPath = Path.Combine(outputDirectory, $"{profileName}-report.md");
File.WriteAllLines(resultPath, results.Select(result => JsonSerializer.Serialize(result, json)), new UTF8Encoding(false));
File.WriteAllText(reportPath, BuildReport(profile, results), new UTF8Encoding(false));

Console.WriteLine($"Offline A/B profile {profile.ProfileId}: {results.Count}/109");
Console.WriteLine(resultPath);
Console.WriteLine(reportPath);

static OutputChecks EvaluateOutput(string input, string? raw, string? final)
{
    bool empty = string.IsNullOrWhiteSpace(final);
    string normalizedRaw = raw?.Replace("\r\n", "\n", StringComparison.Ordinal).Trim() ?? string.Empty;
    bool formatViolation = !string.IsNullOrWhiteSpace(normalizedRaw) &&
        (normalizedRaw.Contains('\n') || Regex.IsMatch(normalizedRaw, @"^\s*(?:translation|译文|翻译)\s*[:：]", RegexOptions.IgnoreCase));
    bool hasNegation = Regex.IsMatch(input, @"\b(?:no|not|don't|didn't|cannot|can't|without|never)\b", RegexOptions.IgnoreCase);
    bool hasNumbers = Regex.IsMatch(input, @"\d+");
    bool hasTime = Regex.IsMatch(input, @"\b\d{1,2}:\d{2}\b|\b\d+\s*(?:s|sec|secs|second|seconds|min|mins|minute|minutes)\b", RegexOptions.IgnoreCase);
    bool hasCondition = Regex.IsMatch(input, @"\b(?:if|unless|until|when|after|before)\b", RegexOptions.IgnoreCase);
    string output = final ?? string.Empty;
    bool negationFailure = hasNegation && !Regex.IsMatch(output, "[不没别无未勿]", RegexOptions.CultureInvariant);
    bool numberFailure = hasNumbers && Regex.Matches(input, @"\d+").Cast<Match>().Select(match => match.Value).Any(number => !output.Contains(number, StringComparison.Ordinal));
    bool timeFailure = hasTime && !Regex.IsMatch(output, @"\d|秒|分|:|：", RegexOptions.CultureInvariant);
    bool conditionFailure = hasCondition && !Regex.IsMatch(output, "如果|若|等|直到|之后|以后|前|再|时", RegexOptions.CultureInvariant);
    bool suspectedAddition = !string.IsNullOrWhiteSpace(output) &&
        (Regex.IsMatch(output, @"(?:作为|解释|注意|我无法|翻译如下)", RegexOptions.CultureInvariant) || output.Length > Math.Max(32, input.Length * 3));
    return new OutputChecks(empty, formatViolation, negationFailure, numberFailure, timeFailure, conditionFailure, suspectedAddition);
}

static string BuildReport(OllamaTranslationProfile profile, IReadOnlyList<OfflineTranslationResult> results)
{
    long? Percentile(double percentile) => results.Where(result => result.ElapsedMilliseconds is not null).Select(result => result.ElapsedMilliseconds!.Value).Order().ElementAtOrDefault((int)Math.Ceiling(results.Count(result => result.ElapsedMilliseconds is not null) * percentile) - 1);
    int success = results.Count(result => result.Error is null && !result.Checks.EmptyOutput);
    var report = new StringBuilder();
    report.AppendLine($"# Offline translation A/B: {profile.ProfileId}");
    report.AppendLine();
    report.AppendLine("Scope: local Ollama only; direct raw_text evaluation; no OCR; no Pack or data-governance mutation.");
    report.AppendLine();
    report.AppendLine("## Model");
    report.AppendLine();
    report.AppendLine($"- Tag: `{profile.ModelTag}`");
    report.AppendLine($"- Digest: `{profile.ModelDigest}`");
    report.AppendLine($"- Prompt/template: `{profile.PromptTemplateVersion}`");
    report.AppendLine($"- Thinking disabled: `{profile.DisableThinking}`");
    report.AppendLine();
    report.AppendLine("## Coverage and safety");
    report.AppendLine();
    report.AppendLine($"- Sent: {results.Count}/109 (general_translation={results.Count(x => x.Route == ChatProcessingRoutes.GeneralTranslation)}, hybrid={results.Count(x => x.Route == ChatProcessingRoutes.Hybrid)}).");
    report.AppendLine("- Excluded before model invocation: human_review_required=31; semantic_rendering=10.");
    report.AppendLine($"- Hybrid verified lock renderings: {results.Sum(x => x.LockedRenderings.Count)}; marker failure produces unavailable output, never a model replacement.");
    report.AppendLine();
    report.AppendLine("## Runtime statistics");
    report.AppendLine();
    report.AppendLine("| Measure | Value |");
    report.AppendLine("| --- | ---: |");
    report.AppendLine($"| Success | {success}/{results.Count} ({(100.0 * success / results.Count):0.0}%) |");
    report.AppendLine($"| P50 latency | {Percentile(0.50)} ms |");
    report.AppendLine($"| P95 latency | {Percentile(0.95)} ms |");
    report.AppendLine($"| Empty output | {results.Count(x => x.Checks.EmptyOutput)} |");
    report.AppendLine($"| Format violation | {results.Count(x => x.Checks.FormatViolation)} |");
    report.AppendLine($"| Negation preservation flags | {results.Count(x => x.Checks.NegationPreservationFailure)} |");
    report.AppendLine($"| Number preservation flags | {results.Count(x => x.Checks.NumberPreservationFailure)} |");
    report.AppendLine($"| Time preservation flags | {results.Count(x => x.Checks.TimePreservationFailure)} |");
    report.AppendLine($"| Condition preservation flags | {results.Count(x => x.Checks.ConditionPreservationFailure)} |");
    report.AppendLine($"| Suspected addition flags | {results.Count(x => x.Checks.SuspectedAddition)} |");
    report.AppendLine();
    report.AppendLine("All records are `synthetic_generation` and `formal_eligibility=not_eligible`; this is not Observation, Evidence, Review, or a batch-003 count.");
    return report.ToString();
}

static string ComputeSha256(string path)
{
    using FileStream stream = File.OpenRead(path);
    return Convert.ToHexString(SHA256.HashData(stream));
}

public sealed record EvaluationCase(
    [property: JsonPropertyName("case_id")] string CaseId,
    [property: JsonPropertyName("channel")] string Channel,
    [property: JsonPropertyName("source_locale")] string SourceLocale,
    [property: JsonPropertyName("raw_text")] string RawText,
    [property: JsonPropertyName("target_locale")] string TargetLocale,
    [property: JsonPropertyName("record_origin")] string RecordOrigin,
    [property: JsonPropertyName("formal_eligibility")] string FormalEligibility,
    [property: JsonPropertyName("evaluation_axes")] EvaluationAxes EvaluationAxes);

public sealed record EvaluationAxes(
    [property: JsonPropertyName("processing_route")] string ProcessingRoute,
    [property: JsonPropertyName("semantic_expectation")] SemanticExpectation SemanticExpectation);

public sealed record SemanticExpectation(
    [property: JsonPropertyName("mode")] string Mode,
    [property: JsonPropertyName("concept_ids")] IReadOnlyList<string>? ConceptIds,
    [property: JsonPropertyName("forbidden_concept_ids")] IReadOnlyList<string>? ForbiddenConceptIds);

public sealed record OutputChecks(
    bool EmptyOutput,
    bool FormatViolation,
    bool NegationPreservationFailure,
    bool NumberPreservationFailure,
    bool TimePreservationFailure,
    bool ConditionPreservationFailure,
    bool SuspectedAddition);

public sealed record OfflineTranslationResult(
    string RecordType,
    string SchemaVersion,
    string CaseId,
    string Route,
    string ActualRoute,
    string ModelProfile,
    string ModelTag,
    string ModelDigest,
    string PromptTemplateVersion,
    string Input,
    string? ModelInput,
    string? RawOutput,
    string? FinalOutput,
    long? ElapsedMilliseconds,
    string? Error,
    bool UsedFallback,
    IReadOnlyList<string> LockedConceptIds,
    IReadOnlyList<string> LockedRenderings,
    string RuntimeStatus,
    OutputChecks Checks,
    string RecordOrigin,
    string FormalEligibility,
    string DataBoundary);
