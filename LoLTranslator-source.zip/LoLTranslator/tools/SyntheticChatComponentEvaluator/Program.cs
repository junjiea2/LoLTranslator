using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using LoLTranslator.App;

const string InputRelativePath = "data/collection/lol/synthetic-chat-v0.1/drafts/synthetic-chat-evaluation.v0.2-rc.1.jsonl";
const string OutputDirectoryRelativePath = "data/collection/lol/synthetic-chat-v0.1/runs";
const string ResultFileName = "synthetic-chat-component-evaluation.v0.2-rc.1.jsonl";
const string ReportFileName = "synthetic-chat-component-evaluation.v0.2-rc.1-report.md";
const string ExpectedInputHash = "73A2FAFBF53ECEFD2644653824494FC3B2B3830CDF87B7320328939F92F15A17";

string workspaceRoot = Directory.GetCurrentDirectory();
string inputPath = Path.Combine(workspaceRoot, InputRelativePath.Replace('/', Path.DirectorySeparatorChar));
string outputDirectory = Path.Combine(workspaceRoot, OutputDirectoryRelativePath.Replace('/', Path.DirectorySeparatorChar));
string inputHash = ComputeSha256(inputPath);
if (!string.Equals(inputHash, ExpectedInputHash, StringComparison.OrdinalIgnoreCase))
{
    throw new InvalidDataException($"Frozen v0.2-rc.1 hash mismatch. Expected {ExpectedInputHash}; got {inputHash}.");
}

var jsonOptions = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true,
    PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = false
};

EvaluationCase[] cases = File.ReadLines(inputPath)
    .Where(line => !string.IsNullOrWhiteSpace(line))
    .Select((line, index) => JsonSerializer.Deserialize<EvaluationCase>(line, jsonOptions)
        ?? throw new InvalidDataException($"Input line {index + 1} is not a JSON object."))
    .ToArray();

ValidateInput(cases);
var service = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
var orchestrator = new ChatProcessingRouteOrchestrator(service);
ComponentEvaluationResult[] results = cases.Select(item => Evaluate(item, orchestrator)).ToArray();
ValidateResults(results);

Directory.CreateDirectory(outputDirectory);
string resultPath = Path.Combine(outputDirectory, ResultFileName);
string reportPath = Path.Combine(outputDirectory, ReportFileName);
File.WriteAllLines(
    resultPath,
    results.Select(result => JsonSerializer.Serialize(result, jsonOptions)),
    new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
File.WriteAllText(reportPath, BuildReport(inputHash, results), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));

Console.WriteLine($"v0.2-rc.1 component evaluation: {results.Length}/150");
Console.WriteLine($"Result JSONL: {resultPath}");
Console.WriteLine($"Report: {reportPath}");

static ComponentEvaluationResult Evaluate(EvaluationCase item, ChatProcessingRouteOrchestrator orchestrator)
{
    ShadowMatchContextOption context = item.Channel == "team"
        ? new ShadowMatchContextOption("Synthetic team chat", "lol.global", "in_game_chat", new[] { "lol.global", "lol.eu_or_global" })
        : new ShadowMatchContextOption("Synthetic non-in-game chat", "lol.global", item.Channel);
    ChatSemanticPolicy semanticPolicy = new(
        item.EvaluationAxes.SemanticExpectation.Mode,
        item.EvaluationAxes.SemanticExpectation.ConceptIds ?? Array.Empty<string>(),
        item.EvaluationAxes.SemanticExpectation.ForbiddenConceptIds ?? Array.Empty<string>());
    ChatProcessingResult result = orchestrator.Process(new ChatProcessingRequest(
        item.RawText,
        item.SourceLocale,
        item.TargetLocale,
        context,
        new ChatProcessingPolicy(item.EvaluationAxes.ProcessingRoute, semanticPolicy)));

    bool routePassed = result.ProcessingRoute == item.EvaluationAxes.ProcessingRoute;
    bool semanticPolicyPassed = result.SemanticPolicy?.IsSatisfied == true;
    bool humanGatePassed = item.EvaluationAxes.ProcessingRoute != ChatProcessingRoutes.HumanReview ||
                           (result.HumanReview.RequiresReview && result.OutputText is null);
    bool directRenderingPassed = item.EvaluationAxes.ProcessingRoute != ChatProcessingRoutes.SemanticRendering ||
                                 (result.Status == "semantic_rendering_completed" && !string.IsNullOrWhiteSpace(result.OutputText));
    bool missingCapability = result.Status is "general_translation_unavailable" or "hybrid_unavailable";
    string capabilityState = missingCapability
        ? "not_exercised_missing_capability"
        : result.Status == "semantic_rendering_completed"
            ? "available_rendering"
            : result.Status == "human_review_required"
                ? "human_review_gate_available"
                : "runtime_status:" + result.Status;

    return new ComponentEvaluationResult(
        "synthetic_chat_component_evaluation_result",
        "synthetic-chat-component-evaluation/0.2-rc.1",
        item.CaseId,
        item.RawText,
        item.ContentClass,
        "direct_raw_text_no_ocr",
        item.EvaluationAxes.ProcessingRoute,
        result.ProcessingRoute,
        item.EvaluationAxes.SemanticExpectation.Mode,
        semanticPolicyPassed,
        result.SemanticPolicy?.SuppressedFormalMatches ?? false,
        result.SemanticPolicy?.Violations ?? Array.Empty<string>(),
        result.ObservedSemanticMatches.Select(match => match.ConceptId).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
        result.SemanticMatches.Select(match => match.ConceptId).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
        result.SemanticRenderings.Select(rendering => rendering.RenderingId).ToArray(),
        result.Status,
        capabilityState,
        routePassed,
        humanGatePassed,
        directRenderingPassed,
        result.OutputText,
        "synthetic_generation",
        "not_eligible",
        "evaluation_only_not_observation_evidence_or_batch_003_count");
}

static void ValidateInput(IReadOnlyList<EvaluationCase> cases)
{
    if (cases.Count != 150 || cases.Select(item => item.CaseId).Distinct(StringComparer.OrdinalIgnoreCase).Count() != 150)
    {
        throw new InvalidDataException("v0.2-rc.1 must contain 150 cases with unique case IDs.");
    }

    if (cases.Any(item => item.RecordOrigin != "synthetic_generation" || item.FormalEligibility != "not_eligible"))
    {
        throw new InvalidDataException("All v0.2-rc.1 records must remain synthetic_generation and not_eligible.");
    }

    CheckCount(cases, item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.GeneralTranslation, 70, "general_translation route");
    CheckCount(cases, item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.SemanticRendering, 10, "semantic_rendering route");
    CheckCount(cases, item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.Hybrid, 39, "hybrid route");
    CheckCount(cases, item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.HumanReview, 31, "human_review route");
    CheckCount(cases, item => item.EvaluationAxes.SemanticExpectation.Mode == "required", 15, "required semantic mode");
    CheckCount(cases, item => item.EvaluationAxes.SemanticExpectation.Mode == "optional", 1, "optional semantic mode");
    CheckCount(cases, item => item.EvaluationAxes.SemanticExpectation.Mode == "candidate_only", 64, "candidate_only semantic mode");
    CheckCount(cases, item => item.EvaluationAxes.SemanticExpectation.Mode == "forbidden", 70, "forbidden semantic mode");
}

static void ValidateResults(IReadOnlyList<ComponentEvaluationResult> results)
{
    ComponentEvaluationResult[] failures = results
        .Where(item => !item.RoutePassed || !item.SemanticPolicyPassed || !item.HumanGatePassed || !item.DirectRenderingPassed)
        .ToArray();
    if (failures.Length > 0)
    {
        string detail = string.Join(
            "; ",
            failures.Take(12).Select(item =>
                $"{item.CaseId}[route={item.RoutePassed},policy={item.SemanticPolicyPassed},gate={item.HumanGatePassed},render={item.DirectRenderingPassed}; observed={string.Join(',', item.ObservedConceptIds)}]"));
        throw new InvalidDataException(
            $"Component evaluation acceptance checks failed ({failures.Length}); no result artifact was written. {detail}");
    }

    CheckCount(results, item => item.ExpectedProcessingRoute == ChatProcessingRoutes.SemanticRendering && item.CapabilityState == "available_rendering", 10, "available direct semantic rendering");
    CheckCount(results, item => item.ExpectedProcessingRoute == ChatProcessingRoutes.HumanReview && item.HumanGatePassed, 31, "human-review gates");
    CheckCount(results, item => item.ExpectedProcessingRoute == ChatProcessingRoutes.Hybrid && item.CapabilityState == "not_exercised_missing_capability", 39, "hybrid unavailable capability states");
    CheckCount(results, item => item.ExpectedProcessingRoute == ChatProcessingRoutes.GeneralTranslation && item.CapabilityState == "not_exercised_missing_capability", 70, "general unavailable capability states");
    CheckCount(results, item => item.ExpectedSemanticMode == "forbidden" && item.EffectiveConceptIds.Count == 0, 70, "forbidden effective concept suppression");
    CheckCount(results, item => item.ExpectedSemanticMode == "candidate_only" && item.EffectiveConceptIds.Count == 0, 64, "candidate-only effective concept suppression");
}

static void CheckCount<T>(IReadOnlyList<T> records, Func<T, bool> predicate, int expected, string label)
{
    int actual = records.Count(predicate);
    if (actual != expected)
    {
        throw new InvalidDataException($"Expected {expected} {label}; found {actual}.");
    }
}

static string BuildReport(string inputHash, IReadOnlyList<ComponentEvaluationResult> results)
{
    int CountRoute(string route) => results.Count(item => item.ExpectedProcessingRoute == route);
    int PassedRoute(string route) => results.Count(item => item.ExpectedProcessingRoute == route && item.RoutePassed);
    int CountMode(string mode) => results.Count(item => item.ExpectedSemanticMode == mode);
    int PassedMode(string mode) => results.Count(item => item.ExpectedSemanticMode == mode && item.SemanticPolicyPassed);
    var report = new StringBuilder();
    report.AppendLine("# Synthetic evaluation v0.2-rc.1 component run");
    report.AppendLine();
    report.AppendLine("Status: passed");
    report.AppendLine("Scope: direct raw_text input; OCR is not exercised.");
    report.AppendLine();
    report.AppendLine("## Frozen input boundary");
    report.AppendLine();
    report.AppendLine($"- Cases: {results.Count}/150");
    report.AppendLine($"- RC SHA-256: `{inputHash}`");
    report.AppendLine("- Every result remains `record_origin=synthetic_generation` and `formal_eligibility=not_eligible`.");
    report.AppendLine("- This run is neither Observation, Evidence, Review nor a batch-003 count.");
    report.AppendLine();
    report.AppendLine("## Processing route baseline");
    report.AppendLine();
    report.AppendLine("| Route | Expected | Passed |");
    report.AppendLine("| --- | ---: | ---: |");
    foreach (string route in new[] { ChatProcessingRoutes.GeneralTranslation, ChatProcessingRoutes.SemanticRendering, ChatProcessingRoutes.Hybrid, ChatProcessingRoutes.HumanReview })
    {
        report.AppendLine($"| `{route}` | {CountRoute(route)} | {PassedRoute(route)} |");
    }

    report.AppendLine();
    report.AppendLine("## Semantic policy");
    report.AppendLine();
    report.AppendLine("| Mode | Expected | Passed | Effective formal concepts |");
    report.AppendLine("| --- | ---: | ---: | ---: |");
    foreach (string mode in new[] { "required", "optional", "candidate_only", "forbidden" })
    {
        int effectiveConcepts = results.Where(item => item.ExpectedSemanticMode == mode).Sum(item => item.EffectiveConceptIds.Count);
        report.AppendLine($"| `{mode}` | {CountMode(mode)} | {PassedMode(mode)} | {effectiveConcepts} |");
    }

    report.AppendLine();
    report.AppendLine("## Gate and capability separation");
    report.AppendLine();
    report.AppendLine($"- Direct semantic_rendering: {results.Count(item => item.ExpectedProcessingRoute == ChatProcessingRoutes.SemanticRendering && item.DirectRenderingPassed)}/10; verified renderings are available.");
    report.AppendLine($"- Forbidden policy: {results.Count(item => item.ExpectedSemanticMode == "forbidden" && item.EffectiveConceptIds.Count == 0)}/70 with no effective formal Concept.");
    report.AppendLine($"- Negative controls: {results.Count(item => item.ContentClass == "negative_control" && item.EffectiveConceptIds.Count == 0)}/11 with no effective formal Concept, including the `care about` boundaries.");
    report.AppendLine($"- Human-review gate: {results.Count(item => item.ExpectedProcessingRoute == ChatProcessingRoutes.HumanReview && item.HumanGatePassed)}/31; no final automatic output was emitted.");
    report.AppendLine($"- Hybrid: {results.Count(item => item.ExpectedProcessingRoute == ChatProcessingRoutes.Hybrid && item.CapabilityState == "not_exercised_missing_capability")}/39 are correctly marked missing capability, not data errors.");
    report.AppendLine($"- General translation: {results.Count(item => item.ExpectedProcessingRoute == ChatProcessingRoutes.GeneralTranslation && item.CapabilityState == "not_exercised_missing_capability")}/70 are correctly marked missing capability, not translation-quality failures.");
    report.AppendLine();
    report.AppendLine("## Available versus missing modules");
    report.AppendLine();
    report.AppendLine("| Module | State |");
    report.AppendLine("| --- | --- |");
    report.AppendLine("| semantic_rendering | available: 10 direct route cases completed with verified rendering |");
    report.AppendLine("| human_review | available: 31 policy-required routes gated before automatic output |");
    report.AppendLine("| general_translation | not_exercised_missing_capability: provider unavailable |");
    report.AppendLine("| hybrid | not_exercised_missing_capability: provider/aggregator unavailable |");
    report.AppendLine("| OCR | not exercised: the input is direct raw_text |");
    report.AppendLine();
    report.AppendLine("No exact translation total is calculated: v0.2 separates route, semantic policy, gate, available rendering and missing capability.");
    return report.ToString();
}

static string ComputeSha256(string path)
{
    using FileStream stream = File.OpenRead(path);
    return Convert.ToHexString(SHA256.HashData(stream));
}

public sealed record EvaluationCase(
    [property: JsonPropertyName("case_id")] string CaseId,
    [property: JsonPropertyName("channel")] string Channel,
    [property: JsonPropertyName("source_locale")] string SourceLocale,
    [property: JsonPropertyName("raw_text")] string RawText,
    [property: JsonPropertyName("target_locale")] string TargetLocale,
    [property: JsonPropertyName("content_class")] string ContentClass,
    [property: JsonPropertyName("record_origin")] string RecordOrigin,
    [property: JsonPropertyName("formal_eligibility")] string FormalEligibility,
    [property: JsonPropertyName("evaluation_axes")] EvaluationAxes EvaluationAxes);

public sealed record EvaluationAxes(
    [property: JsonPropertyName("processing_route")] string ProcessingRoute,
    [property: JsonPropertyName("semantic_expectation")] SemanticExpectation SemanticExpectation);

public sealed record SemanticExpectation(
    [property: JsonPropertyName("mode")] string Mode,
    [property: JsonPropertyName("concept_ids")] IReadOnlyList<string>? ConceptIds,
    [property: JsonPropertyName("forbidden_concept_ids")] IReadOnlyList<string>? ForbiddenConceptIds);

public sealed record ComponentEvaluationResult(
    string RecordType,
    string SchemaVersion,
    string CaseId,
    string RawText,
    string ContentClass,
    string OcrStatus,
    string ExpectedProcessingRoute,
    string ActualProcessingRoute,
    string ExpectedSemanticMode,
    bool SemanticPolicyPassed,
    bool FormalMatchesSuppressed,
    IReadOnlyList<string> SemanticPolicyViolations,
    IReadOnlyList<string> ObservedConceptIds,
    IReadOnlyList<string> EffectiveConceptIds,
    IReadOnlyList<string?> RenderingIds,
    string RuntimeStatus,
    string CapabilityState,
    bool RoutePassed,
    bool HumanGatePassed,
    bool DirectRenderingPassed,
    string? OutputText,
    string RecordOrigin,
    string FormalEligibility,
    string DataBoundary);
