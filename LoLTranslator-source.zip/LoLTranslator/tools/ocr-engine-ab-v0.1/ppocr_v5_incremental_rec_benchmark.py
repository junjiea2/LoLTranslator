"""Benchmark server recognition on one newly detected chat row at a time."""
import json, os, re, sys, time
from pathlib import Path
from PIL import Image
import numpy as np
from paddleocr import PaddleOCR, TextRecognition
from paddlex.inference.pipelines.components.common.crop_image_regions import CropByPolys

if len(sys.argv) != 2 or not os.path.isabs(sys.argv[1]) or not os.path.isfile(sys.argv[1]):
    raise SystemExit("pass one existing absolute screenshot path")

def norm(value):
    return re.sub(r"[^a-z0-9]", "", value.lower())

def recognized_text(result):
    data = result.json if hasattr(result, "json") else result
    if callable(data):
        data = data()
    payload = data.get("res", data)
    return payload.get("rec_text", "")

device = os.environ.get("OCR_BENCHMARK_DEVICE", "cpu")

with Image.open(sys.argv[1]) as source:
    width, height = source.size
    bounds = (int(width * 0.058), int(height * 0.575),
              int(width * 0.305), int(height * 0.735))
    frame = np.asarray(source.crop(bounds).convert("RGB"))

# Reuse exactly the same detected polygons and perspective crop operation as
# Paddle's full OCR pipeline. The first and third rows are non-player/system
# rows; OCR test and the long final message are indices 4 and 7.
detector = PaddleOCR(
    device=device,
    text_detection_model_name="PP-OCRv5_mobile_det",
    text_recognition_model_name="en_PP-OCRv5_mobile_rec",
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=False,
)
detected = list(detector.predict(frame))[0].json["res"]
polys = sorted(detected["dt_polys"], key=lambda poly: min(point[1] for point in poly))
if len(polys) < 8:
    raise RuntimeError(f"expected at least 8 fixture rows, detected {len(polys)}")
cropper = CropByPolys()
short_row = cropper.get_rotate_crop_image(frame, np.asarray(polys[4], dtype=np.float32))
long_row = cropper.get_rotate_crop_image(frame, np.asarray(polys[7], dtype=np.float32))

started = time.perf_counter()
recognizer = TextRecognition(model_name="PP-OCRv5_server_rec", device=device)
init_ms = (time.perf_counter() - started) * 1000

cases = [("ocrtest", short_row), ("whatiswrongwiththisocr", long_row)]
reports = []
for expected, row in cases:
    timings = []
    exact = False
    for _ in range(5):
        started = time.perf_counter()
        results = list(recognizer.predict(row))
        timings.append((time.perf_counter() - started) * 1000)
        text = recognized_text(results[0]) if results else ""
        exact = norm(text).endswith(expected)
    reports.append({
        "expected": expected,
        "runs": 5,
        "exact": exact,
        "first_inference_ms": timings[0],
        "warm_latency_ms": sum(timings[1:]) / 4,
    })

device_label = device.replace(":", "-")
output = Path(__file__).parent / "results" / f"ppocrv5-server-rec-{device_label}.incremental.aggregate.json"
output.parent.mkdir(exist_ok=True)
output.write_text(json.dumps({
    "fixture_id": "temp-user-screenshot-ocr-ab-001",
    "engine": f"ppocrv5_server_rec_{device}_incremental",
    "model_init_ms": init_ms,
    "reports": reports,
    "raw_screenshot": False,
    "raw_ocr": False,
}, indent=2), encoding="utf-8")
print(output)
