using System.Diagnostics;
using System.Text.Json;
using LoLTranslator.App;

if (args.Length != 1 || !Path.IsPathFullyQualified(args[0]) || !File.Exists(args[0]))
{
    Console.Error.WriteLine("Pass one existing absolute screenshot path.");
    return 2;
}

string imagePath = args[0];
string[] expected = ["hi", "hi", "ocr test", "can you scan this", "yo", "what is wrong with this ocr"];
var reports = new List<object>();
foreach (string engine in new[] { "auto", "en-US" })
{
    var elapsed = new List<long>();
    var recognized = new List<IReadOnlyList<StructuredOcrLine>>();
    for (int run = 0; run < 5; run++)
    {
        var watch = Stopwatch.StartNew();
        OcrRecognitionResult result = await OcrService.RecognizeAsync(imagePath, engine);
        elapsed.Add(watch.ElapsedMilliseconds);
        recognized.Add(result.StructuredLines ?? Array.Empty<StructuredOcrLine>());
    }
    IReadOnlyList<StructuredOcrLine> last = recognized[^1];
    string[] bodies = last.Select(line => ChatMessageEnvelopeExtractor.Extract(line.Text).Body).Select(Normalize).ToArray();
    int matched = expected.Count(item => bodies.Contains(item));
    int duplicates = bodies.GroupBy(item => item).Sum(group => Math.Max(0, group.Count() - 1));
    reports.Add(new {
        fixture_id = "temp-user-screenshot-ocr-ab-001", engine, runs = 5,
        structured_line_count = last.Count,
        line_recall = (double)matched / expected.Length,
        false_extra_lines = Math.Max(0, bodies.Length - matched), duplicate_logical_rows = duplicates,
        body_exact_accuracy = (double)matched / expected.Length,
        cer = (double?)null, wer = (double?)null,
        ocr_test_exact = bodies.Contains("ocr test"), cold_latency_ms = elapsed[0], warm_latency_ms = elapsed.Skip(1).Average(),
        player_field = "excluded_due_privacy"
    });
}
string directory = Path.Combine(AppContext.BaseDirectory, "results");
Directory.CreateDirectory(directory);
string output = Path.Combine(directory, "windows-baseline.aggregate.json");
File.WriteAllText(output, JsonSerializer.Serialize(new { fixture_id = "temp-user-screenshot-ocr-ab-001", screenshot_in_repository = false, reports }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(output);
return 0;

static string Normalize(string value) => string.Concat(value.ToLowerInvariant().Where(char.IsLetterOrDigit));
