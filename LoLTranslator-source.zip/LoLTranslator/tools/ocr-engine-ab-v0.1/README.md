# OCR engine A/B v0.1

Run with a user-supplied **absolute Temp image path**. The runner never copies the image or raw OCR text into this repository. It writes only aggregate metrics and redacted expected bodies.

`dotnet run --project tools/ocr-engine-ab-v0.1/ocr-engine-ab-v0.1.csproj -- "C:\...\image.png"`

Baseline: Windows OCR `auto` and `en-US`, five runs each. PP-OCR adapter is intentionally an external-process boundary and is not installed in the WPF app.

Candidate installation proposal (not executed): PaddlePaddle official Windows GPU/CPU wheel matching the installed CUDA, plus `paddleocr` with PP-OCRv5 mobile model. Expected model/cache footprint is roughly 0.2–0.8 GB before framework dependencies; exact official package version must be approved and installed by the main thread.
