"""Read-only PP-OCRv5 CPU A/B runner. Never copies images or writes raw OCR."""
import json, os, sys, time, re
from collections import Counter
from pathlib import Path
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import numpy as np
from paddleocr import PaddleOCR

if len(sys.argv) not in (2, 3, 4) or not os.path.isabs(sys.argv[1]) or not os.path.isfile(sys.argv[1]):
    raise SystemExit("pass an absolute screenshot path, optional preprocessing variant, and optional recognition model")

image = sys.argv[1]
variant = sys.argv[2] if len(sys.argv) >= 3 else "raw"
recognizer = sys.argv[3] if len(sys.argv) == 4 else "mobile"
device = os.environ.get("OCR_BENCHMARK_DEVICE", "cpu")
if variant not in {"raw", "upscale2", "sharp2", "gray2", "blue2"}:
    raise SystemExit("variant must be raw, upscale2, sharp2, gray2, or blue2")
if recognizer not in {"mobile", "server"}:
    raise SystemExit("recognition model must be mobile or server")
expected = ["hi", "hi", "ocr test", "can you scan this", "yo", "what is wrong with this ocr"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())

def body(text):
    # The final colon belongs to the LoL sender envelope. Keeping only the body
    # prevents timestamps, channel labels and player names from distorting the
    # body-language benchmark.
    return norm(re.split(r"[:：]", text)[-1])

def assemble_rows(texts, boxes):
    fragments = []
    for text, box in zip(texts, boxes):
        if len(box) < 4:
            continue
        x1, y1, x2, y2 = map(float, box[:4])
        fragments.append({"text": text, "x": x1, "yc": (y1 + y2) / 2,
                          "height": max(1.0, y2 - y1)})
    rows = []
    for fragment in sorted(fragments, key=lambda item: (item["yc"], item["x"])):
        target = next((row for row in rows if abs(row["yc"] - fragment["yc"])
                       <= max(6.0, 0.55 * max(row["height"], fragment["height"]))), None)
        if target is None:
            rows.append({"yc": fragment["yc"], "height": fragment["height"],
                         "fragments": [fragment]})
        else:
            target["fragments"].append(fragment)
            target["yc"] = sum(item["yc"] for item in target["fragments"]) / len(target["fragments"])
            target["height"] = max(target["height"], fragment["height"])
    return [" ".join(item["text"] for item in sorted(row["fragments"], key=lambda item: item["x"]))
            for row in sorted(rows, key=lambda item: item["yc"])]

def levenshtein(a, b):
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(current[-1] + 1, previous[j] + 1,
                               previous[j - 1] + (ca != cb)))
        previous = current
    return previous[-1]

# This fixture's game chat viewport. Crop only in memory: the source screenshot
# remains in Temp and no derivative image is written to disk.
with Image.open(image) as source:
    # Original fixture is 2560x1440. These normalized bounds isolate the LoL
    # chat rows and exclude both the old translation overlay and the app window.
    width, height = source.size
    bounds = (int(width * 0.058), int(height * 0.575),
              int(width * 0.305), int(height * 0.735))
    crop = source.crop(bounds).convert("RGB")
    if variant == "upscale2":
        crop = crop.resize((crop.width * 2, crop.height * 2), Image.Resampling.LANCZOS)
    elif variant == "sharp2":
        crop = crop.resize((crop.width * 2, crop.height * 2), Image.Resampling.LANCZOS)
        crop = crop.filter(ImageFilter.UnsharpMask(radius=1.0, percent=180, threshold=2))
    elif variant == "gray2":
        crop = ImageOps.autocontrast(crop.convert("L"), cutoff=1).convert("RGB")
        crop = crop.resize((crop.width * 2, crop.height * 2), Image.Resampling.LANCZOS)
    elif variant == "blue2":
        blue = Image.fromarray(np.asarray(crop)[:, :, 2])
        crop = ImageOps.autocontrast(blue, cutoff=1).convert("RGB")
        crop = crop.resize((crop.width * 2, crop.height * 2), Image.Resampling.LANCZOS)
    frame = np.asarray(crop)

# Explicit mobile detection + English mobile recognition, CPU only.
start = time.perf_counter()
ocr = PaddleOCR(
    lang="en",
    ocr_version="PP-OCRv5",
    device=device,
    text_detection_model_name="PP-OCRv5_mobile_det",
    text_recognition_model_name=("en_PP-OCRv5_mobile_rec" if recognizer == "mobile"
                                 else "PP-OCRv5_server_rec"),
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=False,
)
init_ms = (time.perf_counter() - start) * 1000
runs, last_rows, last_fragment_count, last_row_count, last_sender_rows = [], [], 0, 0, 0
for _ in range(5):
    start = time.perf_counter()
    result = list(ocr.predict(frame))
    elapsed = (time.perf_counter() - start) * 1000
    assembled = []
    fragment_count = 0
    row_count = 0
    sender_rows = 0
    for page in result:
        data = page.json if hasattr(page, "json") else page
        if callable(data): data = data()
        if isinstance(data, str): data = json.loads(data)
        payload = data.get("res", data) if isinstance(data, dict) else {}
        texts = payload.get("rec_texts", []) if isinstance(payload, dict) else []
        boxes = payload.get("rec_boxes", []) if isinstance(payload, dict) else []
        rows = assemble_rows(texts, boxes)
        fragment_count += len(texts)
        row_count += len(rows)
        sender_rows += sum(1 for row in rows if len(re.findall(r"[:：]", row)) >= 2)
        assembled.extend(norm(row) for row in rows if norm(row))
    last_rows = assembled
    last_fragment_count = fragment_count
    last_row_count = row_count
    last_sender_rows = sender_rows
    runs.append(elapsed)
expected_norm = [norm(item) for item in expected]
remaining = list(last_rows)
distances = []
expected_diagnostics = []
# Match longer messages first. Compare against each row's suffix so imperfect
# sender delimiters do not contaminate the message-body score.
for item in sorted(expected_norm, key=len, reverse=True):
    if not remaining:
        distances.append(len(item))
        expected_diagnostics.append({"expected": item, "edit_distance": len(item), "exact": False})
        continue
    row_distances = [levenshtein(item, row[-len(item):]) for row in remaining]
    best_index = min(range(len(remaining)), key=lambda i: row_distances[i])
    distances.append(row_distances[best_index])
    expected_diagnostics.append({"expected": item, "edit_distance": row_distances[best_index],
                                 "exact": row_distances[best_index] == 0})
    remaining.pop(best_index)
matched = sum(distance == 0 for distance in distances)
edit_distance = sum(distances)
cer_denominator = sum(len(item) for item in expected_norm)
row_counts = Counter(last_rows)
report = {"fixture_id":"temp-user-screenshot-ocr-ab-001","engine":f"ppocrv5_{recognizer}_rec_{device}","preprocessing":variant,"runs":5,
 "line_recall":matched/len(expected),"false_extra_lines":max(0,len(last_rows)-matched),
 "duplicate_logical_rows":sum(max(0, count-1) for count in row_counts.values()),
 "body_exact_accuracy":matched/len(expected),"cer":edit_distance/cer_denominator,"wer":None,
 "ocr_test_exact":any(row.endswith(norm("ocr test")) for row in last_rows),"cold_latency_ms":runs[0]+init_ms,
 "warm_latency_ms":sum(runs[1:])/4,"player_field":"excluded_due_privacy",
 "detected_fragments":last_fragment_count,"assembled_rows":last_row_count,
 "rows_with_sender_delimiter":last_sender_rows,
 "expected_diagnostics":expected_diagnostics,
 "raw_screenshot":False,"raw_ocr":False}
out = Path(__file__).parent / "results"
out.mkdir(exist_ok=True)
device_label = device.replace(":", "-")
output = out / f"ppocrv5-{recognizer}-rec-{device_label}.{variant}.aggregate.json"
output.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(output)
