using System.Security.Cryptography;
using System.Text.Encodings.Web;
using System.Text.Json;
using LoLTranslator.App;
using SlangGraph.Core;

const string CandidatePathRelative = "data/packs/lol/domain-lexicon.v0.1.candidate.2.jsonl";
const string OutputRelative = "data/collection/lol/domain-lexicon-v0.1/runs/domain-lexicon.v0.1.candidate.2-runtime-compatibility.jsonl";
const string ExpectedHash = "4DEE3098C10B555E367AA44FC2924A3BB4C9D96155CA7FB455343A1D64EAEC8B";

if (args.Length != 1 || args[0] != "--candidate2-no-model-shadow")
    throw new ArgumentException("Explicit no-model candidate.2 opt-in required: --candidate2-no-model-shadow");

string root = Directory.GetCurrentDirectory();
string path = Path.Combine(root, CandidatePathRelative.Replace('/', Path.DirectorySeparatorChar));
string outputPath = Path.Combine(root, OutputRelative.Replace('/', Path.DirectorySeparatorChar));
string hash = Sha256(path);
if (!string.Equals(hash, ExpectedHash, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Frozen candidate.2 hash mismatch.");

var failures = new List<string>();
var entryNodes = new List<JsonElement>();
JsonElement? header = null;
int lineCount = 0;
foreach (string line in File.ReadLines(path))
{
    lineCount++;
    using JsonDocument document = JsonDocument.Parse(line);
    JsonElement rootElement = document.RootElement.Clone();
    string? type = Text(rootElement, "record_type");
    if (type == "domain_lexicon")
    {
        if (header is not null) failures.Add("duplicate_header"); else header = rootElement;
    }
    else if (type == "lexicon_entry") entryNodes.Add(rootElement);
    else failures.Add($"unsupported_record_type:{type ?? "missing"}");
}

if (lineCount != 500 || header is null || entryNodes.Count != 499) failures.Add("record_count_expected_500_header_1_entries_499");
if (header is not null) ValidateHeader(header.Value, failures);

var canonicalIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var aliasIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var renderingIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var sourceIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var reviewReferences = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var conflictAliases = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
var conflictSeverities = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
var typeCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
int aliasCount = 0, renderingCount = 0, candidateStatusFailures = 0;
foreach (JsonElement entry in entryNodes)
{
    string? canonical = Required(entry, "canonical_id", failures);
    if (canonical is not null && !canonicalIds.Add(canonical)) failures.Add($"duplicate_canonical_id:{canonical}");
    string? kind = Required(entry, "kind", failures);
    string? entityType = Required(entry, "type", failures);
    if (entityType is not null) Increment(typeCounts, entityType);
    RequireArray(entry, "scope", failures); RequireArray(entry, "context_scope", failures); RequireArray(entry, "scope_tags", failures);
    RequireObject(entry, "canonical_names", failures); RequireArray(entry, "source_ids", failures); RequireObject(entry, "provenance", failures);
    ValidatePatch(entry, failures, "entry");
    if (!CandidateOnly(entry)) candidateStatusFailures++;
    var entrySourceSet = entry.TryGetProperty("source_ids", out JsonElement entrySources) && entrySources.ValueKind == JsonValueKind.Array
        ? entrySources.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String).Select(item => item.GetString()!).ToHashSet(StringComparer.OrdinalIgnoreCase)
        : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    foreach (string source in entrySourceSet) sourceIds.Add(source);
    if (!entry.TryGetProperty("provenance", out JsonElement entryProvenance) || !entryProvenance.TryGetProperty("source_ids", out JsonElement provenanceSources) ||
        provenanceSources.ValueKind != JsonValueKind.Array || !provenanceSources.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String).Select(item => item.GetString()!).ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(entrySourceSet))
        failures.Add($"entry_provenance_sources_incomplete:{canonical}");
    if (entry.TryGetProperty("review_issue_ids", out JsonElement entryIssues) && entryIssues.ValueKind == JsonValueKind.Array)
        foreach (JsonElement issue in entryIssues.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String)) reviewReferences.Add(issue.GetString()!);

    if (!entry.TryGetProperty("aliases", out JsonElement aliases) || aliases.ValueKind != JsonValueKind.Array) { failures.Add($"aliases_missing:{canonical}"); continue; }
    foreach (JsonElement alias in aliases.EnumerateArray())
    {
        aliasCount++;
        string? aliasId = Required(alias, "alias_id", failures);
        if (aliasId is not null && !aliasIds.Add(aliasId)) failures.Add($"duplicate_alias_id:{aliasId}");
        foreach (string field in new[] { "surface", "normalized", "locale", "register", "status", "review_status", "formal_eligibility", "conflict_status", "match_policy" }) Required(alias, field, failures);
        RequireArray(alias, "scope", failures); RequireArray(alias, "source_ids", failures); ValidatePatch(alias, failures, "alias");
        if (!CandidateOnly(alias)) candidateStatusFailures++;
        if (!alias.TryGetProperty("source_ids", out JsonElement aliasSources) || aliasSources.ValueKind != JsonValueKind.Array ||
            !aliasSources.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String).Select(item => item.GetString()!).All(entrySourceSet.Contains))
            failures.Add($"alias_source_reference_invalid:{aliasId}");
        if (alias.TryGetProperty("conflict_ids", out JsonElement conflictIds) && conflictIds.ValueKind == JsonValueKind.Array && conflictIds.GetArrayLength() > 0)
        {
            if (Text(alias, "conflict_status") != "requires_review" || Text(alias, "match_policy") != "fail_closed") failures.Add($"conflict_not_fail_closed:{aliasId}");
            foreach (JsonElement conflictId in conflictIds.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String))
            {
                string id = conflictId.GetString()!;
                conflictAliases.TryAdd(id, alias);
            }
            if (alias.TryGetProperty("ambiguity", out JsonElement ambiguity) && ambiguity.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement item in ambiguity.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.Object))
                {
                    string? id = Text(item, "conflict_id");
                    string? severity = Text(item, "severity");
                    if (id is not null && severity is not null)
                    {
                        if (conflictSeverities.TryGetValue(id, out string? prior) && !string.Equals(prior, severity, StringComparison.OrdinalIgnoreCase)) failures.Add($"conflict_severity_mismatch:{id}");
                        conflictSeverities[id] = severity;
                    }
                }
            }
        }
    }

    if (!entry.TryGetProperty("localized_renderings", out JsonElement renderings) || renderings.ValueKind != JsonValueKind.Array) { failures.Add($"renderings_missing:{canonical}"); continue; }
    foreach (JsonElement rendering in renderings.EnumerateArray())
    {
        renderingCount++;
        string? renderingId = Required(rendering, "rendering_id", failures);
        if (renderingId is not null && !renderingIds.Add(renderingId)) failures.Add($"duplicate_rendering_id:{renderingId}");
        foreach (string field in new[] { "target_locale", "text", "source_id", "status", "review_status", "formal_eligibility" }) Required(rendering, field, failures);
        if (!CandidateOnly(rendering)) candidateStatusFailures++;
        string? renderingSource = Text(rendering, "source_id");
        if (renderingSource is null || !entrySourceSet.Contains(renderingSource) || !rendering.TryGetProperty("provenance", out JsonElement renderingProvenance) || Text(renderingProvenance, "source_id") != renderingSource)
            failures.Add($"rendering_source_reference_invalid:{renderingId}");
    }
}

if (aliasCount != 1811) failures.Add($"alias_count:{aliasCount}");
if (renderingCount != 998) failures.Add($"rendering_count:{renderingCount}");
if (candidateStatusFailures != 0) failures.Add($"formal_status_leak:{candidateStatusFailures}");
if (typeCounts.GetValueOrDefault("champion") != 173 || typeCounts.GetValueOrDefault("item") != 316 || typeCounts.GetValueOrDefault("summoner_spell") != 10) failures.Add("type_counts_invalid");
// Data's per-alias severity names the conditional class "warning". The
// header's 54 blocker + 71 conditional contract is checked against that
// explicit source vocabulary without reclassifying any candidate record.
if (conflictAliases.Count != 125 || conflictSeverities.Count != 125 || conflictSeverities.Count(pair => pair.Value == "blocker") != 54 || conflictSeverities.Count(pair => pair.Value == "warning") != 71) failures.Add("conflict_counts_or_classes_invalid");

var headerConflictIds = StringArray(header!.Value.GetProperty("conflict_policy"), "conflict_ids");
var headerIssueIds = StringArray(header.Value.GetProperty("review_policy"), "issue_ids");
var headerAmbiguityIds = StringArray(header.Value.GetProperty("review_policy"), "ambiguity_issue_ids");
if (headerConflictIds.Count != 125 || !headerConflictIds.All(conflictAliases.ContainsKey)) failures.Add("header_conflict_references_incomplete");
if (headerIssueIds.Count != 28 || headerAmbiguityIds.Count != 23 || !headerAmbiguityIds.All(headerIssueIds.Contains) || !reviewReferences.All(headerIssueIds.Contains)) failures.Add("header_review_references_incomplete");

DomainLexicon lexicon = DomainLexiconLoader.LoadJsonl(path);
var index = new DomainLexiconIndex(lexicon);
var representativeRecords = new List<RepresentativeRecord>();
foreach (DomainLexiconEntry entry in lexicon.Entries.GroupBy(item => item.Type, StringComparer.OrdinalIgnoreCase).Select(group => group.OrderBy(item => item.CanonicalId, StringComparer.OrdinalIgnoreCase).First()))
{
    DomainLexiconAlias alias = entry.Aliases.First(item => string.Equals(item.Locale, "en-US", StringComparison.OrdinalIgnoreCase));
    DomainLexiconMatchContext context = Context(entry, "16.15.1");
    DomainLexiconMatchResult defaultResult = index.Match(alias.Surface, "en-US", context);
    DomainLexiconMatchResult shadow = index.Match(alias.Surface, "en-US", context, new DomainLexiconMatchOptions(true));
    DomainLexiconMatchResult expired = index.Match(alias.Surface, "en-US", context with { Patch = "16.14.1" }, new DomainLexiconMatchOptions(true));
    DomainLexiconMatchResult unknown = index.Match(alias.Surface, "en-US", context with { Patch = null }, new DomainLexiconMatchOptions(true));
    DomainLexiconMatchResult nonGame = index.Match(alias.Surface, "en-US", new DomainLexiconMatchContext(null, null, null, "16.15.1", Array.Empty<string>()), new DomainLexiconMatchOptions(true));
    DomainLexiconRenderedEntry zh = index.RenderShadow(entry.CanonicalId, "zh-CN");
    DomainLexiconRenderedEntry fallback = index.RenderShadow(entry.CanonicalId, "en-GB");
    bool pass = defaultResult.FormalMatches.Count == 0 && defaultResult.CandidateShadowMatches.Count == 0 && shadow.FormalMatches.Count == 0 && shadow.CandidateShadowMatches.Count == 1 && expired.CandidateShadowMatches.Count == 0 && unknown.CandidateShadowMatches.Count == 0 && nonGame.CandidateShadowMatches.Count == 0;
    representativeRecords.Add(new RepresentativeRecord("representative", entry.CanonicalId, entry.Type, alias.Surface, shadow.CandidateShadowMatches.Count, defaultResult.FormalMatches.Count, zh.ResolvedLocale, fallback.ResolvedLocale, pass));
    if (!pass) failures.Add($"representative_runtime:{entry.CanonicalId}");
}

var conflictRecords = new List<ConflictRecord>();
foreach ((string conflictId, JsonElement alias) in conflictAliases.OrderBy(pair => pair.Key, StringComparer.OrdinalIgnoreCase))
{
    string surface = Text(alias, "surface")!;
    string locale = Text(alias, "locale")!;
    string canonical = entryNodes.First(entry => entry.GetProperty("aliases").EnumerateArray().Any(item => Text(item, "alias_id") == Text(alias, "alias_id"))).GetProperty("canonical_id").GetString()!;
    DomainLexiconEntry entry = lexicon.Entries.Single(item => item.CanonicalId == canonical);
    DomainLexiconMatchResult result = index.Match(surface, locale, Context(entry, "16.15.1"), new DomainLexiconMatchOptions(true));
    bool pass = result.FormalMatches.Count == 0 && result.CandidateShadowMatches.Count == 0 && result.AmbiguityReasons.Count > 0;
    conflictRecords.Add(new ConflictRecord("conflict", conflictId, conflictSeverities[conflictId], Text(alias, "alias_id")!, result.FormalMatches.Count, result.CandidateShadowMatches.Count, result.AmbiguityReasons, pass));
    if (!pass) failures.Add($"conflict_runtime:{conflictId}");
}

// This is the only end-to-end bridge invocation in the candidate.2 process.
// Its local recording provider proves candidate diagnostics do not introduce
// locks, route overrides, or a changed general-translation input. It is not a
// model provider and cannot contact Qwen.
DomainLexiconEntry bridgeEntry = lexicon.Entries.First(entry => entry.Aliases.Any(alias => string.Equals(alias.Locale, "en-US", StringComparison.OrdinalIgnoreCase)));
DomainLexiconAlias bridgeAlias = bridgeEntry.Aliases.First(alias => string.Equals(alias.Locale, "en-US", StringComparison.OrdinalIgnoreCase));
var recorder = new Candidate2RecordingProvider();
var semanticService = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
var orchestrator = new ChatProcessingRouteOrchestrator(semanticService, recorder);
var processor = new DomainLexiconShadowProcessor(index, DomainLexiconShadowProfile.ExplicitTestOnly(includeCandidateShadow: true), orchestrator);
DomainLexiconShadowResult bridge = processor.Process(
    new ChatProcessingRequest(bridgeAlias.Surface, "en-US", "zh-CN", new ShadowMatchContextOption("candidate2-test", "lol.global", "in_game_chat"),
        new ChatProcessingPolicy(ChatProcessingRoutes.GeneralTranslation, new ChatSemanticPolicy("optional", Array.Empty<string>(), Array.Empty<string>()))),
    Context(bridgeEntry, "16.15.1"));
bool bridgePassed = bridge.Lexicon.FormalMatches.Count == 0 && bridge.Lexicon.CandidateShadowMatches.Count == 1 &&
    bridge.LexiconLockedSpans.Count == 0 && !bridge.ForcedHybridForFormalLexicon &&
    bridge.Processing.ProcessingRoute == ChatProcessingRoutes.GeneralTranslation && recorder.LastInput == bridgeAlias.Surface;
if (!bridgePassed) failures.Add("candidate_shadow_bridge_changed_processing");

string status = failures.Count == 0 ? "compatible" : "incompatible";
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
var json = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
var output = new List<object>
{
    new RunHeader("domain_lexicon_candidate2_runtime_compatibility", "0.1", DateTimeOffset.UtcNow, CandidatePathRelative, hash, "no_model_candidate_shadow_only", status, "candidate.1_not_loaded"),
    new SummaryRecord("summary", lineCount, lexicon.Entries.Count, aliasCount, renderingCount, typeCounts, conflictAliases.Count, conflictSeverities.Count(pair => pair.Value == "blocker"), conflictSeverities.Count(pair => pair.Value == "warning"), headerAmbiguityIds.Count, headerIssueIds.Count, candidateStatusFailures, failures),
    new BridgeRecord("candidate_shadow_bridge", bridge.Lexicon.CandidateShadowMatches.Count, bridge.LexiconLockedSpans.Count, bridge.ForcedHybridForFormalLexicon, bridge.Processing.ProcessingRoute, recorder.CallCount, 0, bridgePassed)
};
output.AddRange(representativeRecords); output.AddRange(conflictRecords);
File.WriteAllLines(outputPath, output.Select(item => JsonSerializer.Serialize(item, json)));
Console.WriteLine($"Candidate.2 SHA-256: {hash}");
Console.WriteLine($"Direct loader: {lexicon.Entries.Count} entries, {aliasCount} aliases, {renderingCount} renderings");
Console.WriteLine($"Conflicts: {conflictAliases.Count} ({conflictSeverities.Count(pair => pair.Value == "blocker")} blocker, {conflictSeverities.Count(pair => pair.Value == "warning")} conditional/warning), runtime failures {conflictRecords.Count(item => !item.Passed)}");
Console.WriteLine($"Compatibility: {status}; Qwen invocations 0; candidate.1 not loaded");
Console.WriteLine($"Output: {OutputRelative}");
return status == "compatible" ? 0 : 1;

static void ValidateHeader(JsonElement header, ICollection<string> failures)
{
    foreach (string field in new[] { "schema_version", "lexicon_id", "lexicon_version", "domain_id", "status", "formal_eligibility", "provenance", "conflict_policy", "review_policy" })
        if (!header.TryGetProperty(field, out _)) failures.Add($"header_missing:{field}");
    if (Text(header, "formal_eligibility") != "candidate_only" || Text(header, "status") != "draft") failures.Add("header_formal_status_invalid");
}
static void ValidatePatch(JsonElement value, ICollection<string> failures, string scope)
{
    if (!value.TryGetProperty("patch_validity", out JsonElement patch) || patch.ValueKind != JsonValueKind.Object || Text(patch, "from") != "16.15.1" || Text(patch, "to") != "16.15.1") failures.Add($"patch_invalid:{scope}");
}
static bool CandidateOnly(JsonElement item) => Text(item, "status") == "pending" && Text(item, "review_status") == "pending" && Text(item, "formal_eligibility") == "candidate_only";
static string? Required(JsonElement item, string property, ICollection<string> failures) { string? value = Text(item, property); if (string.IsNullOrWhiteSpace(value)) failures.Add($"missing:{property}"); return value; }
static void RequireArray(JsonElement item, string property, ICollection<string> failures) { if (!item.TryGetProperty(property, out JsonElement value) || value.ValueKind != JsonValueKind.Array || value.GetArrayLength() == 0) failures.Add($"array_missing:{property}"); }
static void RequireObject(JsonElement item, string property, ICollection<string> failures) { if (!item.TryGetProperty(property, out JsonElement value) || value.ValueKind != JsonValueKind.Object) failures.Add($"object_missing:{property}"); }
static string? Text(JsonElement item, string property) => item.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.String ? value.GetString() : null;
static HashSet<string> StringArray(JsonElement item, string property) => item.GetProperty(property).EnumerateArray().Where(value => value.ValueKind == JsonValueKind.String).Select(value => value.GetString()!).ToHashSet(StringComparer.OrdinalIgnoreCase);
static void Increment(IDictionary<string, int> dictionary, string key) => dictionary[key] = dictionary.TryGetValue(key, out int count) ? count + 1 : 1;
static DomainLexiconMatchContext Context(DomainLexiconEntry entry, string? patch) => new(null, null, null, patch, entry.ContextScopes.SelectMany(scope => scope.Tags ?? Array.Empty<string>()).ToArray());
static string Sha256(string value) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(value)));

sealed record RunHeader(string RecordType, string SchemaVersion, DateTimeOffset GeneratedAt, string CandidatePath, string CandidateSha256, string ExecutionMode, string CompatibilityStatus, string Candidate1LoadState);
sealed record SummaryRecord(string RecordType, int Lines, int Entries, int Aliases, int Renderings, IReadOnlyDictionary<string, int> TypeCounts, int ConflictIds, int BlockerConflicts, int ConditionalConflicts, int AmbiguityIssues, int ReviewIssues, int FormalStatusLeaks, IReadOnlyList<string> Failures);
sealed record RepresentativeRecord(string RecordType, string CanonicalId, string Type, string AliasSurface, int CandidateMatches, int FormalMatches, string ZhRenderingLocale, string FallbackLocale, bool Passed);
sealed record ConflictRecord(string RecordType, string ConflictId, string Severity, string AliasId, int FormalMatches, int CandidateMatches, IReadOnlyList<string> Reasons, bool Passed);
sealed record BridgeRecord(string RecordType, int CandidateMatches, int ProtectedSpans, bool RouteOverridden, string ProcessingRoute, int LocalTestProviderCalls, int QwenInvocations, bool Passed);

sealed class Candidate2RecordingProvider : IGeneralTranslationProvider
{
    public int CallCount { get; private set; }
    public string? LastInput { get; private set; }
    public GeneralTranslationResult Translate(GeneralTranslationRequest request)
    {
        CallCount++;
        LastInput = request.Text;
        return new GeneralTranslationResult("unavailable", null, "candidate2-recording", "no_model_candidate_shadow_test");
    }
}
