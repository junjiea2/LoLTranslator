using System.Security.Cryptography;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using SlangGraph.Core;

const string CandidateRelativePath = "data/packs/lol/domain-lexicon.v0.1.candidate.1.jsonl";
const string MetadataRelativePath = "data/packs/lol/domain-lexicon.v0.1.candidate.1.metadata.jsonl";
const string OutputRelativePath = "data/collection/lol/domain-lexicon-v0.1/runs/domain-lexicon.v0.1.candidate.1-shadow-compatibility.jsonl";
const string ExpectedCandidateHash = "5804A00B807D6F6E91CB4C60AD1D477D1AAEEF55D466F689C728C6597FD5BF85";

if (args.Length != 1 || args[0] != "--candidate-shadow-diagnostics")
{
    throw new ArgumentException("Explicit no-model opt-in required: --candidate-shadow-diagnostics");
}

string root = Directory.GetCurrentDirectory();
string candidatePath = Path.Combine(root, CandidateRelativePath.Replace('/', Path.DirectorySeparatorChar));
string metadataPath = Path.Combine(root, MetadataRelativePath.Replace('/', Path.DirectorySeparatorChar));
string outputPath = Path.Combine(root, OutputRelativePath.Replace('/', Path.DirectorySeparatorChar));
string candidateHash = ComputeSha256(candidatePath);
if (!string.Equals(candidateHash, ExpectedCandidateHash, StringComparison.OrdinalIgnoreCase))
{
    throw new InvalidDataException($"Frozen candidate SHA-256 mismatch: {candidateHash}");
}

SourcePackStats sourceStats = InspectSourcePack(candidatePath);
DomainLexiconCandidateLoadResult load = DomainLexiconLoader.LoadCandidateSidecarJsonl(metadataPath);
if (load.Lexicon is null)
{
    throw new InvalidDataException("No usable candidate lexicon survived read-only loading.");
}

DomainLexiconIndex index = new(load.Lexicon);
EntryDiagnostic[] representative = BuildRepresentativeDiagnostics(index, load.Lexicon).ToArray();
ConflictDiagnostic[] conflicts = BuildConflictDiagnostics(index, load.Lexicon, load.DeclaredAmbiguities).ToArray();
IsolationDiagnostic isolation = CheckCandidateIsolation(index, load.Lexicon, representative);
string status = DetermineStatus(sourceStats, load, representative, conflicts, isolation);

Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
var json = new JsonSerializerOptions
{
    PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = false
};
var records = new List<object>
{
    new CompatibilityHeader(
        "domain_lexicon_candidate_shadow_compatibility",
        "0.1",
        DateTimeOffset.UtcNow,
        CandidateRelativePath,
        candidateHash,
        MetadataRelativePath,
        ComputeSha256(metadataPath),
        "no_model_candidate_shadow_only",
        status,
        "candidate records are diagnostics only; no protected spans, localized formal output, formal matcher input, or Qwen invocation"),
    new SourcePackDiagnostic("source_pack", sourceStats.TotalLines, sourceStats.ValidLines, sourceStats.InvalidJsonLines, sourceStats.RecordTypes, sourceStats.EntityTypes, sourceStats.InvalidJsonIssues),
    new LoaderDiagnostic("sidecar_loader", load.TotalLines, load.LoadedEntries, load.Issues.Count, load.Issues.GroupBy(issue => issue.Code).ToDictionary(group => group.Key, group => group.Count()), load.MissingFields, load.UnknownFields),
    new CandidateEntryDiagnostic("candidate_entries", load.Lexicon.Entries.GroupBy(entry => entry.Kind).ToDictionary(group => group.Key, group => group.Count()), load.Lexicon.Entries.GroupBy(entry => entry.Type).ToDictionary(group => group.Key, group => group.Count()), load.Lexicon.Entries.GroupBy(entry => entry.FormalEligibility).ToDictionary(group => group.Key, group => group.Count()), CountLocales(load.Lexicon), CountRenderLocales(load.Lexicon), CountPatches(load.Lexicon), CountScopes(load.Lexicon)),
    new IsolationDiagnosticRecord("candidate_isolation", isolation.FormalMatches, isolation.CandidateMatches, isolation.NonGameCandidateMatches, isolation.FormalLocks, isolation.QwenInvocations, isolation.FormalRenderingAffected, isolation.Passed)
};
records.AddRange(load.Issues.Select(issue => new IssueDiagnostic("load_issue", issue.LineNumber, issue.RecordType, issue.Code, issue.Detail)));
records.AddRange(representative);
records.AddRange(conflicts);
File.WriteAllLines(outputPath, records.Select(record => JsonSerializer.Serialize(record, json)));

Console.WriteLine($"Candidate SHA-256: {candidateHash}");
Console.WriteLine($"Source Pack: {sourceStats.ValidLines}/{sourceStats.TotalLines} JSON records; invalid JSON {sourceStats.InvalidJsonLines}");
Console.WriteLine($"Sidecar loader: {load.LoadedEntries}/{load.TotalLines} entries; issues {load.Issues.Count}");
Console.WriteLine($"Candidate ambiguity declarations: {conflicts.Length}; runtime conflict failures: {conflicts.Count(item => !item.Passed)}");
Console.WriteLine($"Candidate isolation: {(isolation.Passed ? "passed" : "failed")}; Qwen invocations: {isolation.QwenInvocations}");
Console.WriteLine($"Compatibility: {status}");
Console.WriteLine($"Output: {OutputRelativePath}");

return status == "incompatible" ? 1 : 0;

static SourcePackStats InspectSourcePack(string path)
{
    int lineNumber = 0;
    int valid = 0;
    var recordTypes = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
    var entityTypes = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
    var invalid = new List<SourceIssue>();
    foreach (string line in File.ReadLines(path))
    {
        lineNumber++;
        if (string.IsNullOrWhiteSpace(line)) continue;
        try
        {
            using JsonDocument document = JsonDocument.Parse(line);
            valid++;
            string recordType = GetString(document.RootElement, "record_type") ?? "<missing>";
            Increment(recordTypes, recordType);
            if (string.Equals(recordType, "entity", StringComparison.OrdinalIgnoreCase))
            {
                Increment(entityTypes, GetString(document.RootElement, "entity_type") ?? "<missing>");
            }
        }
        catch (JsonException exception)
        {
            invalid.Add(new SourceIssue(lineNumber, "invalid_json", exception.Message));
        }
    }

    return new SourcePackStats(lineNumber, valid, invalid.Count, recordTypes, entityTypes, invalid);
}

static IEnumerable<EntryDiagnostic> BuildRepresentativeDiagnostics(DomainLexiconIndex index, DomainLexicon lexicon)
{
    foreach (string type in lexicon.Entries.Select(entry => entry.Type).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(value => value, StringComparer.OrdinalIgnoreCase))
    {
        DomainLexiconEntry? entry = lexicon.Entries
            .Where(candidate => string.Equals(candidate.Type, type, StringComparison.OrdinalIgnoreCase))
            .OrderBy(candidate => candidate.CanonicalId, StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault(candidate => candidate.Aliases.Any(alias => string.Equals(alias.Locale, "en-US", StringComparison.OrdinalIgnoreCase)));
        if (entry is null) continue;
        DomainLexiconAlias alias = entry.Aliases.First(alias => string.Equals(alias.Locale, "en-US", StringComparison.OrdinalIgnoreCase));
        DomainLexiconMatchContext context = ContextFor(entry, "16.15.1");
        DomainLexiconMatchResult en = index.Match(alias.Surface, "en-US", context, new DomainLexiconMatchOptions(true));
        DomainLexiconMatchResult zh = index.Match(alias.Surface, "en-US", context with { Patch = "16.15.1" }, new DomainLexiconMatchOptions(true));
        DomainLexiconMatchResult expired = index.Match(alias.Surface, "en-US", context with { Patch = "16.14.1" }, new DomainLexiconMatchOptions(true));
        DomainLexiconMatchResult nonGame = index.Match(alias.Surface, "en-US", new DomainLexiconMatchContext(null, null, null, "16.15.1", Array.Empty<string>()), new DomainLexiconMatchOptions(true));
        DomainLexiconRenderedEntry exact = index.RenderShadow(entry.CanonicalId, "zh-CN");
        DomainLexiconRenderedEntry fallback = index.RenderShadow(entry.CanonicalId, "en-GB");
        bool found = en.CandidateShadowMatches.Any(match => string.Equals(match.CanonicalId, entry.CanonicalId, StringComparison.OrdinalIgnoreCase));
        yield return new EntryDiagnostic(
            "representative_candidate_shadow",
            entry.CanonicalId,
            type,
            alias.Surface,
            found,
            en.FormalMatches.Count,
            exact.ResolvedLocale,
            exact.UsedFallback,
            fallback.ResolvedLocale,
            fallback.UsedFallback,
            expired.CandidateShadowMatches.Count,
            nonGame.CandidateShadowMatches.Count,
            found && en.FormalMatches.Count == 0 && expired.CandidateShadowMatches.Count == 0 && nonGame.CandidateShadowMatches.Count == 0);
    }
}

static IEnumerable<ConflictDiagnostic> BuildConflictDiagnostics(DomainLexiconIndex index, DomainLexicon lexicon, IReadOnlyList<DomainLexiconDeclaredAmbiguity> declaredAmbiguities)
{
    foreach (DomainLexiconDeclaredAmbiguity ambiguity in declaredAmbiguities.OrderBy(item => item.CanonicalId, StringComparer.OrdinalIgnoreCase).ThenBy(item => item.Surface, StringComparer.OrdinalIgnoreCase))
    {
        // Candidate data intentionally does not promote the declared conflict
        // surface into aliases. It therefore must remain unmatchable rather
        // than being guessed from its note.
        DomainLexiconEntry entry = lexicon.Entries.Single(item => string.Equals(item.CanonicalId, ambiguity.CanonicalId, StringComparison.OrdinalIgnoreCase));
        bool indexed = ambiguity.Surface is not null && entry.Aliases.Any(alias => string.Equals(alias.Surface, ambiguity.Surface, StringComparison.OrdinalIgnoreCase));
        DomainLexiconMatchResult result = ambiguity.Surface is null
            ? new DomainLexiconMatchResult(Array.Empty<DomainLexiconEntityMatch>(), Array.Empty<DomainLexiconEntityMatch>(), Array.Empty<string>())
            : index.Match(ambiguity.Surface, "en-US", ContextFor(entry, "16.15.1"), new DomainLexiconMatchOptions(true));
        bool passed = !indexed && result.FormalMatches.Count == 0 && result.CandidateShadowMatches.Count == 0;
        yield return new ConflictDiagnostic("declared_alias_conflict", entry.CanonicalId, ambiguity.Surface, indexed, result.FormalMatches.Count, result.CandidateShadowMatches.Count, result.AmbiguityReasons, passed);
    }

    foreach (IGrouping<string, (DomainLexiconEntry Entry, DomainLexiconAlias Alias)> group in lexicon.Entries
                 .SelectMany(entry => entry.Aliases.Select(alias => (entry, alias)))
                 .GroupBy(item => $"{item.alias.Locale}\u001f{DomainLexiconTextNormalizer.Normalize(item.alias.Normalized)}", StringComparer.OrdinalIgnoreCase)
                 .Where(group => group.Select(item => item.entry.CanonicalId).Distinct(StringComparer.OrdinalIgnoreCase).Count() > 1)
                 .OrderBy(group => group.Key, StringComparer.OrdinalIgnoreCase))
    {
        (DomainLexiconEntry Entry, DomainLexiconAlias Alias) sample = group.First();
        DomainLexiconMatchResult result = index.Match(sample.Alias.Surface, sample.Alias.Locale, ContextFor(sample.Entry, "16.15.1"), new DomainLexiconMatchOptions(true));
        bool passed = result.FormalMatches.Count == 0 && result.CandidateShadowMatches.Count == 0 && result.AmbiguityReasons.Count > 0;
        yield return new ConflictDiagnostic("same_surface_multiple_canonical_ids", string.Join("|", group.Select(item => item.Entry.CanonicalId).Distinct(StringComparer.OrdinalIgnoreCase)), sample.Alias.Surface, true, result.FormalMatches.Count, result.CandidateShadowMatches.Count, result.AmbiguityReasons, passed);
    }
}

static IsolationDiagnostic CheckCandidateIsolation(DomainLexiconIndex index, DomainLexicon lexicon, IReadOnlyList<EntryDiagnostic> representatives)
{
    EntryDiagnostic? sample = representatives.FirstOrDefault(item => item.CandidateShadowMatched);
    if (sample is null) return new IsolationDiagnostic(0, 0, 0, 0, 0, false, false);
    DomainLexiconEntry entry = lexicon.Entries.Single(item => string.Equals(item.CanonicalId, sample.CanonicalId, StringComparison.OrdinalIgnoreCase));
    DomainLexiconMatchResult defaultMatch = index.Match(sample.AliasSurface, "en-US", ContextFor(entry, "16.15.1"));
    DomainLexiconMatchResult shadowMatch = index.Match(sample.AliasSurface, "en-US", ContextFor(entry, "16.15.1"), new DomainLexiconMatchOptions(true));
    DomainLexiconMatchResult nonGame = index.Match(sample.AliasSurface, "en-US", new DomainLexiconMatchContext(null, null, null, "16.15.1", Array.Empty<string>()), new DomainLexiconMatchOptions(true));
    bool passed = defaultMatch.FormalMatches.Count == 0 && defaultMatch.CandidateShadowMatches.Count == 0 && shadowMatch.FormalMatches.Count == 0 && shadowMatch.CandidateShadowMatches.Count == 1 && nonGame.CandidateShadowMatches.Count == 0;
    return new IsolationDiagnostic(defaultMatch.FormalMatches.Count, shadowMatch.CandidateShadowMatches.Count, nonGame.CandidateShadowMatches.Count, 0, 0, false, passed);
}

static DomainLexiconMatchContext ContextFor(DomainLexiconEntry entry, string patch) =>
    new(null, null, null, patch, entry.ContextScopes.SelectMany(scope => scope.Tags ?? Array.Empty<string>()).Distinct(StringComparer.OrdinalIgnoreCase).ToArray());

static string DetermineStatus(SourcePackStats source, DomainLexiconCandidateLoadResult load, IReadOnlyList<EntryDiagnostic> representatives, IReadOnlyList<ConflictDiagnostic> conflicts, IsolationDiagnostic isolation)
{
    if (source.InvalidJsonLines > 0 || load.Issues.Any(issue => issue.Code == "invalid_json") || !isolation.Passed || representatives.Any(item => !item.Passed) || conflicts.Any(item => !item.Passed)) return "incompatible";
    return load.Issues.Count > 0 || load.MissingFields.Count > 0 || load.UnknownFields.Count > 0 ? "compatible_with_warnings" : "compatible";
}

static IReadOnlyDictionary<string, int> CountLocales(DomainLexicon lexicon) => lexicon.Entries.SelectMany(entry => entry.Aliases).GroupBy(alias => alias.Locale).ToDictionary(group => group.Key, group => group.Count());
static IReadOnlyDictionary<string, int> CountRenderLocales(DomainLexicon lexicon) => lexicon.Entries.SelectMany(entry => entry.LocalizedRenderings).GroupBy(rendering => rendering.TargetLocale).ToDictionary(group => group.Key, group => group.Count());
static IReadOnlyDictionary<string, int> CountPatches(DomainLexicon lexicon) => lexicon.Entries.GroupBy(entry => $"{entry.PatchValidity?.From ?? "none"}..{entry.PatchValidity?.To ?? "none"}").ToDictionary(group => group.Key, group => group.Count());
static IReadOnlyDictionary<string, int> CountScopes(DomainLexicon lexicon) => lexicon.Entries.SelectMany(entry => entry.ContextScopes).SelectMany(scope => scope.Tags ?? Array.Empty<string>()).GroupBy(tag => tag).ToDictionary(group => group.Key, group => group.Count());
static string? GetString(JsonElement root, string property) => root.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.String ? value.GetString() : null;
static void Increment(IDictionary<string, int> counts, string key) => counts[key] = counts.TryGetValue(key, out int count) ? count + 1 : 1;
static string ComputeSha256(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

sealed record CompatibilityHeader(string RecordType, string SchemaVersion, DateTimeOffset GeneratedAt, string CandidatePath, string CandidateSha256, string MetadataPath, string MetadataSha256, string ExecutionMode, string CompatibilityStatus, string IsolationBoundary);
sealed record SourceIssue(int LineNumber, string Code, string Detail);
sealed record SourcePackStats(int TotalLines, int ValidLines, int InvalidJsonLines, IReadOnlyDictionary<string, int> RecordTypes, IReadOnlyDictionary<string, int> EntityTypes, IReadOnlyList<SourceIssue> InvalidJsonIssues);
sealed record SourcePackDiagnostic(string RecordType, int TotalLines, int ValidLines, int InvalidJsonLines, IReadOnlyDictionary<string, int> RecordTypes, IReadOnlyDictionary<string, int> EntityTypes, IReadOnlyList<SourceIssue> InvalidJsonIssues);
sealed record LoaderDiagnostic(string RecordType, int TotalLines, int LoadedEntries, int IssueCount, IReadOnlyDictionary<string, int> IssuesByCode, IReadOnlyDictionary<string, int> MissingFields, IReadOnlyDictionary<string, int> UnknownFields);
sealed record CandidateEntryDiagnostic(string RecordType, IReadOnlyDictionary<string, int> KindCounts, IReadOnlyDictionary<string, int> TypeCounts, IReadOnlyDictionary<string, int> FormalEligibilityCounts, IReadOnlyDictionary<string, int> AliasLocaleCounts, IReadOnlyDictionary<string, int> RenderingLocaleCounts, IReadOnlyDictionary<string, int> PatchCounts, IReadOnlyDictionary<string, int> ScopeTagCounts);
sealed record IssueDiagnostic(string RecordType, int LineNumber, string? SourceRecordType, string Code, string Detail);
sealed record EntryDiagnostic(string RecordType, string CanonicalId, string Type, string AliasSurface, bool CandidateShadowMatched, int FormalMatches, string ExactRenderingLocale, bool ExactRenderingFallback, string FallbackRenderingLocale, bool FallbackRenderingFallback, int ExpiredPatchCandidateMatches, int NonGameCandidateMatches, bool Passed);
sealed record ConflictDiagnostic(string RecordType, string CanonicalIds, string? DeclaredSurface, bool SurfaceIndexed, int FormalMatches, int CandidateMatches, IReadOnlyList<string> AmbiguityReasons, bool Passed);
sealed record IsolationDiagnostic(int FormalMatches, int CandidateMatches, int NonGameCandidateMatches, int FormalLocks, int QwenInvocations, bool FormalRenderingAffected, bool Passed);
sealed record IsolationDiagnosticRecord(string RecordType, int FormalMatches, int CandidateMatches, int NonGameCandidateMatches, int FormalLocks, int QwenInvocations, bool FormalRenderingAffected, bool Passed);
