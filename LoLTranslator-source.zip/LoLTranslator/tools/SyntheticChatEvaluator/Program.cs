using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using LoLTranslator.App;
using SlangGraph.Core;

const string InputRelativePath = "data/collection/lol/synthetic-chat-v0.1/accepted/synthetic-chat-evaluation.v0.1.jsonl";
const string OutputDirectoryRelativePath = "data/collection/lol/synthetic-chat-v0.1/runs";
const string ResultFileName = "synthetic-chat-runtime-evaluation.v0.1.jsonl";
const string ReportFileName = "synthetic-chat-runtime-evaluation-report.v0.1.md";

string workspaceRoot = Directory.GetCurrentDirectory();
string inputPath = Path.Combine(workspaceRoot, InputRelativePath.Replace('/', Path.DirectorySeparatorChar));
string outputDirectory = Path.Combine(workspaceRoot, OutputDirectoryRelativePath.Replace('/', Path.DirectorySeparatorChar));

if (!File.Exists(inputPath))
{
    throw new FileNotFoundException("Synthetic evaluation input was not found.", inputPath);
}

var jsonOptions = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true,
    PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = false
};

SyntheticEvaluationCase[] cases = File.ReadLines(inputPath)
    .Where(line => !string.IsNullOrWhiteSpace(line))
    .Select((line, index) => JsonSerializer.Deserialize<SyntheticEvaluationCase>(line, jsonOptions)
        ?? throw new InvalidDataException($"Input line {index + 1} is not a JSON object."))
    .ToArray();

if (cases.Length != 150)
{
    throw new InvalidDataException($"Expected 150 synthetic cases; found {cases.Length}.");
}

if (cases.Any(item => item.RecordOrigin != "synthetic_generation" || item.FormalEligibility != "not_eligible"))
{
    throw new InvalidDataException("Every evaluation input must remain synthetic_generation and not_eligible.");
}

var shadowService = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
SyntheticRuntimeEvaluationResult[] results = cases
    .Select(item => Evaluate(item, shadowService))
    .ToArray();

Directory.CreateDirectory(outputDirectory);
string resultPath = Path.Combine(outputDirectory, ResultFileName);
string reportPath = Path.Combine(outputDirectory, ReportFileName);

File.WriteAllLines(
    resultPath,
    results.Select(result => JsonSerializer.Serialize(result, jsonOptions)),
    new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
File.WriteAllText(reportPath, BuildReport(inputPath, resultPath, results), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));

Console.WriteLine($"Synthetic evaluation cases: {results.Length}");
Console.WriteLine($"Result JSONL: {resultPath}");
Console.WriteLine($"Report: {reportPath}");

static SyntheticRuntimeEvaluationResult Evaluate(
    SyntheticEvaluationCase item,
    OcrShadowSemanticService shadowService)
{
    ShadowMatchContextOption context = item.Channel == "team"
        ? new ShadowMatchContextOption(
            "Synthetic team-chat evaluation context",
            "lol.global",
            "in_game_chat",
            new[] { "lol.global", "lol.eu_or_global" })
        : new ShadowMatchContextOption(
            "Synthetic non-in-game-chat evaluation context",
            "lol.global",
            item.Channel);

    IReadOnlyList<OcrShadowLineResult> lines = shadowService.Match(item.RawText, item.SourceLocale, context);
    SlangGraphSemanticMatch[] matches = lines.SelectMany(line => line.Matches).ToArray();
    SyntheticSemanticMatch[] actualMatches = matches.Select(match =>
    {
        SlangGraphRenderedConcept rendering = shadowService.Render(match, item.TargetLocale);
        return new SyntheticSemanticMatch(
            match.ConceptId,
            match.MatchKind,
            match.SourceRecordId,
            match.Confidence,
            match.MatchedText,
            match.Slots.ToDictionary(
                pair => pair.Key,
                pair => pair.Value.Select(value => value.Value).ToArray(),
                StringComparer.OrdinalIgnoreCase),
            rendering.RenderingId,
            rendering.Text,
            rendering.ResolvedLocale,
            rendering.UsedFallback);
    }).ToArray();

    string actualRoute = actualMatches.Length == 0 ? "no_semantic_match" : "slang_graph";
    string? actualTranslation = actualMatches.Length == 1 ? actualMatches[0].RenderedText : null;
    string outputStatus = actualMatches.Length switch
    {
        0 => "no_translation_engine_for_general_text",
        1 => "verified_semantic_rendering",
        _ => "multiple_semantic_renderings_no_aggregate_translation"
    };
    bool routeMatched = actualRoute == item.FinalRoute;
    bool translationMatched = actualTranslation == item.FinalTranslation;
    bool negativeControlFalsePositive = item.ContentClass == "negative_control" && actualMatches.Length > 0;
    bool humanReviewForcedDecision = item.FinalRoute == "human_review_required" && actualRoute != "human_review_required";

    var failureCategories = new List<string>();
    if (!routeMatched)
    {
        failureCategories.Add("routing");
    }

    if (negativeControlFalsePositive ||
        (item.FinalRoute == "slang_graph" && actualMatches.Length == 0) ||
        (item.FinalRoute == "human_review_required" && actualMatches.Length > 0))
    {
        failureCategories.Add("semantic_matching");
    }

    if (!translationMatched)
    {
        failureCategories.Add("translation");
    }

    if (actualMatches.Length > 0 && !translationMatched)
    {
        failureCategories.Add("rendering");
    }

    return new SyntheticRuntimeEvaluationResult(
        "synthetic_chat_runtime_evaluation_result",
        "synthetic-chat-runtime-evaluation/0.1",
        item.CaseId,
        item.MatchId,
        item.Sequence,
        item.GameTime,
        item.Channel,
        item.SourceLocale,
        item.TargetLocale,
        item.ContentClass,
        item.RawText,
        item.FinalTranslation,
        item.FinalRoute,
        "direct_raw_text_no_ocr",
        context.Community,
        context.Channel,
        actualRoute,
        actualTranslation,
        outputStatus,
        actualMatches,
        routeMatched,
        translationMatched,
        negativeControlFalsePositive,
        humanReviewForcedDecision,
        failureCategories,
        "synthetic_generation",
        "not_eligible",
        "evaluation_only_not_observation_evidence_or_batch_003_count");
}

static string BuildReport(
    string inputPath,
    string resultPath,
    IReadOnlyList<SyntheticRuntimeEvaluationResult> results)
{
    string[] routes = ["general_translation", "slang_graph", "hybrid", "no_semantic_match", "human_review_required"];
    string[] failureCategories = ["ocr", "routing", "translation", "semantic_matching", "rendering"];
    int negativeControlCount = results.Count(item => item.ContentClass == "negative_control");
    int negativeControlFalsePositiveCount = results.Count(item => item.NegativeControlFalsePositive);
    int humanReviewCount = results.Count(item => item.ExpectedRoute == "human_review_required");
    int humanReviewForcedCount = results.Count(item => item.HumanReviewForcedDecision);

    var report = new StringBuilder();
    report.AppendLine("# Synthetic evaluation run v0.1");
    report.AppendLine();
    report.AppendLine("Status: completed");
    report.AppendLine("Scope: synthetic-only runtime evaluation; no Pack was modified.");
    report.AppendLine();
    report.AppendLine("## Input boundary");
    report.AppendLine();
    report.AppendLine($"- Cases: {results.Count}/150");
    report.AppendLine($"- Input SHA-256: `{ComputeSha256(inputPath)}`");
    report.AppendLine("- All input and output records: `record_origin=synthetic_generation`, `formal_eligibility=not_eligible`.");
    report.AppendLine("- Results are evaluation-only and are not Observation, Evidence, Review, or batch-003 counts.");
    report.AppendLine();
    report.AppendLine("## Actual runtime contract");
    report.AppendLine();
    report.AppendLine("- Input is passed directly as `raw_text`; OCR is not exercised in this run.");
    report.AppendLine("- The runtime uses the frozen semantic Pack 0.3.0 and Rendering Pack 0.1.0 with `includeDraft:false`.");
    report.AppendLine("- Current runtime has verified semantic rendering only. It has no general-translation, hybrid aggregation, or automatic human-review router.");
    report.AppendLine("- Team records use `lol.global` + `in_game_chat`; other input channels preserve their channel and therefore remain subject to published channel constraints.");
    report.AppendLine();
    report.AppendLine("## Route comparison");
    report.AppendLine();
    report.AppendLine("| Route | Expected | Actual | Exact route match |");
    report.AppendLine("| --- | ---: | ---: | ---: |");
    foreach (string route in routes)
    {
        int expected = results.Count(item => item.ExpectedRoute == route);
        int actual = results.Count(item => item.ActualRoute == route);
        int exact = results.Count(item => item.ExpectedRoute == route && item.ActualRoute == route);
        report.AppendLine($"| `{route}` | {expected} | {actual} | {exact} |");
    }

    report.AppendLine();
    report.AppendLine($"Overall exact route matches: {results.Count(item => item.RouteMatched)}/{results.Count}.");
    report.AppendLine($"Overall exact translation matches: {results.Count(item => item.TranslationMatched)}/{results.Count}.");
    report.AppendLine();
    report.AppendLine("## Safety checks");
    report.AppendLine();
    report.AppendLine($"- Negative controls: {negativeControlCount}; semantic false positives: {negativeControlFalsePositiveCount}.");
    report.AppendLine($"- Human-review-required cases: {humanReviewCount}; auto-routed away from human review: {humanReviewForcedCount}.");
    report.AppendLine();
    report.AppendLine("### Negative-control detail");
    report.AppendLine();
    report.AppendLine("| Case | Raw text | Actual route | Semantic concepts | Result |");
    report.AppendLine("| --- | --- | --- | --- | --- |");
    foreach (SyntheticRuntimeEvaluationResult item in results.Where(item => item.ContentClass == "negative_control"))
    {
        report.AppendLine(
            $"| `{item.CaseId}` | {EscapeTable(item.RawText)} | `{item.ActualRoute}` | {Concepts(item)} | " +
            (item.NegativeControlFalsePositive ? "false positive" : "no semantic match") + " |");
    }

    report.AppendLine();
    report.AppendLine("### Human-review-required detail");
    report.AppendLine();
    report.AppendLine("| Case | Raw text | Actual route | Semantic concepts | Forced decision |");
    report.AppendLine("| --- | --- | --- | --- | --- |");
    foreach (SyntheticRuntimeEvaluationResult item in results.Where(item => item.ExpectedRoute == "human_review_required"))
    {
        report.AppendLine(
            $"| `{item.CaseId}` | {EscapeTable(item.RawText)} | `{item.ActualRoute}` | {Concepts(item)} | " +
            (item.HumanReviewForcedDecision ? "yes" : "no") + " |");
    }
    report.AppendLine();
    report.AppendLine("## Failure signals");
    report.AppendLine();
    report.AppendLine("Categories may overlap on a case. `ocr` is reported as zero observable failures because the run starts from direct raw text, not an image.");
    report.AppendLine();
    report.AppendLine("| Category | Cases | Definition |");
    report.AppendLine("| --- | ---: | --- |");
    foreach (string category in failureCategories)
    {
        int count = category == "ocr" ? 0 : results.Count(item => item.FailureCategories.Contains(category));
        string definition = category switch
        {
            "ocr" => "Not exercised by this direct-text run.",
            "routing" => "Actual route differs from final_route.",
            "translation" => "Actual output is absent or differs from final_translation.",
            "semantic_matching" => "Published semantic match is absent where required, or appears on a protected negative/human-review boundary.",
            "rendering" => "A semantic rendering was produced but differs from final_translation.",
            _ => string.Empty
        };
        report.AppendLine($"| `{category}` | {count} | {definition} |");
    }

    report.AppendLine();
    report.AppendLine("## Artifacts");
    report.AppendLine();
    report.AppendLine($"- Result JSONL: `{Path.GetFileName(resultPath)}`");
    report.AppendLine("- No source Pack, candidate Pack, RC Pack, or formal data count was changed.");
    return report.ToString();
}

static string Concepts(SyntheticRuntimeEvaluationResult item) =>
    item.SemanticMatches.Count == 0
        ? "-"
        : string.Join(", ", item.SemanticMatches.Select(match => $"`{match.ConceptId}`"));

static string EscapeTable(string value) => value.Replace("|", "\\|", StringComparison.Ordinal);

static string ComputeSha256(string path)
{
    using FileStream stream = File.OpenRead(path);
    return Convert.ToHexString(SHA256.HashData(stream));
}

public sealed record SyntheticEvaluationCase(
    [property: JsonPropertyName("case_id")] string CaseId,
    [property: JsonPropertyName("match_id")] string MatchId,
    [property: JsonPropertyName("sequence")] int Sequence,
    [property: JsonPropertyName("game_time")] string GameTime,
    [property: JsonPropertyName("channel")] string Channel,
    [property: JsonPropertyName("source_locale")] string SourceLocale,
    [property: JsonPropertyName("raw_text")] string RawText,
    [property: JsonPropertyName("target_locale")] string TargetLocale,
    [property: JsonPropertyName("content_class")] string ContentClass,
    [property: JsonPropertyName("record_origin")] string RecordOrigin,
    [property: JsonPropertyName("formal_eligibility")] string FormalEligibility,
    [property: JsonPropertyName("final_translation")] string FinalTranslation,
    [property: JsonPropertyName("final_route")] string FinalRoute);

public sealed record SyntheticRuntimeEvaluationResult(
    string RecordType,
    string SchemaVersion,
    string CaseId,
    string MatchId,
    int Sequence,
    string GameTime,
    string InputChannel,
    string SourceLocale,
    string TargetLocale,
    string ContentClass,
    string RawText,
    string ExpectedTranslation,
    string ExpectedRoute,
    string OcrStatus,
    string? RuntimeCommunity,
    string? RuntimeChannel,
    string ActualRoute,
    string? ActualTranslation,
    string OutputStatus,
    IReadOnlyList<SyntheticSemanticMatch> SemanticMatches,
    bool RouteMatched,
    bool TranslationMatched,
    bool NegativeControlFalsePositive,
    bool HumanReviewForcedDecision,
    IReadOnlyList<string> FailureCategories,
    string RecordOrigin,
    string FormalEligibility,
    string DataBoundary);

public sealed record SyntheticSemanticMatch(
    string ConceptId,
    string MatchKind,
    string SourceRecordId,
    double Confidence,
    string MatchedText,
    IReadOnlyDictionary<string, string[]> Slots,
    string? RenderingId,
    string RenderedText,
    string ResolvedLocale,
    bool UsedFallback);
