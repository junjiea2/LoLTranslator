using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.RegularExpressions;
using LoLTranslator.App;
using SlangGraph.Core;

if (args.Length != 2)
{
    Console.Error.WriteLine("Usage: SlangGraph.LegacyLolMigrator <legacy-jsonl> <output-jsonl>");
    return 2;
}

LolSlangDataset legacy = LolSlangDatasetLoader.LoadFromJsonl(args[0]);
IReadOnlyList<(string RecordType, object Value)> records = LegacyLolMigration.Convert(legacy);

string? outputDirectory = Path.GetDirectoryName(Path.GetFullPath(args[1]));

if (!string.IsNullOrWhiteSpace(outputDirectory))
{
    Directory.CreateDirectory(outputDirectory);
}

File.WriteAllLines(
    args[1],
    records.Select(record => LegacyLolMigration.SerializeRecord(record.RecordType, record.Value)),
    new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));

SlangGraphPack migrated = SlangGraphJsonl.Load(args[1]);
Console.WriteLine($"Migrated {legacy.DatasetId} {legacy.DatasetVersion}");
Console.WriteLine($"Pack: {migrated.Header.PackId} {migrated.Header.PackVersion}");
Console.WriteLine($"Concepts: {migrated.Concepts.Count}");
Console.WriteLine($"Expressions: {migrated.Expressions.Count}");
Console.WriteLine($"Observations: {migrated.Observations.Count}");
return 0;

internal static class LegacyLolMigration
{
    private const string LolDomain = "game.lol";
    private const string CoreDomain = "core.communication";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        WriteIndented = false
    };

    public static IReadOnlyList<(string RecordType, object Value)> Convert(LolSlangDataset legacy)
    {
        var records = new List<(string, object)>();
        var evidence = new List<EvidenceRecord>();
        var conceptMap = legacy.Concepts.ToDictionary(
            item => item.ConceptId,
            item => $"{LolDomain}:{item.ConceptId}",
            StringComparer.OrdinalIgnoreCase);
        var entityMap = legacy.Entities.ToDictionary(
            item => item.EntityId,
            item => $"{LolDomain}:entity:{item.EntityId}",
            StringComparer.OrdinalIgnoreCase);

        records.Add(("pack", new PackHeader(
            "slang-graph/0.2",
            "pack.game.lol.chat",
            $"0.2.0-migrated-from-{legacy.DatasetVersion}",
            Array.Empty<PackDependency>(),
            "draft")));
        records.Add(("domain", new DomainRecord(
            CoreDomain,
            "通用沟通语义",
            "不依赖具体游戏或社区的抽象沟通概念。",
            null,
            new[] { "core", "cross-domain" })));
        records.Add(("domain", new DomainRecord(
            LolDomain,
            "League of Legends",
            "英雄联盟局内沟通领域包。",
            CoreDomain,
            new[] { "game", "moba", "lol" })));

        foreach (DataSource source in legacy.Sources)
        {
            records.Add(("source", new SourceRecord(
                source.SourceId,
                source.SourceType,
                source.Uri,
                source.CollectionPolicy,
                source.CollectedAt,
                source.Notes)));
        }

        const string abstractConceptId = "core.communication:capability.unavailable";
        records.Add(("concept", new ConceptRecord(
            abstractConceptId,
            CoreDomain,
            "status",
            "某个主体当前无法使用某项能力。",
            new[]
            {
                new SlotDefinition("subject", "entity_ref", null, false),
                new SlotDefinition("capability", "entity_ref", null, true)
            },
            new[] { "availability", "cross-domain" },
            Array.Empty<string>(),
            "draft")));

        foreach (SlangConcept concept in legacy.Concepts)
        {
            records.Add(("concept", new ConceptRecord(
                conceptMap[concept.ConceptId],
                LolDomain,
                concept.Category,
                concept.Definition,
                concept.Slots.Select(ConvertSlot).ToArray(),
                new[] { $"urgency:{concept.Urgency}", "legacy-v0.1" },
                Array.Empty<string>(),
                concept.Status)));
        }

        foreach (GameEntity entity in legacy.Entities)
        {
            string entityId = entityMap[entity.EntityId];
            IReadOnlyList<string> evidenceIds = CreateEvidence(
                evidence,
                entityId,
                entity.SourceIds,
                "legacy_source_reference");

            records.Add(("entity", new EntityRecord(
                entityId,
                LolDomain,
                entity.EntityType,
                entity.CanonicalNames,
                entity.Aliases.Select(alias => new EntityAlias("und", alias, alias)).ToArray(),
                evidenceIds,
                entity.Status)));
        }

        foreach (SlangExpression expression in legacy.Expressions)
        {
            string expressionId = $"{LolDomain}:expression:{expression.ExpressionId}";
            IReadOnlyList<string> evidenceIds = CreateEvidence(
                evidence,
                expressionId,
                expression.SourceIds,
                "legacy_source_reference");

            records.Add(("expression", new ExpressionRecord(
                expressionId,
                conceptMap[expression.ConceptId],
                LolDomain,
                expression.Locale,
                expression.Surface,
                expression.Normalized,
                $"lol.{expression.Region.ToLowerInvariant()}",
                "in_game_chat",
                expression.Register,
                null,
                evidenceIds,
                expression.Status)));
        }

        foreach (SlangTemplate template in legacy.Templates)
        {
            string patternId = $"{LolDomain}:pattern:{template.TemplateId}";
            IReadOnlyList<string> evidenceIds = CreateEvidence(
                evidence,
                patternId,
                template.SourceIds,
                "legacy_source_reference");

            records.Add(("pattern", new PatternRecord(
                patternId,
                conceptMap[template.ConceptId],
                LolDomain,
                template.Locale,
                template.Pattern,
                template.Slots,
                null,
                "in_game_chat",
                evidenceIds,
                template.Status)));
        }

        foreach (SemanticRelation relation in legacy.Relations)
        {
            records.Add(("relation", new RelationRecord(
                $"{LolDomain}:relation:{relation.RelationId}",
                MapNodeId(relation.FromId, conceptMap, entityMap),
                relation.RelationType,
                MapNodeId(relation.ToId, conceptMap, entityMap),
                null,
                Array.Empty<string>(),
                relation.Status)));
        }

        if (conceptMap.TryGetValue("summoner.flash.unavailable", out string? flashConceptId))
        {
            records.Add(("relation", new RelationRecord(
                $"{LolDomain}:relation:flash-unavailable.specialization",
                flashConceptId,
                "specialization_of",
                abstractConceptId,
                1.0,
                Array.Empty<string>(),
                "draft")));
        }

        records.AddRange(evidence.Select(item => ("evidence", (object)item)));

        foreach (TextExample example in legacy.Examples)
        {
            IReadOnlyList<ObservationLabel> labels = example.ConceptId is null
                ? Array.Empty<ObservationLabel>()
                : new[]
                {
                    new ObservationLabel(
                        conceptMap[example.ConceptId],
                        example.Kind,
                        example.Slots,
                        0.5)
                };

            records.Add(("observation", new ObservationRecord(
                $"{LolDomain}:observation:{example.ExampleId}",
                LolDomain,
                example.Text,
                example.Locale,
                null,
                "in_game_chat",
                null,
                "redacted",
                example.SourceIds,
                labels,
                example.Status)));
        }

        return records;
    }

    public static string SerializeRecord(string recordType, object value)
    {
        using JsonDocument document = JsonDocument.Parse(JsonSerializer.Serialize(value, JsonOptions));
        using var stream = new MemoryStream();

        using (var writer = new Utf8JsonWriter(stream))
        {
            writer.WriteStartObject();
            writer.WriteString("record_type", recordType);

            foreach (JsonProperty property in document.RootElement.EnumerateObject())
            {
                property.WriteTo(writer);
            }

            writer.WriteEndObject();
        }

        return Encoding.UTF8.GetString(stream.ToArray());
    }

    private static SlotDefinition ConvertSlot(string slot)
    {
        return slot.ToLowerInvariant() switch
        {
            "seconds" => new SlotDefinition(slot, "number", null, false),
            "subject" => new SlotDefinition(slot, "entity_ref", null, false),
            "target" => new SlotDefinition(slot, "entity_ref", null, false),
            "objective" => new SlotDefinition(slot, "entity_ref", "map_objective", false),
            "spell" => new SlotDefinition(slot, "entity_ref", "ability", false),
            _ => new SlotDefinition(slot, "text", null, false)
        };
    }

    private static IReadOnlyList<string> CreateEvidence(
        ICollection<EvidenceRecord> destination,
        string subjectId,
        IEnumerable<string> sourceIds,
        string evidenceKind)
    {
        var ids = new List<string>();
        int index = 0;

        foreach (string sourceId in sourceIds)
        {
            index++;
            string evidenceId = $"evidence.legacy.{Sanitize(subjectId)}.{Sanitize(sourceId)}.{index}";
            ids.Add(evidenceId);
            destination.Add(new EvidenceRecord(
                evidenceId,
                subjectId,
                sourceId,
                evidenceKind,
                null,
                "pending",
                null,
                "迁移后仍需人工复核。"));
        }

        return ids;
    }

    private static string MapNodeId(
        string legacyId,
        IReadOnlyDictionary<string, string> conceptMap,
        IReadOnlyDictionary<string, string> entityMap)
    {
        if (conceptMap.TryGetValue(legacyId, out string? conceptId)) return conceptId;
        if (entityMap.TryGetValue(legacyId, out string? entityId)) return entityId;
        return $"{LolDomain}:{legacyId}";
    }

    private static string Sanitize(string value)
    {
        return Regex.Replace(value.ToLowerInvariant(), @"[^a-z0-9]+", "-").Trim('-');
    }
}
