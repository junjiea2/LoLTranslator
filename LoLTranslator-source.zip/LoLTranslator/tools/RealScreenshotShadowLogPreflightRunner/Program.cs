using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;

const string DefaultOutputRelative = "data/collection/lol/domain-lexicon-v0.1/rc-1-human-review/runtime-shadow/real-screenshot-shadow-v0.1-local-preflight-manifest.json";
const string Run006OutputRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-shadow/run006-local-preflight-content-free.json";
bool latestOnly = args.Contains("--latest-only", StringComparer.OrdinalIgnoreCase);
string inputPath = args.FirstOrDefault(argument => !argument.StartsWith("--", StringComparison.Ordinal))
    ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LoLTranslator", "real-screenshot-shadow.v0.1.jsonl");
if (!File.Exists(inputPath)) throw new FileNotFoundException("Local real screenshot shadow log was not found.", inputPath);

var lineStatuses = new Dictionary<string, int>(StringComparer.Ordinal);
var fusionStatuses = new Dictionary<string, int>(StringComparer.Ordinal);
var targetLocales = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var origins = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var eligibility = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var intakeStatuses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var redactionStatuses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
var sensitiveFlags = new HashSet<string>(StringComparer.Ordinal);
var falsePositiveMetadata = new HashSet<string>(StringComparer.Ordinal);
int records = 0;
int modelCalls = 0;
int screenshotInLog = 0;
int screenshotWrittenToDataset = 0;

IReadOnlyList<string> inputRecords = latestOnly
    ? File.ReadLines(inputPath).Where(line => !string.IsNullOrWhiteSpace(line)).TakeLast(1).ToArray()
    : File.ReadLines(inputPath).Where(line => !string.IsNullOrWhiteSpace(line)).ToArray();
foreach (string line in inputRecords)
{
    if (string.IsNullOrWhiteSpace(line)) continue;
    records++;
    using JsonDocument document = JsonDocument.Parse(line);
    JsonElement root = document.RootElement;
    modelCalls += Number(root, "model_call_count");
    Add(targetLocales, Text(root, "target_locale"));
    Add(origins, Text(root, "record_origin"));
    Add(eligibility, Text(root, "formal_eligibility"));
    Add(intakeStatuses, Text(root, "intake_status"));
    Add(redactionStatuses, Text(root, "redaction_status"));
    if (Bool(root, "screenshot_in_log")) screenshotInLog++;
    if (Bool(root, "screenshot_written_to_dataset")) screenshotWrittenToDataset++;
    foreach (JsonElement entry in root.GetProperty("lines").EnumerateArray())
    {
        Increment(lineStatuses, Text(entry, "status") ?? "unknown");
        Increment(fusionStatuses, Text(entry, "fusion_status") ?? "unknown");
        foreach (string property in new[] { "ocr_text", "protected_input", "raw_provider_output", "final_output", "failure_reason" })
        {
            ScanSensitive(Text(entry, property), sensitiveFlags, falsePositiveMetadata);
        }
    }
}

string rootDirectory = Directory.GetCurrentDirectory();
string outputRelative = latestOnly ? Run006OutputRelative : DefaultOutputRelative;
string outputPath = Path.Combine(rootDirectory, outputRelative.Replace('/', Path.DirectorySeparatorChar));
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
FileInfo info = new(inputPath);
string hash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(inputPath)));
var manifest = new
{
    manifest_type = latestOnly ? "real_screenshot_shadow_run006_local_preflight.v0.1" : "real_screenshot_shadow_local_preflight.v0.1",
    generated_at = DateTimeOffset.UtcNow,
    source_file_name = Path.GetFileName(inputPath),
    source_sha256 = hash,
    source_size_bytes = info.Length,
    record_count = records,
    model_call_count = modelCalls,
    target_locales = targetLocales.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    record_origins = origins.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    formal_eligibility = eligibility.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    intake_statuses = intakeStatuses.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    redaction_statuses = redactionStatuses.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    screenshot_in_log_count = screenshotInLog,
    screenshot_written_to_dataset_count = screenshotWrittenToDataset,
    line_status_counts = lineStatuses.OrderBy(pair => pair.Key, StringComparer.Ordinal).ToDictionary(pair => pair.Key, pair => pair.Value),
    fusion_status_counts = fusionStatuses.OrderBy(pair => pair.Key, StringComparer.Ordinal).ToDictionary(pair => pair.Key, pair => pair.Value),
    sensitive_marker_categories_detected = sensitiveFlags.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    sensitive_false_positive_metadata = falsePositiveMetadata.OrderBy(value => value, StringComparer.Ordinal).ToArray(),
    disposition = sensitiveFlags.Count == 0 && records > 0 && modelCalls == 0 && screenshotInLog == 0 && screenshotWrittenToDataset == 0
        ? "local_diagnostic_only_not_evidence"
        : "local_diagnostic_blocked",
    no_chat_body_exported = true,
    no_image_or_path_exported = true
};
File.WriteAllText(outputPath, JsonSerializer.Serialize(manifest, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Preflight records: {records}; model calls: {modelCalls}; sensitive categories: {sensitiveFlags.Count}; output: {outputPath}");

static string? Text(JsonElement element, string property) =>
    element.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.String ? value.GetString() : null;
static int Number(JsonElement element, string property) =>
    element.TryGetProperty(property, out JsonElement value) && value.TryGetInt32(out int parsed) ? parsed : 0;
static bool Bool(JsonElement element, string property) =>
    element.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.True;
static void Add(ISet<string> values, string? value) { if (!string.IsNullOrWhiteSpace(value)) values.Add(value); }
static void Increment(IDictionary<string, int> values, string key) => values[key] = values.TryGetValue(key, out int count) ? count + 1 : 1;

static void ScanSensitive(string? text, ISet<string> flags, ISet<string> falsePositiveMetadata)
{
    if (string.IsNullOrWhiteSpace(text)) return;
    if (Regex.IsMatch(text, @"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")) flags.Add("email");
    if (Regex.IsMatch(text, @"(?i)\b(?:https?://|www\.)")) flags.Add("url");
    if (Regex.IsMatch(text, @"(?ix)(?:\b[a-z]:[\\/]|\\\\[^\s\\/]+[\\/][^\s]+|file://)")) flags.Add("local_path");
    bool timestampStyle = Regex.IsMatch(text, @"(?<!\d)(?:\d{1,2}\s*[:：]\s*\d{2}|[:：]\s*\d{1,2}\s*\[)");
    if (timestampStyle)
    {
        falsePositiveMetadata.Add("phone_like_timestamp_style");
    }
    if (Regex.IsMatch(text, @"(?<!\d)(?:\+?\d[\s().-]?){7,}\d(?!\d)"))
    {
        if (timestampStyle)
        {
            falsePositiveMetadata.Add("phone_like_timestamp_style");
        }
        else
        {
            flags.Add("phone");
        }
    }
    if (Regex.IsMatch(text, @"(?<!\w)@[A-Za-z0-9_]{2,}")) flags.Add("mention");
}
