@echo off
cd /d "%~dp0"
start "" "%~dp0LoLTranslator.App.exe"
