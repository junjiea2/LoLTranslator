using System.Drawing;
using LoLTranslator.App;

if (args.Length == 0 || args.Any(path => !Path.IsPathFullyQualified(path) || !File.Exists(path)))
{
    Console.Error.WriteLine("Usage: SystemMessageScreenshotRunner <absolute-chat-screenshot> [...]");
    return 2;
}

string? recognitionModel = Environment.GetEnvironmentVariable("LOLTRANSLATOR_SCREENSHOT_REC_MODEL_DIR");
string? recognitionDictionary = Environment.GetEnvironmentVariable("LOLTRANSLATOR_SCREENSHOT_REC_DICT");
using var provider = new NativePpOcrV5SidecarProvider(
    recognizerModelDirectory: recognitionModel,
    dictionaryPath: recognitionDictionary);
HighAccuracyOcrCapability capability = await provider.ProbeAsync(CancellationToken.None);
if (!capability.Ready)
{
    Console.Error.WriteLine(capability.Diagnostic);
    return 3;
}

long frameId = 0;
foreach (string path in args)
{
    foreach (string variant in new[] { "raw", "scaled2x", "contrast2x" })
    {
        var elapsed = System.Diagnostics.Stopwatch.StartNew();
        string candidatePath = variant switch
        {
            "raw" => path,
            "scaled2x" => OcrChatPreprocessor.CreateScaledCandidate(path),
            _ => OcrChatPreprocessor.CreateLolChatHighContrastCandidate(path)
        };
        try
        {
            IReadOnlyList<StructuredOcrLine> lines = await provider.RecognizeLinesAsync(
                candidatePath, "auto", ++frameId, CancellationToken.None);
            using var bitmap = new Bitmap(candidatePath);
            Console.WriteLine($"IMAGE {Path.GetFileName(path)} VARIANT {variant} ROWS {lines.Count} MS {elapsed.ElapsedMilliseconds}");
            foreach (StructuredOcrLine line in lines.OrderBy(line => line.Bounds.Y))
            {
                ChatRowVisualAnalysis visual = ScreenCaptureService.ComputeRowVisualAnalysis(bitmap, line.Bounds);
                Console.WriteLine($"x={line.Bounds.X:F0}\ty={line.Bounds.Y:F0}\tw={line.Bounds.Width:F0}\th={line.Bounds.Height:F0}\tally={visual.AlliedBlueSamples}\tenemy={visual.EnemyRedSamples}\tgold={visual.SystemGoldSamples}\trelation={visual.IdentityRelation ?? "none"}\ttext={visual.TextLikeSamples}\t{line.Text}");
            }
        }
        finally
        {
            if (variant != "raw") ScreenCaptureService.DeleteTransient(candidatePath);
        }
    }
}

return 0;
