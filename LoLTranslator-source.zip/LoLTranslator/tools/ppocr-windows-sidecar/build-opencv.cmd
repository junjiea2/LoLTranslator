@echo off
setlocal
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

subst P: "%CACHE_ROOT%" >nul 2>nul
call "%~dp0configure-opencv.cmd"
if errorlevel 1 exit /b %errorlevel%
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
cmake --build P:\build\opencv-4.10.0 --config Release --target INSTALL -- /m:4
set "BUILD_EXIT=%ERRORLEVEL%"
endlocal & exit /b %BUILD_EXIT%
