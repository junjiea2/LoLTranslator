param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ [IO.Path]::IsPathRooted($_) -and (Test-Path -LiteralPath $_) })]
    [string]$ScreenshotPath,
    [string]$DetectorModelDirectory = 'C:\Users\jense\.paddlex\official_models\PP-OCRv5_mobile_det',
    [string]$RecognizerModelDirectory = 'C:\Users\jense\.paddlex\official_models\PP-OCRv5_server_rec',
    [string]$OutputPath = ''
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $PSScriptRoot '..\ocr-engine-ab-v0.1\results\ppocrv5-sidecar-gpu-six-line.aggregate.json'
}
$sidecar = Join-Path $PSScriptRoot '.third-party\build\sidecar-gpu\Release\loltranslator-ppocr-sidecar.exe'
$dictionary = Join-Path $PSScriptRoot '.third-party\models\PP-OCRv5_server_rec\character_dict.txt'
foreach ($required in @($sidecar, $DetectorModelDirectory, $RecognizerModelDirectory, $dictionary)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Required GPU gate input is unavailable: $required" }
}

# These are redacted message bodies only. The input screenshot and raw OCR never
# enter the output JSON or any project artifact.
$expected = @('Hi', 'hi', 'OCR test', 'can you scan this?', 'Yo', 'what is wrong with this OCR?')
function ConvertTo-NormalizedText([string]$value) {
    return [Text.RegularExpressions.Regex]::Replace($value.ToLowerInvariant(), '[^a-z0-9]', '')
}

function Measure-RedactedResult($lines) {
    $remaining = [Collections.ArrayList]::new()
    foreach ($line in @($lines)) {
        $text = if ($line.PSObject.Properties['text_base64']) {
            [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([string]$line.text_base64))
        } else { [string]$line.text }
        [void]$remaining.Add((ConvertTo-NormalizedText $text))
    }
    $matched = 0
    foreach ($item in @($expected | Sort-Object { $_.Length } -Descending)) {
        $needle = ConvertTo-NormalizedText $item
        $matchIndex = -1
        for ($index = 0; $index -lt $remaining.Count; $index++) {
            if ([string]$remaining[$index] -and ([string]$remaining[$index]).EndsWith($needle)) {
                $matchIndex = $index
                break
            }
        }
        if ($matchIndex -ge 0) {
            $matched++
            $remaining.RemoveAt($matchIndex)
        }
    }
    $duplicates = @($remaining | Where-Object { $_ } | Group-Object | Where-Object { $_.Count -gt 1 } |
        ForEach-Object { $_.Count - 1 } | Measure-Object -Sum).Sum
    if ($null -eq $duplicates) { $duplicates = 0 }
    return [pscustomobject]@{ matched = $matched; duplicates = [int]$duplicates }
}

$arguments = @(
    '--stdin_loop=true',
    "--det_model_dir=$DetectorModelDirectory",
    "--rec_model_dir=$RecognizerModelDirectory",
    "--rec_char_dict_path=$dictionary",
    '--use_gpu=true', '--gpu_id=0', '--gpu_mem=6000', '--use_tensorrt=false',
    '--use_angle_cls=false', '--crop_x=0.058', '--crop_y=0.575',
    '--crop_width=0.247', '--crop_height=0.160'
)
$startInfo = [Diagnostics.ProcessStartInfo]::new()
$startInfo.FileName = $sidecar
$startInfo.Arguments = [string]::Join(' ', ($arguments | ForEach-Object { '"' + $_.Replace('"', '\"') + '"' }))
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$startInfo.RedirectStandardInput = $true
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true
$process = [Diagnostics.Process]::new()
$process.StartInfo = $startInfo
$runs = @()
$coldClock = [Diagnostics.Stopwatch]::StartNew()
[void]$process.Start()
$stderrTask = $process.StandardError.ReadToEndAsync()
try {
    for ($run = 1; $run -le 5; $run++) {
        $clock = if ($run -eq 1) { $coldClock } else { [Diagnostics.Stopwatch]::StartNew() }
        $process.StandardInput.WriteLine($ScreenshotPath)
        $process.StandardInput.Flush()
        $timeoutMs = if ($run -eq 1) { 30000 } else { 5000 }
        $responseLine = $null
        while ($clock.ElapsedMilliseconds -lt $timeoutMs) {
            $stdoutTask = $process.StandardOutput.ReadLineAsync()
            $remainingMs = [Math]::Max(1, $timeoutMs - [int]$clock.ElapsedMilliseconds)
            if (-not $stdoutTask.Wait($remainingMs)) { break }
            $candidateLine = $stdoutTask.Result
            if ($null -eq $candidateLine) { break }
            if ($candidateLine.TrimStart().StartsWith('{"status":') -and
                -not $candidateLine.TrimStart().StartsWith('{"status":"ready"')) {
                $responseLine = $candidateLine
                break
            }
            # Paddle may emit native startup diagnostics to stdout. They are
            # ignored in memory and are never persisted in the aggregate.
        }
        if ($null -eq $responseLine) {
            $clock.Stop()
            $runs += [pscustomobject]@{ run = $run; status = 'protocol_timeout'; elapsed_ms = $clock.ElapsedMilliseconds; matched = 0; line_count = 0; duplicates = 0 }
            break
        }
        $clock.Stop()
        try {
            $payload = $responseLine | ConvertFrom-Json
            $measurement = Measure-RedactedResult $payload.lines
            $runs += [pscustomobject]@{
                run = $run; status = $payload.status; elapsed_ms = $clock.ElapsedMilliseconds
                matched = $measurement.matched; line_count = @($payload.lines).Count
                duplicates = $measurement.duplicates
            }
        }
        catch {
            $runs += [pscustomobject]@{ run = $run; status = 'malformed_output'; elapsed_ms = $clock.ElapsedMilliseconds; matched = 0; line_count = 0; duplicates = 0 }
            break
        }
    }
}
finally {
    if (-not $process.HasExited) {
        try { $process.StandardInput.WriteLine('__quit__'); $process.StandardInput.Close() } catch {}
        if (-not $process.WaitForExit(5000)) { $process.Kill(); $process.WaitForExit() }
    }
    $null = $stderrTask.GetAwaiter().GetResult() # diagnostics may contain local paths; never persist them
}

$warm = @($runs | Select-Object -Skip 1 | ForEach-Object { $_.elapsed_ms })
$result = [ordered]@{
    fixture_id = 'temp-user-screenshot-ocr-ab-001'
    engine = 'ppocrv5_mobile_det_server_rec_cpp_cuda'
    runs = 5
    expected_body_lines = 6
    minimum_matched_body_lines = @($runs | ForEach-Object { $_.matched } | Measure-Object -Minimum).Minimum
    maximum_duplicate_rows = @($runs | ForEach-Object { $_.duplicates } | Measure-Object -Maximum).Maximum
    ocr_test_exact_all_runs = @($runs | Where-Object { $_.matched -eq 6 }).Count -eq 5
    cold_latency_ms = $runs[0].elapsed_ms
    warm_latency_ms = ($warm | Measure-Object -Average).Average
    raw_screenshot = $false
    raw_ocr = $false
    run_summaries = $runs
    pass = (@($runs | Where-Object { $_.status -eq 'ok' -and $_.matched -eq 6 -and $_.duplicates -eq 0 }).Count -eq 5 -and ($warm | Measure-Object -Maximum).Maximum -le 1000)
}

$directory = Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Force -Path $directory | Out-Null
[IO.File]::WriteAllText($OutputPath, ($result | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
Write-Output $OutputPath
exit $(if ($result.pass) { 0 } else { 4 })
