param(
    [string]$ReferenceSource = 'C:\Users\jense\AppData\Local\Temp\PaddleOCR-official-release-2.7\deploy\cpp_infer'
)

$ErrorActionPreference = 'Stop'
$cacheRoot = Join-Path $PSScriptRoot '.third-party'
$destination = Join-Path $cacheRoot 'PaddleOCR-cpp-infer-v2.7'
if (-not (Test-Path -LiteralPath (Join-Path $ReferenceSource 'include\paddleocr.h'))) {
    throw "The approved local official PaddleOCR C++ reference source is unavailable: $ReferenceSource"
}

if (-not (Test-Path -LiteralPath $destination)) {
    Copy-Item -LiteralPath $ReferenceSource -Destination $destination -Recurse
}

foreach ($relativePath in @('src\ocr_det.cpp', 'src\ocr_rec.cpp')) {
    $path = Join-Path $destination $relativePath
    $source = Get-Content -LiteralPath $path -Raw -Encoding utf8
    $old = "config.SetModel(model_dir + `"/inference.pdmodel`",`r`n                  model_dir + `"/inference.pdiparams`");"
    $new = "// PP-OCRv5 exports Paddle's PIR program as inference.json.  Paddle 3.2.2`r`n  // selects it when the model directory/prefix overload is used.`r`n  config.SetModel(model_dir, `"inference`");`r`n  config.EnableNewIR();"
    if ($source.Contains($old)) {
        [System.IO.File]::WriteAllText($path, $source.Replace($old, $new), [System.Text.UTF8Encoding]::new($false))
    }
    elseif (-not $source.Contains('config.SetModel(model_dir, "inference")')) {
        throw "Unexpected official source shape in $path; refusing a fuzzy model-format patch."
    }

    # Paddle 3.2.2's PIR export rejects the legacy memory optimizer pass used
    # by the older official C++ sample.  The predictor remains fail-closed;
    # this only removes that incompatible optional pass.
    $source = Get-Content -LiteralPath $path -Raw -Encoding utf8
    $legacyMemoryOptim = '  config.EnableMemoryOptim();'
    $pirSafeMemoryOptim = '  // PIR model: do not add the legacy memory optimizer pass.'
    if ($source.Contains($legacyMemoryOptim)) {
        [System.IO.File]::WriteAllText($path, $source.Replace($legacyMemoryOptim, $pirSafeMemoryOptim), [System.Text.UTF8Encoding]::new($false))
    }
}

Write-Host "Staged official PaddleOCR C++ source at $destination"
