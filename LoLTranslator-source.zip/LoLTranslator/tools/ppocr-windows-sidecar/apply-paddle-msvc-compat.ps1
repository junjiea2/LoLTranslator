param(
    [Parameter(Mandatory = $true)]
    [string]$PaddleSource
)

$ErrorActionPreference = 'Stop'
$patch = Join-Path $PSScriptRoot 'patches\paddle-3.2.2-msvc-compat.patch'
if (-not (Test-Path -LiteralPath (Join-Path $PaddleSource '.git'))) {
    throw "PaddleSource must be the checked-out Paddle 3.2.2 source tree: $PaddleSource"
}

$savedErrorAction = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
& git -C $PaddleSource apply --reverse --check $patch 2>$null
$hasCompletePatch = $LASTEXITCODE -eq 0
$ErrorActionPreference = $savedErrorAction
if ($hasCompletePatch) {
    Write-Host 'Paddle MSVC compatibility patch is already applied.'
    exit 0
}

$ErrorActionPreference = 'Continue'
& git -C $PaddleSource apply --check $patch 2>$null
$canApply = $LASTEXITCODE -eq 0
$ErrorActionPreference = $savedErrorAction
if ($canApply) {
    & git -C $PaddleSource apply $patch
    if ($LASTEXITCODE -ne 0) { throw 'Unable to apply the Paddle MSVC compatibility patch.' }
    Write-Host 'Applied Paddle 3.2.2 MSVC compatibility patch.'
    exit 0
}

throw 'Paddle source neither accepts nor contains the expected MSVC compatibility patch.'
