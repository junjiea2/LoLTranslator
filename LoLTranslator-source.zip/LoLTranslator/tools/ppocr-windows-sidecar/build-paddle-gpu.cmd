@echo off
setlocal EnableExtensions
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

call "%SIDECAR_ROOT%configure-paddle-gpu.cmd"
if errorlevel 1 exit /b %errorlevel%
subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%apply-paddle-msvc-compat.ps1" -PaddleSource "P:\P"
if errorlevel 1 exit /b %errorlevel%

rem Keep the top-level distribution target serial on Windows. It avoids the
rem existing generated-header race while still producing a GPU inference SDK.
cmake --build P:\build\paddle-gpu --config Release --target inference_lib_dist -- /m:1
set "BUILD_EXIT=%ERRORLEVEL%"
endlocal & exit /b %BUILD_EXIT%
