[CmdletBinding()]
param(
    [switch]$DownloadSources
)

$ErrorActionPreference = 'Stop'
$toolRoot = Split-Path -Parent $PSCommandPath
$cacheRoot = Join-Path $toolRoot '.third-party'
$paddleSource = Join-Path $cacheRoot 'Paddle-3.2.2.zip'
$opencvSource = Join-Path $cacheRoot 'opencv-4.10.0.zip'
$modelRoot = 'C:\Users\jense\.paddlex\official_models'

function Test-ZipArchive([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $archive = [System.IO.Compression.ZipFile]::OpenRead($Path)
        try { return $archive.Entries.Count -gt 0 }
        finally { $archive.Dispose() }
    } catch { return $false }
}

$dependencies = @(
    [pscustomobject]@{
        id = 'paddle-inference-source'; version = '3.2.2'; license = 'Apache-2.0'
        url = 'https://github.com/PaddlePaddle/Paddle/archive/refs/tags/v3.2.2.zip'
        destination = $paddleSource
    },
    [pscustomobject]@{
        id = 'opencv-source'; version = '4.10.0'; license = 'Apache-2.0'
        url = 'https://codeload.github.com/opencv/opencv/zip/refs/tags/4.10.0'
        destination = $opencvSource
    }
)

if ($DownloadSources) {
    New-Item -ItemType Directory -Force -Path $cacheRoot | Out-Null
    foreach ($dependency in $dependencies) {
        if (-not (Test-ZipArchive $dependency.destination)) {
            Remove-Item -LiteralPath $dependency.destination -Force -ErrorAction SilentlyContinue
            $partial = "$($dependency.destination).partial"
            Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
            Invoke-WebRequest -Uri $dependency.url -OutFile $partial
            if (-not (Test-ZipArchive $partial)) { throw "downloaded archive is invalid: $($dependency.id)" }
            Move-Item -LiteralPath $partial -Destination $dependency.destination
        }
    }
}

$models = @(
    [pscustomobject]@{ id = 'ppocrv5-mobile-det'; path = Join-Path $modelRoot 'PP-OCRv5_mobile_det' },
    [pscustomobject]@{ id = 'ppocrv5-server-rec'; path = Join-Path $modelRoot 'PP-OCRv5_server_rec' }
)

$modelReport = foreach ($model in $models) {
    $program = Join-Path $model.path 'inference.json'
    $parameters = Join-Path $model.path 'inference.pdiparams'
    [pscustomobject]@{
        id = $model.id
        source = $model.path
        inference_json = Test-Path -LiteralPath $program
        inference_pdiparams = Test-Path -LiteralPath $parameters
        pdiparams_sha256 = if (Test-Path -LiteralPath $parameters) { (Get-FileHash -LiteralPath $parameters -Algorithm SHA256).Hash } else { $null }
        size_bytes = if (Test-Path -LiteralPath $parameters) { (Get-Item -LiteralPath $parameters).Length } else { 0 }
    }
}

$report = [pscustomobject]@{
    generated_utc = [DateTime]::UtcNow.ToString('o')
    platform = 'windows-x64'
    required_msvc = 'Visual Studio 2022 Build Tools x64'
    source_dependencies = foreach ($dependency in $dependencies) {
        [pscustomobject]@{
            id = $dependency.id; version = $dependency.version; license = $dependency.license
            url = $dependency.url; cached = Test-ZipArchive $dependency.destination
            sha256 = if (Test-ZipArchive $dependency.destination) { (Get-FileHash -LiteralPath $dependency.destination -Algorithm SHA256).Hash } else { $null }
            size_bytes = if (Test-ZipArchive $dependency.destination) { (Get-Item -LiteralPath $dependency.destination).Length } else { 0 }
        }
    }
    models = @($modelReport)
}

$report | ConvertTo-Json -Depth 5
