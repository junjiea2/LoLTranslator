@echo off
setlocal EnableExtensions
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

if "%CUDA_PATH%"=="" (
  echo CUDA_PATH is not set. Run the CUDA prerequisite verification first.
  exit /b 2
)
if "%CUDNN_ROOT%"=="" set "CUDNN_ROOT=%CUDA_PATH%"
if not exist "%CUDNN_ROOT%\bin\cudnn64_9.dll" (
  echo cuDNN 9 runtime DLL not found at "%CUDNN_ROOT%\bin\cudnn64_9.dll".
  exit /b 2
)

subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%stage-official-pipeline.ps1"
if errorlevel 1 exit /b %errorlevel%
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%generate-recognizer-dictionary.ps1"
if errorlevel 1 exit /b %errorlevel%

cmake -S "%SIDECAR_ROOT%sidecar" -B P:\build\sidecar-gpu -G "Visual Studio 17 2022" -A x64 ^
  -DPPOCR_REFERENCE_SOURCE=P:\PaddleOCR-cpp-infer-v2.7 ^
  -DPADDLE_SDK_DIR=P:\build\paddle-gpu\paddle_inference_install_dir ^
  -DPADDLE_BUILD_DIR=P:\build\paddle-gpu ^
  -DOpenCV_DIR=P:\install\opencv-4.10.0\x64\vc17\lib ^
  -DCUDA_RUNTIME_DIR="%CUDA_PATH%\bin" ^
  -DCUDNN_RUNTIME_DIR="%CUDNN_ROOT%\bin"

set "CONFIGURE_EXIT=%ERRORLEVEL%"
endlocal & exit /b %CONFIGURE_EXIT%
