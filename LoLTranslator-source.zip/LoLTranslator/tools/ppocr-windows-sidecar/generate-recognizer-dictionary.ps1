param(
    [string]$RecognizerModel = 'C:\Users\jense\.paddlex\official_models\PP-OCRv5_server_rec'
)

$ErrorActionPreference = 'Stop'
$configPath = Join-Path $RecognizerModel 'config.json'
$outputPath = Join-Path $PSScriptRoot '.third-party\models\PP-OCRv5_server_rec\character_dict.txt'
if (-not (Test-Path -LiteralPath $configPath)) {
    throw "Recognizer config is unavailable: $configPath"
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding utf8 | ConvertFrom-Json
$characters = @($config.PostProcess.character_dict)
if ($characters.Count -lt 1000) {
    throw 'The PP-OCRv5 recognizer character list is incomplete; refusing to generate a dictionary.'
}
New-Item -ItemType Directory -Path (Split-Path -Parent $outputPath) -Force | Out-Null
[System.IO.File]::WriteAllLines($outputPath, [string[]]$characters, [System.Text.UTF8Encoding]::new($false))
$hash = (Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash
Write-Host "Generated model-derived character dictionary ($($characters.Count) labels, SHA-256 $hash)."
