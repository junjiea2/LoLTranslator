@echo off
setlocal
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%apply-paddle-msvc-compat.ps1" -PaddleSource "P:\P"
if errorlevel 1 exit /b %errorlevel%

rem OpenBLAS' generated headers race under nested MSBuild parallelism on Windows.
rem Keep the top-level distribution build serial; Paddle still compiles its own
rem independent targets normally and this makes the SDK build reproducible.
cmake --build P:\build\paddle-cpu --config Release --target inference_lib_dist -- /m:1
set "BUILD_EXIT=%ERRORLEVEL%"
endlocal & exit /b %BUILD_EXIT%
