@echo off
setlocal
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul

cmake -S P:\opencv-4.10.0 -B P:\build\opencv-4.10.0 -G "Visual Studio 17 2022" -A x64 ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_INSTALL_PREFIX=P:\install\opencv-4.10.0 ^
  -DBUILD_LIST=core,imgproc,imgcodecs ^
  -DBUILD_SHARED_LIBS=ON ^
  -DBUILD_TESTS=OFF -DBUILD_PERF_TESTS=OFF -DBUILD_EXAMPLES=OFF ^
  -DBUILD_opencv_apps=OFF -DBUILD_JAVA=OFF -DBUILD_opencv_python3=OFF

endlocal
