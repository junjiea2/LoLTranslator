// JSON-only command adapter over PaddleOCR's official DB/CTC C++ pipeline.
// It reads transient captures and writes one JSON result per request to stdout.
// It never writes images or OCR text to disk.
#include <gflags/gflags.h>
#include <include/args.h>
#include <include/paddleocr.h>
#include <opencv2/imgcodecs.hpp>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>

using namespace PaddleOCR;

DEFINE_string(input_image, "", "Single image path supplied by the host process.");
DEFINE_bool(stdin_loop, false, "Keep models loaded and read one image path per stdin line.");
DEFINE_double(crop_x, 0.0, "Optional normalized left edge of the chat crop.");
DEFINE_double(crop_y, 0.0, "Optional normalized top edge of the chat crop.");
DEFINE_double(crop_width, 0.0, "Optional normalized width of the chat crop.");
DEFINE_double(crop_height, 0.0, "Optional normalized height of the chat crop.");

namespace {
class StdoutToStderrScope {
 public:
  StdoutToStderrScope() : original_(std::cout.rdbuf(std::cerr.rdbuf())) {}
  ~StdoutToStderrScope() { std::cout.rdbuf(original_); }

 private:
  std::streambuf* original_;
};

std::string JsonEscape(const std::string& value) {
  std::ostringstream result;
  for (unsigned char c : value) {
    switch (c) {
      case '\\': result << "\\\\"; break;
      case '"': result << "\\\""; break;
      case '\n': result << "\\n"; break;
      case '\r': result << "\\r"; break;
      case '\t': result << "\\t"; break;
      default:
        if (c < 0x20) {
          // JSON requires exactly four hexadecimal digits after \u. OCR can
          // occasionally emit a control byte for a noisy game frame; the old
          // short form (for example \u1) made the complete response invalid.
          result << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                 << static_cast<int>(c) << std::dec << std::setfill(' ');
        } else {
          result << static_cast<char>(c);
        }
    }
  }
  return result.str();
}

std::string Base64Encode(const std::string& value) {
  static constexpr char alphabet[] =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  std::string result;
  result.reserve(((value.size() + 2) / 3) * 4);
  for (size_t index = 0; index < value.size(); index += 3) {
    const unsigned int first = static_cast<unsigned char>(value[index]);
    const unsigned int second = index + 1 < value.size()
                                    ? static_cast<unsigned char>(value[index + 1])
                                    : 0;
    const unsigned int third = index + 2 < value.size()
                                   ? static_cast<unsigned char>(value[index + 2])
                                   : 0;
    const unsigned int combined = (first << 16) | (second << 8) | third;
    result.push_back(alphabet[(combined >> 18) & 0x3f]);
    result.push_back(alphabet[(combined >> 12) & 0x3f]);
    result.push_back(index + 1 < value.size() ? alphabet[(combined >> 6) & 0x3f] : '=');
    result.push_back(index + 2 < value.size() ? alphabet[combined & 0x3f] : '=');
  }
  return result;
}

void EmitError(const char* code) {
  std::cout << "{\"status\":\"error\",\"code\":\"" << code << "\",\"lines\":[]}" << std::endl;
}

void ProcessImage(const std::string& image_path, PPOCR& engine) {
  cv::Mat image = cv::imread(image_path, cv::IMREAD_COLOR);
  if (!image.data) {
    EmitError("input_image_unreadable");
    return;
  }
  if (FLAGS_crop_width > 0.0 || FLAGS_crop_height > 0.0) {
    if (FLAGS_crop_x < 0.0 || FLAGS_crop_y < 0.0 || FLAGS_crop_width <= 0.0 ||
        FLAGS_crop_height <= 0.0 || FLAGS_crop_x + FLAGS_crop_width > 1.0 ||
        FLAGS_crop_y + FLAGS_crop_height > 1.0) {
      EmitError("invalid_normalized_crop");
      return;
    }
    const int x = static_cast<int>(FLAGS_crop_x * image.cols);
    const int y = static_cast<int>(FLAGS_crop_y * image.rows);
    const int width = static_cast<int>(FLAGS_crop_width * image.cols);
    const int height = static_cast<int>(FLAGS_crop_height * image.rows);
    if (width < 1 || height < 1 || x < 0 || y < 0 || x + width > image.cols ||
        y + height > image.rows) {
      EmitError("invalid_normalized_crop");
      return;
    }
    image = image(cv::Rect(x, y, width, height)).clone();
  }

  std::vector<OCRPredictResult> results;
  {
    StdoutToStderrScope nativeDiagnostics;
    results = engine.ocr(image, true, true, false);
  }
  std::cout << "{\"status\":\"ok\",\"lines\":[";
  for (size_t index = 0; index < results.size(); ++index) {
    const OCRPredictResult& line = results[index];
    if (index != 0) std::cout << ',';
    // Keep the line protocol ASCII-only. No possible OCR byte sequence can
    // terminate a string or corrupt the JSON framing; the WPF host decodes it
    // in memory and never persists this transport representation.
    std::cout << "{\"text_base64\":\"" << Base64Encode(line.text) << "\",\"score\":";
    if (std::isfinite(line.score)) {
      std::cout << line.score;
    } else {
      // NaN and infinity are not JSON numbers. Score is diagnostic metadata;
      // keep the OCR row and emit a valid nullable value instead.
      std::cout << "null";
    }
    std::cout << ",\"box\":[";
    for (size_t point = 0; point < line.box.size(); ++point) {
      if (point != 0) std::cout << ',';
      const std::vector<int>& coordinate = line.box[point];
      std::cout << '[' << coordinate[0] << ',' << coordinate[1] << ']';
    }
    std::cout << "]}";
  }
  std::cout << "]}" << std::endl;
}
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  if ((!FLAGS_stdin_loop && FLAGS_input_image.empty()) || FLAGS_det_model_dir.empty() ||
      FLAGS_rec_model_dir.empty() || FLAGS_rec_char_dict_path.empty()) {
    EmitError("required_argument_missing");
    return 2;
  }

  try {
    // Paddle's native progress diagnostics must never corrupt the JSON protocol
    // consumed by the WPF provider.  They remain available on stderr for local
    // diagnostics and no OCR text is persisted by this adapter.
    std::unique_ptr<PPOCR> engine;
    {
      StdoutToStderrScope nativeDiagnostics;
      engine = std::make_unique<PPOCR>();
    }
    if (FLAGS_stdin_loop) {
      std::cout << "{\"status\":\"ready\"}" << std::endl;
      std::string image_path;
      while (std::getline(std::cin, image_path)) {
        if (image_path == "__quit__") break;
        if (!image_path.empty()) ProcessImage(image_path, *engine);
      }
    } else {
      ProcessImage(FLAGS_input_image, *engine);
    }
  } catch (const std::exception& exception) {
    EmitError("native_inference_exception");
    return 4;
  }
  return 0;
}
