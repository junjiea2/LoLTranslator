cmake_minimum_required(VERSION 3.24)
project(loltranslator_ppocr_v5_sidecar LANGUAGES CXX)

set(PPOCR_REFERENCE_SOURCE "" CACHE PATH "Staged official PaddleOCR C++ source")
set(PADDLE_SDK_DIR "" CACHE PATH "Paddle Inference inference_lib_dist directory")
set(PADDLE_BUILD_DIR "" CACHE PATH "Paddle build directory used only for official dirent headers")
set(CUDNN_RUNTIME_DIR "" CACHE PATH "Optional cuDNN runtime directory for GPU sidecar packaging")
set(CUDA_RUNTIME_DIR "" CACHE PATH "Optional CUDA runtime directory for GPU sidecar packaging")
set(OpenCV_DIR "" CACHE PATH "OpenCV config directory")

if(NOT EXISTS "${PPOCR_REFERENCE_SOURCE}/include/paddleocr.h")
  message(FATAL_ERROR "PPOCR_REFERENCE_SOURCE must contain staged official PaddleOCR cpp_infer source.")
endif()

if(NOT EXISTS "${PADDLE_SDK_DIR}/paddle/include/paddle_inference_api.h")
  message(FATAL_ERROR "PADDLE_SDK_DIR must be Paddle inference_lib_dist output.")
endif()
if(NOT EXISTS "${PADDLE_BUILD_DIR}/third_party/dirent/src/extern_dirent/include/dirent.h")
  message(FATAL_ERROR "PADDLE_BUILD_DIR must contain Paddle's official dirent header from this build.")
endif()

find_package(OpenCV REQUIRED CONFIG)

set(PPOCR_SOURCES
  main_json.cpp
  "${PPOCR_REFERENCE_SOURCE}/src/args.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/clipper.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/ocr_cls.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/ocr_det.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/ocr_rec.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/paddleocr.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/postprocess_op.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/preprocess_op.cpp"
  "${PPOCR_REFERENCE_SOURCE}/src/utility.cpp")

add_executable(loltranslator-ppocr-sidecar ${PPOCR_SOURCES})
target_compile_features(loltranslator-ppocr-sidecar PRIVATE cxx_std_17)
# The locally built Paddle Inference distribution is configured with
# MSVC_STATIC_CRT=ON; its static gflags dependency therefore requires /MT.
set_property(TARGET loltranslator-ppocr-sidecar PROPERTY
  MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
target_compile_definitions(loltranslator-ppocr-sidecar PRIVATE GOOGLE_GLOG_DLL_DECL=)
target_include_directories(loltranslator-ppocr-sidecar PRIVATE
  "${CMAKE_CURRENT_LIST_DIR}/compat"
  "${PPOCR_REFERENCE_SOURCE}"
  "${PADDLE_SDK_DIR}/paddle/include"
  "${PADDLE_SDK_DIR}/third_party/install/protobuf/include"
  "${PADDLE_SDK_DIR}/third_party/install/glog/include"
  "${PADDLE_SDK_DIR}/third_party/install/gflags/include"
  "${PADDLE_SDK_DIR}/third_party/install/xxhash/include"
  "${PADDLE_SDK_DIR}/third_party/install/zlib/include"
  "${PADDLE_BUILD_DIR}/third_party/dirent/src/extern_dirent/include")
target_link_directories(loltranslator-ppocr-sidecar PRIVATE
  "${PADDLE_SDK_DIR}/paddle/lib"
  "${PADDLE_SDK_DIR}/third_party/install/openblas/lib"
  "${PADDLE_SDK_DIR}/third_party/install/protobuf/lib"
  "${PADDLE_SDK_DIR}/third_party/install/glog/lib"
  "${PADDLE_SDK_DIR}/third_party/install/gflags/lib"
  "${PADDLE_SDK_DIR}/third_party/install/xxhash/lib")
target_link_libraries(loltranslator-ppocr-sidecar PRIVATE
  paddle_inference openblas glog gflags_static libprotobuf xxhash ${OpenCV_LIBS} shlwapi)

add_custom_command(TARGET loltranslator-ppocr-sidecar POST_BUILD
  COMMAND "${CMAKE_COMMAND}" -E copy_directory "${PADDLE_SDK_DIR}/paddle/lib" "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>"
  COMMAND "${CMAKE_COMMAND}" -E copy_directory "${PADDLE_SDK_DIR}/third_party/install/openblas/lib" "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>"
  # Paddle's Windows distribution import DLL references these two runtime
  # libraries from the same verified Paddle build; inference_lib_dist does not
  # currently copy them into paddle/lib.
  COMMAND "${CMAKE_COMMAND}" -E copy_if_different "${PADDLE_BUILD_DIR}/paddle/common/$<CONFIG>/common.dll" "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>"
  COMMAND "${CMAKE_COMMAND}" -E copy_if_different "${PADDLE_BUILD_DIR}/paddle/phi/$<CONFIG>/phi.dll" "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>"
  COMMAND "${CMAKE_COMMAND}" -E copy_directory "${OpenCV_DIR}/../bin" "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>")

if(CUDA_RUNTIME_DIR)
  if(NOT EXISTS "${CUDA_RUNTIME_DIR}/cublasLt64_12.dll" OR
     NOT EXISTS "${CUDA_RUNTIME_DIR}/cublas64_12.dll" OR
     NOT EXISTS "${CUDA_RUNTIME_DIR}/cudart64_12.dll")
    message(FATAL_ERROR "CUDA_RUNTIME_DIR must contain the CUDA 12 cuBLAS and runtime DLLs.")
  endif()
  file(GLOB CUDA_RUNTIME_DLLS
    "${CUDA_RUNTIME_DIR}/cublas*64_12.dll"
    "${CUDA_RUNTIME_DIR}/cudart64_12.dll")
  add_custom_command(TARGET loltranslator-ppocr-sidecar POST_BUILD
    COMMAND "${CMAKE_COMMAND}" -E copy_if_different ${CUDA_RUNTIME_DLLS} "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>")
endif()

if(CUDNN_RUNTIME_DIR)
  if(NOT EXISTS "${CUDNN_RUNTIME_DIR}/cudnn64_9.dll")
    message(FATAL_ERROR "CUDNN_RUNTIME_DIR must contain cudnn64_9.dll when specified.")
  endif()
  file(GLOB CUDNN_RUNTIME_DLLS "${CUDNN_RUNTIME_DIR}/cudnn*_9.dll")
  if(NOT CUDNN_RUNTIME_DLLS)
    message(FATAL_ERROR "CUDNN_RUNTIME_DIR does not contain the cuDNN 9 runtime DLL set.")
  endif()
  add_custom_command(TARGET loltranslator-ppocr-sidecar POST_BUILD
    COMMAND "${CMAKE_COMMAND}" -E copy_if_different ${CUDNN_RUNTIME_DLLS} "$<TARGET_FILE_DIR:loltranslator-ppocr-sidecar>")
endif()
