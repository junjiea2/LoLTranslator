#pragma once

#include <string>
#include <vector>

// PaddleOCR's optional auto-log package is only used for benchmark printing.
// The host measures timing itself, so the sidecar intentionally uses a no-op
// implementation and does not fetch a network dependency during native builds.
class AutoLogger {
 public:
  template <typename... Args>
  explicit AutoLogger(Args&&...) {}
  void report() const {}
};
