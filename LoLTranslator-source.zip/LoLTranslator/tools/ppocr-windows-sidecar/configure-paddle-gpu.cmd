@echo off
setlocal EnableExtensions
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

if "%CUDA_PATH%"=="" (
  echo CUDA_PATH is not set. Install CUDA Toolkit 12.6 and open a new terminal.
  exit /b 2
)
if not exist "%CUDA_PATH%\bin\nvcc.exe" (
  echo CUDA Toolkit compiler not found at "%CUDA_PATH%\bin\nvcc.exe".
  exit /b 2
)
if "%CUDNN_ROOT%"=="" set "CUDNN_ROOT=%CUDA_PATH%"
if not exist "%CUDNN_ROOT%\include\cudnn.h" (
  echo cuDNN header not found. Set CUDNN_ROOT to the extracted cuDNN 9.5.1 CUDA 12 directory.
  exit /b 2
)
if not exist "%CUDNN_ROOT%\lib\x64\cudnn.lib" (
  echo cuDNN import library not found at "%CUDNN_ROOT%\lib\x64\cudnn.lib".
  exit /b 2
)

rem Paddle 3.2 still uses CMake's legacy FindCUDA module on Windows. That
rem module treats backslashes in -D values as escape characters, so provide
rem CMake-style paths even though the validation above uses native paths.
set "CUDA_PATH_CMAKE=%CUDA_PATH:\=/%"
set "CUDNN_ROOT_CMAKE=%CUDNN_ROOT:\=/%"

subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul

cmake -S P:\P -B P:\build\paddle-gpu -G "Visual Studio 17 2022" -A x64 -T "cuda=%CUDA_PATH_CMAKE%" ^
  -DWITH_GPU=ON ^
  -DCUDA_TOOLKIT_ROOT_DIR="%CUDA_PATH_CMAKE%" ^
  -DCUDNN_INCLUDE_DIR="%CUDNN_ROOT_CMAKE%/include" ^
  -DCUDNN_LIBRARY="%CUDNN_ROOT_CMAKE%/lib/x64/cudnn.lib" ^
  -DCUDA_ARCH_NAME=Ampere ^
  -DWITH_TESTING=OFF ^
  -DON_INFER=ON ^
  -DWITH_INFERENCE_API_TEST=OFF ^
  -DWITH_DISTRIBUTE=OFF ^
  -DWITH_MKL=OFF ^
  -DWITH_AVX=ON ^
  -DWITH_PYTHON=OFF ^
  -DWITH_TENSORRT=OFF

set "CONFIGURE_EXIT=%ERRORLEVEL%"
endlocal & exit /b %CONFIGURE_EXIT%
