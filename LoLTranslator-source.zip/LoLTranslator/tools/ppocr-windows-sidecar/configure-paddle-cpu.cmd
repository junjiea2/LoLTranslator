@echo off
setlocal
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

rem A short drive prevents Windows path limits in Paddle's nested third-party tree.
subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul

cmake -S P:\P -B P:\build\paddle-cpu -G "Visual Studio 17 2022" -A x64 ^
  -DWITH_GPU=OFF ^
  -DWITH_TESTING=OFF ^
  -DON_INFER=ON ^
  -DWITH_INFERENCE_API_TEST=OFF ^
  -DWITH_DISTRIBUTE=OFF ^
  -DWITH_MKL=OFF ^
  -DWITH_AVX=ON ^
  -DWITH_PYTHON=OFF

endlocal
