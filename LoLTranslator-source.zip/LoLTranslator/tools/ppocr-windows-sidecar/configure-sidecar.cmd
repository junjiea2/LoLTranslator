@echo off
setlocal
set "SIDECAR_ROOT=%~dp0"
set "CACHE_ROOT=%SIDECAR_ROOT%.third-party"

subst P: "%CACHE_ROOT%" >nul 2>nul
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%stage-official-pipeline.ps1"
if errorlevel 1 exit /b %errorlevel%
powershell -NoProfile -ExecutionPolicy Bypass -File "%SIDECAR_ROOT%generate-recognizer-dictionary.ps1"
if errorlevel 1 exit /b %errorlevel%

cmake -S "%SIDECAR_ROOT%sidecar" -B P:\build\sidecar -G "Visual Studio 17 2022" -A x64 ^
  -DPPOCR_REFERENCE_SOURCE=P:\PaddleOCR-cpp-infer-v2.7 ^
  -DPADDLE_SDK_DIR=P:\build\paddle-cpu\paddle_inference_install_dir ^
  -DPADDLE_BUILD_DIR=P:\build\paddle-cpu ^
  -DOpenCV_DIR=P:\install\opencv-4.10.0\x64\vc17\lib

endlocal
