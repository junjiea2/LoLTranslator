# Official Windows C++ sidecar dependency bootstrap

This directory contains reproducible source acquisition only. Its `.third-party/`
cache and `build/` output are ignored, and neither user screenshots nor OCR output
are accepted here.

## Locked development inputs

| Dependency | Version | Official source | License | Development use |
| --- | --- | --- | --- | --- |
| Paddle Inference | 3.2.2 | `https://github.com/PaddlePaddle/Paddle/archive/refs/tags/v3.2.2.zip` | Apache-2.0 | Build a Windows x64 C++ SDK with the same major/minor runtime used by the successful benchmark. |
| OpenCV | 4.10.0 | `https://codeload.github.com/opencv/opencv/zip/refs/tags/4.10.0` | Apache-2.0 | Build the official DB post-processing/crop dependency for the sidecar. |
| PP-OCRv5 mobile detector | local official cache | `C:\Users\jense\.paddlex\official_models\PP-OCRv5_mobile_det` | Apache-2.0 | Read-only `inference.json` + `inference.pdiparams`. |
| PP-OCRv5 server recognizer | local official cache | `C:\Users\jense\.paddlex\official_models\PP-OCRv5_server_rec` | Apache-2.0 | Read-only `inference.json` + `inference.pdiparams`. |

The model cache was verified locally before this document was created. The bootstrap
script records its file hashes and refuses to claim a model is present unless both
Paddle program and parameter files exist.

The initial source archives are expected to be roughly 150–250 MiB combined; a full
Windows x64 Paddle build may download several additional gigabytes of source/build
dependencies and requires substantially more free disk. The exact final hashes and
sizes are written only after download, rather than being guessed. Downloads are
first written as `.partial` files and atomically promoted only after ZIP validation.

## Reproduction

Read-only readiness report:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\ppocr-windows-sidecar\bootstrap-dependencies.ps1
```

Fetch the two official source archives into the ignored local cache:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\ppocr-windows-sidecar\bootstrap-dependencies.ps1 -DownloadSources
```

The next step is to build Paddle Inference 3.2.2 and OpenCV 4.10.0 with the installed
Visual Studio 2022 x64 toolchain, compile the official PaddleOCR C++ pipeline against
the resulting SDKs, and run the existing six-line aggregate-only gate. Nothing is
enabled in the WPF product before that gate passes.
