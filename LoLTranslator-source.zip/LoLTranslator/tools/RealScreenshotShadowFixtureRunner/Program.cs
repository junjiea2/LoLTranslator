using System.Text.Json;
using LoLTranslator.App;
using SlangGraph.Core;

const string RcRelative = "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.2.jsonl";
const string NormalizationArtifactRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-normalization-candidate.jsonl";
const string NormalizationReviewRelative = "data/collection/lol/real-screenshot-shadow-001/run005-review-normalization.jsonl";
const string OutputRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-shadow/real-screenshot-shadow-fixture-v0.1-t0p-normalization.json";

string root = Directory.GetCurrentDirectory();
string rcPath = Path.Combine(root, RcRelative.Replace('/', Path.DirectorySeparatorChar));
string normalizationArtifactPath = Path.Combine(root, NormalizationArtifactRelative.Replace('/', Path.DirectorySeparatorChar));
string normalizationReviewPath = Path.Combine(root, NormalizationReviewRelative.Replace('/', Path.DirectorySeparatorChar));
DomainLexicon lexicon = DomainLexiconLoader.LoadJsonl(rcPath);
DomainLexiconEntry ahri = lexicon.Entries.Single(entry => entry.CanonicalId == "game.lol.lexicon:champion.ahri");
DomainLexiconEntry jinx = lexicon.Entries.Single(entry => entry.CanonicalId == "game.lol.lexicon:champion.jinx");
DomainLexiconEntry brand = lexicon.Entries.Single(entry => entry.CanonicalId == "game.lol.lexicon:champion.brand");
string ahriEnglish = ahri.Aliases.Single(alias => alias.Locale == "en-US").Surface;
string ahriChinese = ahri.Aliases.Single(alias => alias.Locale == "zh-CN").Surface;
string jinxEnglish = jinx.Aliases.Single(alias => alias.Locale == "en-US").Surface;
string brandEnglish = brand.Aliases.Single(alias => alias.Locale == "en-US").Surface;

OcrShadowSemanticService semantic = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
ShadowMatchContextOption context = new("fixture", "lol.global", "in_game_chat", new[] { "lol.global" });
IReadOnlyList<OcrShadowLineResult> fused = semantic.MatchCandidates(
[
    new OcrRecognitionResult($"00:12 [Team] (FixturePlayer): {ahriEnglish.ToLowerInvariant()} noflash\n00:20 take care, {jinxEnglish.ToLowerInvariant()}\n00:26 [Team] (FixturePlayer): {ahriChinese} is here\n00:28 {brandEnglish.ToLowerInvariant()} new logo\n00:30 {ahriEnglish}gd4éé are mid\n00:34 ordinary text", "zh-CN")
], OcrShadowSemanticService.AutoSemanticLocale, context);

var ambiguous = new OcrShadowLineResult(
    99,
    ahriEnglish + " conflicting OCR",
    Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, "en-US", 1, ahriEnglish + " conflicting OCR", "00:36") },
    new OcrFusionMetadata("ambiguous", 0.20, new[] { "fixture_conflicting_same_timestamp" }));
var normalizationPositive = FusedLine(100, $"00:40 [Team] (FixturePlayer): {ahriEnglish.ToLowerInvariant()} go t0P", "zh-CN");
var provider = new RecordingProvider();
ChampionOfficialRc2RealScreenshotShadowService service = ChampionOfficialRc2RealScreenshotShadowService.CreateExplicit(
    semantic, rcPath, provider, normalizationArtifactPath, normalizationReviewPath);
ChampionOfficialRc2RealScreenshotShadowResult result = service.Process(fused.Append(ambiguous).Append(normalizationPositive).ToArray(), context, "zh-CN");
var failureProvider = new FailureProvider();
ChampionOfficialRc2RealScreenshotShadowResult failureResult = ChampionOfficialRc2RealScreenshotShadowService
    .CreateExplicit(semantic, rcPath, failureProvider, normalizationArtifactPath, normalizationReviewPath)
    .Process(fused.Take(1).ToArray(), context, "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult formatFailureResult = ChampionOfficialRc2RealScreenshotShadowService
    .CreateExplicit(semantic, rcPath, new FormatFailureProvider(), normalizationArtifactPath, normalizationReviewPath)
    .Process(fused.Take(1).ToArray(), context, "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult prefixInjectionResult = ChampionOfficialRc2RealScreenshotShadowService
    .CreateExplicit(semantic, rcPath, new PrefixInjectingProvider(), normalizationArtifactPath, normalizationReviewPath)
    .Process(fused.Take(1).ToArray(), context, "zh-CN");
var formalTopProvider = new RecordingProvider();
ChampionOfficialRc2RealScreenshotShadowResult formalTopResult = ChampionOfficialRc2RealScreenshotShadowService
    .CreateExplicit(semantic, rcPath, formalTopProvider, normalizationArtifactPath, normalizationReviewPath)
    .Process(
        new[] { FusedLine(150, $": 29 [ Team mismatch ( {ahriChinese} ) : {ahriEnglish.ToLowerInvariant()} go top", "zh-CN") },
        context,
        "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult unavailableProviderResult = ChampionOfficialRc2RealScreenshotShadowService
    .CreateExplicit(semantic, rcPath, new OllamaUnavailableProvider(), normalizationArtifactPath, normalizationReviewPath)
    .Process(fused.Take(1).ToArray(), context, "zh-CN");

var negativeProvider = new RecordingProvider();
ChampionOfficialRc2RealScreenshotShadowService negativeService = ChampionOfficialRc2RealScreenshotShadowService.CreateExplicit(
    semantic, rcPath, negativeProvider, normalizationArtifactPath, normalizationReviewPath);
var nonLolContext = new ShadowMatchContextOption("fixture", "other.game", "in_game_chat", Array.Empty<string>());
var missingContext = new ShadowMatchContextOption("fixture", "", "in_game_chat", Array.Empty<string>());
var conflictingContext = new ShadowMatchContextOption("fixture", "lol.global", "other_channel", new[] { "lol.global" });
ChampionOfficialRc2RealScreenshotShadowResult nonLolResult = negativeService.Process(
    new[] { FusedLine(201, $"{ahriEnglish} go t0P", "en-US") }, nonLolContext, "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult missingContextResult = negativeService.Process(
    new[] { FusedLine(202, $"{ahriEnglish} go t0P", "en-US") }, missingContext, "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult negativeResult = negativeService.Process(
    new[]
    {
        FusedLine(203, "t0PPlayer", "en-US"),
        FusedLine(204, $"{ahriEnglish} go tOP", "en-US"),
        FusedLine(205, $"{ahriEnglish} go t0p", "en-US"),
        FusedLine(206, "ordinary top", "en-US"),
        FusedLine(207, "unanchored OCR noise t0P", "en-US"),
    }, context, "zh-CN");
ChampionOfficialRc2RealScreenshotShadowResult conflictingContextResult = negativeService.Process(
    new[] { FusedLine(208, $"{ahriEnglish} go t0P", "en-US") }, conflictingContext, "zh-CN");

ChampionOfficialRc2RealScreenshotShadowLine[] completed = result.Lines.Where(line => line.Status == "hybrid_completed").ToArray();
ChampionOfficialRc2RealScreenshotShadowLine normalizationLine = result.Lines.Single(line => line.LineNumber == normalizationPositive.LineNumber);
bool negativeNormalizationPassed = negativeProvider.CallCount == 0 &&
    nonLolResult.Lines.Single().Status == "shadow_context_incompatible" &&
    missingContextResult.Lines.Single().Status == "shadow_context_incompatible" &&
    conflictingContextResult.Lines.Single().Status == "shadow_context_incompatible" &&
    negativeResult.Lines.All(line => line.TypedNormalizations.Count == 0) &&
    negativeResult.Lines.Single(line => line.LineNumber == 204).Status == "normalization_requires_review" &&
    negativeResult.Lines.Single(line => line.LineNumber == 205).Status == "normalization_requires_review" &&
    negativeResult.Lines.Single(line => line.LineNumber == 207).Status == "no_official_champion_match";
ChampionOfficialRc2RealScreenshotShadowLine formalTopLine = formalTopResult.Lines.Single();
bool envelopeBoundaryPassed =
    formalTopLine.ChatPrefix is not null &&
    formalTopLine.MessageBody == $"{ahriEnglish.ToLowerInvariant()} go top" &&
    formalTopLine.ProtectedInput is not null &&
    !formalTopLine.ProtectedInput.Contains("Team mismatch", StringComparison.Ordinal) &&
    formalTopLine.ProtectedInput.Contains("[[SG_ENTITY_LOCKED_", StringComparison.Ordinal) &&
    formalTopLine.VerifiedTypedEntities?.Any(entity => entity.EntityId == "game.lol:lane.top" && entity.EntityType == "lane") == true &&
    formalTopLine.FinalOutput?.Contains(ahriChinese, StringComparison.Ordinal) == true &&
    formalTopLine.FinalOutput.Contains("\u53bb", StringComparison.Ordinal) &&
    formalTopLine.LockedRenderings.Any(rendering => rendering == "\u4e0a\u8def") &&
    !ChatMessageEnvelopeExtractor.Extract("Reminder: (not a chat envelope): keep colon").HasHighConfidencePrefix;
bool passed = result.ModelCallCount == 4 && completed.Length == 4 && provider.CallCount == 4 &&
    completed.All(line => line.ProtectedInput is not null &&
        line.ProtectedInput.Contains("[[RC_LOCKED_", StringComparison.Ordinal) &&
        !line.ProtectedInput.Contains("FixturePlayer", StringComparison.Ordinal) &&
        !line.ProtectedInput.Contains("[Team]", StringComparison.Ordinal) &&
        line.FinalOutput is not null && line.LockedRenderings.All(rendering => line.FinalOutput.Contains(rendering, StringComparison.Ordinal))) &&
    completed.Any(line => line.ChatPrefix is not null) && completed.Any(line => line.ChatPrefix is null) &&
    normalizationLine.TypedNormalizations.SingleOrDefault()?.TargetEntity == "game.lol:lane.top" &&
    normalizationLine.TypedNormalizations.SingleOrDefault()?.TargetSlot == "destination_area_lane" &&
    normalizationLine.ProtectedInput?.Contains("[[SG_ENTITY_LOCKED_", StringComparison.Ordinal) == true &&
    !normalizationLine.ProtectedInput!.Contains("t0P", StringComparison.Ordinal) &&
    normalizationLine.FinalOutput?.Contains(ahriChinese, StringComparison.Ordinal) == true &&
    normalizationLine.FinalOutput.Contains("\u53bb", StringComparison.Ordinal) &&
    normalizationLine.LockedRenderings.Any(rendering => rendering == "\u4e0a\u8def") &&
    negativeNormalizationPassed &&
    envelopeBoundaryPassed &&
    result.Lines.Count(line => line.Status == "no_official_champion_match" && line.FailureReason == "no_rc2_candidate_match_no_provider_call") >= 2 &&
    result.Lines.Single(line => line.Status == "fusion_ambiguous").FailureReason == "fusion_ambiguous_no_provider_call" &&
    result.Lines.Count(line => line.Status == "common_word_context_requires_review") == 1 &&
    result.Lines.Where(line => line.Status == "hybrid_completed").Any(line => line.CanonicalIds.Contains(ahri.CanonicalId)) &&
    result.Lines.Where(line => line.Status == "hybrid_completed").Any(line => line.CanonicalIds.Contains(jinx.CanonicalId)) &&
    failureResult.Lines.Single().Status == "hybrid_unavailable" && failureResult.Lines.Single().FinalOutput is null &&
    failureResult.Lines.Single().FailureReason == "fixture_provider_timeout" &&
    formatFailureResult.Lines.Single().Status == "hybrid_unavailable" && formatFailureResult.Lines.Single().FinalOutput is null &&
    formatFailureResult.Lines.Single().FailureReason == "fixture_format_violation" &&
    prefixInjectionResult.Lines.Single().Status == "hybrid_unavailable" && prefixInjectionResult.Lines.Single().FinalOutput is null &&
    prefixInjectionResult.Lines.Single().FailureReason == "model_added_chat_envelope" &&
    unavailableProviderResult.Lines.Single().Status == "hybrid_unavailable" &&
    unavailableProviderResult.Lines.Single().FinalOutput is null &&
    unavailableProviderResult.Lines.Single().FailureReason == "local_provider_unavailable";

string outputPath = Path.Combine(root, OutputRelative.Replace('/', Path.DirectorySeparatorChar));
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
File.WriteAllText(outputPath, JsonSerializer.Serialize(new
{
    fixture = "real_screenshot_shadow_fixture_v0.1",
    rc_sha256 = ChampionOfficialRc2RealScreenshotShadowService.ExpectedRcSha256,
    normalization_candidate_sha256 = RuntimeTypedNormalizationCandidate.ExpectedArtifactSha256,
    normalization_review_sha256 = RuntimeTypedNormalizationCandidate.ExpectedReviewSha256,
    input_mode = "synthetic_ocr_candidates_no_image",
    formal_eligibility = "not_eligible",
    player_alias_intake_loaded = false,
    rotate_concept_loaded = false,
    fused_line_count = fused.Count,
    model_call_count = result.ModelCallCount,
    provider_call_count = provider.CallCount,
    completed = completed.Length,
    no_provider_calls = result.NoProviderCallCount,
    fail_closed = result.FailClosedCount,
    failure_mode_passed = failureResult.Lines.Single().Status == "hybrid_unavailable" && failureResult.Lines.Single().FinalOutput is null,
    format_failure_passed = formatFailureResult.Lines.Single().Status == "hybrid_unavailable" && formatFailureResult.Lines.Single().FinalOutput is null,
    injected_chat_prefix_passed = prefixInjectionResult.Lines.Single().FailureReason == "model_added_chat_envelope",
    damaged_envelope_body_only_and_formal_top_passed = envelopeBoundaryPassed,
    local_provider_unavailable_passed = unavailableProviderResult.Lines.Single().FailureReason == "local_provider_unavailable",
    typed_normalization_positive_passed = normalizationLine.TypedNormalizations.Count == 1 && normalizationLine.FinalOutput?.Contains("去上路", StringComparison.Ordinal) == true,
    typed_normalization_negative_boundaries_passed = negativeNormalizationPassed,
    passed
}, new JsonSerializerOptions { WriteIndented = true }));

Console.WriteLine($"Fixture passed: {passed}; model calls: {result.ModelCallCount}; provider calls: {provider.CallCount}");
return passed ? 0 : 1;

static OcrShadowLineResult FusedLine(int lineNumber, string text, string locale) => new(
    lineNumber,
    text,
    Array.Empty<SlangGraphSemanticMatch>(),
    new[] { new OcrShadowLineSource(0, locale, 1, text, null) },
    new OcrFusionMetadata("fused", 0.95, new[] { "fixture" }));

sealed class RecordingProvider : ILocalTranslationAttemptProvider
{
    public int CallCount { get; private set; }
    public GeneralTranslationResult Translate(GeneralTranslationRequest request)
    {
        LocalTranslationAttempt attempt = TranslateWithDiagnostics(request);
        return new GeneralTranslationResult("succeeded", attempt.FinalOutput, "fixture-recording", null);
    }

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        CallCount++;
        string output = request.Text + " 已处理";
        string safeOutput = request.Text
            .Replace("go top lane", "\u53bb\u4e0a\u8def", StringComparison.Ordinal)
            .Replace("go top", "\u53bb\u4e0a\u8def", StringComparison.Ordinal)
            .Replace("go [[SG_ENTITY_LOCKED_1]]", "\u53bb [[SG_ENTITY_LOCKED_1]]", StringComparison.Ordinal) + " fixture";
        return new LocalTranslationAttempt("fixture-recording", "none", "none", "fixture-v1", request.Text, request.Text, safeOutput, safeOutput, 1, null, false);
    }
}

sealed class FailureProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) =>
        new("unavailable", null, "fixture-failure", "fixture_provider_timeout");

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request) =>
        new("fixture-failure", "none", "none", "fixture-v1", request.Text, request.Text, null, null, 1, "fixture_provider_timeout", false);
}

sealed class FormatFailureProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) =>
        new("unavailable", null, "fixture-format", "fixture_format_violation");

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request) =>
        new("fixture-format", "none", "none", "fixture-v1", request.Text, request.Text, null, null, 1, "fixture_format_violation", false);
}

sealed class OllamaUnavailableProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request) =>
        new("unavailable", null, "fixture-ollama", "ollama_local_provider_error:HttpRequestException");

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request) =>
        new("fixture-ollama", "qwen3:8b", ControlledShadowQwen3Profile.ExpectedDigest, "fixture-v1", request.Text, request.Text, null, null, 1,
            "ollama_local_provider_error:HttpRequestException", false);
}

sealed class PrefixInjectingProvider : ILocalTranslationAttemptProvider
{
    public GeneralTranslationResult Translate(GeneralTranslationRequest request)
    {
        LocalTranslationAttempt attempt = TranslateWithDiagnostics(request);
        return new GeneralTranslationResult("succeeded", attempt.FinalOutput, "fixture-prefix", null);
    }

    public LocalTranslationAttempt TranslateWithDiagnostics(GeneralTranslationRequest request)
    {
        string output = "00:12 [Team] (Injected): " + request.Text + " 已处理";
        return new LocalTranslationAttempt("fixture-prefix", "none", "none", "fixture-v1", request.Text, request.Text, output, output, 1, null, false);
    }
}
