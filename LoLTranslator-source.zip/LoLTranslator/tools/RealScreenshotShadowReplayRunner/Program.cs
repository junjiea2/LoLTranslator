using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using LoLTranslator.App;
using SlangGraph.Core;

const string RcRelative = "data/packs/lol/domain-lexicon.v0.1.champion-official.rc.2.jsonl";
const string NormalizationArtifactRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-normalization-candidate.jsonl";
const string NormalizationReviewRelative = "data/collection/lol/real-screenshot-shadow-001/run005-review-normalization.jsonl";
const string OutputRelative = "data/collection/lol/real-screenshot-shadow-001/runtime-shadow/run006-local-replay-content-free.json";

string root = Directory.GetCurrentDirectory();
string logPath = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
    "LoLTranslator",
    "real-screenshot-shadow.v0.1.jsonl");
if (!File.Exists(logPath)) throw new FileNotFoundException("Local Shadow log is required for replay.", logPath);

string latestJson = File.ReadLines(logPath).LastOrDefault(line => !string.IsNullOrWhiteSpace(line))
    ?? throw new InvalidDataException("Local Shadow log has no records.");
using JsonDocument sourceDocument = JsonDocument.Parse(latestJson);
JsonElement rootRecord = sourceDocument.RootElement;
if (Text(rootRecord, "record_origin") != "real_screenshot_shadow_local_only" ||
    Text(rootRecord, "formal_eligibility") != "not_eligible" ||
    rootRecord.GetProperty("screenshot_in_log").GetBoolean() ||
    rootRecord.GetProperty("screenshot_written_to_dataset").GetBoolean())
{
    throw new InvalidDataException("Replay source is not an eligible local-only Shadow record.");
}

JsonElement[] sourceLines = rootRecord.GetProperty("lines").EnumerateArray().ToArray();
JsonElement[] targetLines = sourceLines.Where(line =>
    TextArray(line, "canonical_ids").Count > 0 &&
    !string.Equals(Text(line, "fusion_status"), "ambiguous", StringComparison.OrdinalIgnoreCase)).ToArray();
if (targetLines.Length != 1) throw new InvalidDataException("Replay requires exactly one reliable locked-entity source line.");

JsonElement sourceLine = targetLines[0];
string sourceText = Text(sourceLine, "ocr_text") ?? throw new InvalidDataException("Replay source text is absent.");
int lineNumber = sourceLine.GetProperty("line_number").GetInt32();
string targetLocale = Text(rootRecord, "target_locale") ?? "zh-CN";
string fusionStatus = Text(sourceLine, "fusion_status") ?? throw new InvalidDataException("Replay fusion status is absent.");
double fusionConfidence = sourceLine.GetProperty("fusion_confidence").GetDouble();
IReadOnlyList<string> fusionReasons = TextArray(sourceLine, "fusion_reasons");
IReadOnlyList<string> locales = TextArray(sourceLine, "ocr_locales");
if (locales.Count == 0) throw new InvalidDataException("Replay source locales are absent.");

var replayLine = new OcrShadowLineResult(
    lineNumber,
    sourceText,
    Array.Empty<SlangGraphSemanticMatch>(),
    locales.Select((locale, index) => new OcrShadowLineSource(index, locale, lineNumber, sourceText, null)).ToArray(),
    new OcrFusionMetadata(fusionStatus, fusionConfidence, fusionReasons));
var context = new ShadowMatchContextOption("run006 local replay", "lol.global", "in_game_chat", new[] { "lol.global" });
OcrShadowSemanticService semantic = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
ChampionOfficialRc2RealScreenshotShadowService shadow = ChampionOfficialRc2RealScreenshotShadowService.CreateExplicit(
    semantic,
    Path.Combine(root, RcRelative.Replace('/', Path.DirectorySeparatorChar)),
    provider: null,
    Path.Combine(root, NormalizationArtifactRelative.Replace('/', Path.DirectorySeparatorChar)),
    Path.Combine(root, NormalizationReviewRelative.Replace('/', Path.DirectorySeparatorChar)));
ChampionOfficialRc2RealScreenshotShadowResult replay = shadow.Process(new[] { replayLine }, context, targetLocale);
ChampionOfficialRc2RealScreenshotShadowLine outcome = replay.Lines.Single();

bool bodyOnlyInput = outcome.ChatPrefix is not null &&
    (outcome.ProtectedInput is null || !outcome.ProtectedInput.Contains(outcome.ChatPrefix, StringComparison.Ordinal));
bool lockedRenderingPreserved = outcome.FinalOutput is not null &&
    outcome.LockedRenderings.All(rendering => outcome.FinalOutput.Contains(rendering, StringComparison.Ordinal));
bool noOutputEnvelope = outcome.FinalOutput is null || !ChatMessageEnvelopeExtractor.Extract(outcome.FinalOutput).HasHighConfidencePrefix;
bool topLaneObserved = outcome.FinalOutput?.Contains("\u4e0a\u8def", StringComparison.Ordinal) == true;
bool translationQualityReviewRequired = outcome.FinalOutput is not null && !topLaneObserved;

string localReviewPath = Path.Combine(
    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
    "LoLTranslator",
    "real-screenshot-shadow-replay.v0.1.jsonl");
Directory.CreateDirectory(Path.GetDirectoryName(localReviewPath)!);
var localReview = new
{
    record_type = "real_screenshot_shadow_run006_local_replay_review/0.1",
    recorded_at = DateTimeOffset.UtcNow,
    record_origin = "real_screenshot_shadow_local_replay",
    formal_eligibility = "not_eligible",
    intake_status = "local_review_only_not_for_data_import",
    redaction_status = "runtime_body_only_not_export_ready",
    screenshot_in_log = false,
    screenshot_written_to_dataset = false,
    source_log_sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(logPath))),
    source_record_ordinal_from_end = 1,
    source_line_number = lineNumber,
    model_digest = ControlledShadowQwen3Profile.ExpectedDigest,
    status = outcome.Status,
    failure_reason = outcome.FailureReason,
    canonical_ids = outcome.CanonicalIds,
    typed_normalization_targets = outcome.TypedNormalizations.Select(item => item.TargetEntity),
    verified_typed_entity_ids = (outcome.VerifiedTypedEntities ?? Array.Empty<SlangGraphEntityResolution>()).Select(item => item.EntityId),
    provider_input = outcome.ProtectedInput,
    raw_provider_output = outcome.RawProviderOutput,
    final_output = outcome.FinalOutput,
    target_zh_top_lane_semantics_observed = topLaneObserved,
    translation_quality_review_required = translationQualityReviewRequired,
    elapsed_milliseconds = outcome.ElapsedMilliseconds
};
File.AppendAllText(localReviewPath, JsonSerializer.Serialize(localReview) + Environment.NewLine);

string outputPath = Path.Combine(root, OutputRelative.Replace('/', Path.DirectorySeparatorChar));
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
var report = new
{
    report_type = "real_screenshot_shadow_run006_local_replay_content_free/0.1",
    record_origin = "real_screenshot_shadow_local_replay",
    formal_eligibility = "not_eligible",
    intake_status = "local_diagnostic_only_not_for_data_import",
    source_log_sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(logPath))),
    source_record_ordinal_from_end = 1,
    screenshot_read = false,
    screenshot_written_to_dataset = false,
    source_text_sha256 = Hash(sourceText),
    fusion_status = fusionStatus,
    fusion_confidence = fusionConfidence,
    chat_envelope_detected = outcome.ChatPrefix is not null,
    body_only_provider_input = bodyOnlyInput,
    status = outcome.Status,
    failure_reason = outcome.FailureReason,
    model_call_count = replay.ModelCallCount,
    model_digest = ControlledShadowQwen3Profile.ExpectedDigest,
    canonical_ids = outcome.CanonicalIds,
    typed_normalization_targets = outcome.TypedNormalizations.Select(item => item.TargetEntity),
    verified_typed_entity_ids = (outcome.VerifiedTypedEntities ?? Array.Empty<SlangGraphEntityResolution>()).Select(item => item.EntityId),
    final_output_present = outcome.FinalOutput is not null,
    final_output_sha256 = outcome.FinalOutput is null ? null : Hash(outcome.FinalOutput),
    locked_rendering_preserved = lockedRenderingPreserved,
    output_has_chat_envelope = !noOutputEnvelope,
    target_zh_top_lane_semantics_observed = topLaneObserved,
    translation_quality_review_required = translationQualityReviewRequired,
    local_review_output_retained = true,
    elapsed_milliseconds = outcome.ElapsedMilliseconds
};
File.WriteAllText(outputPath, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));

Console.WriteLine($"Replay status: {outcome.Status}; model calls: {replay.ModelCallCount}; body-only: {bodyOnlyInput}; top-lane semantics: {topLaneObserved}; report: {outputPath}");
return outcome.Status == "hybrid_completed" && bodyOnlyInput && lockedRenderingPreserved && noOutputEnvelope ? 0 : 1;

static string? Text(JsonElement element, string property) =>
    element.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.String ? value.GetString() : null;

static IReadOnlyList<string> TextArray(JsonElement element, string property) =>
    element.TryGetProperty(property, out JsonElement value) && value.ValueKind == JsonValueKind.Array
        ? value.EnumerateArray().Where(item => item.ValueKind == JsonValueKind.String).Select(item => item.GetString()!).ToArray()
        : Array.Empty<string>();

static string Hash(string text) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
