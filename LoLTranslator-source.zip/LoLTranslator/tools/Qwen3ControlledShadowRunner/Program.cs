using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using LoLTranslator.App;

const string InputRelativePath = "data/collection/lol/synthetic-chat-v0.1/drafts/synthetic-chat-evaluation.v0.2-rc.1.jsonl";
const string OutputRelativePath = "data/collection/lol/synthetic-chat-v0.1/runs/qwen3-controlled-shadow-e2e-v0.1";
const string ExpectedInputHash = "73A2FAFBF53ECEFD2644653824494FC3B2B3830CDF87B7320328939F92F15A17";

if (args.Length != 1 || args[0] != "--enable-qwen3-controlled-shadow")
{
    throw new ArgumentException("Explicit opt-in required: --enable-qwen3-controlled-shadow");
}

string root = Directory.GetCurrentDirectory();
string inputPath = Path.Combine(root, InputRelativePath.Replace('/', Path.DirectorySeparatorChar));
string outputDirectory = Path.Combine(root, OutputRelativePath.Replace('/', Path.DirectorySeparatorChar));
if (!string.Equals(ComputeSha256(inputPath), ExpectedInputHash, StringComparison.OrdinalIgnoreCase))
{
    throw new InvalidDataException("Frozen v0.2-rc.1 input hash mismatch.");
}

var json = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true,
    PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = false
};
EvaluationCase[] cases = File.ReadLines(inputPath)
    .Where(line => !string.IsNullOrWhiteSpace(line))
    .Select(line => JsonSerializer.Deserialize<EvaluationCase>(line, json) ?? throw new InvalidDataException("Invalid evaluation JSONL."))
    .ToArray();
ValidateCases(cases);

ControlledShadowQwen3Profile profile = ControlledShadowQwen3Profile.ExplicitTestOnly();
ControlledShadowRuntimeDependencies dependencies = ControlledShadowQwen3RuntimeFactory.Create(profile);
if (!dependencies.IsEnabled)
{
    throw new InvalidOperationException("Explicit controlled-shadow profile unexpectedly disabled.");
}

var provider = (OllamaLocalTranslationProvider)dependencies.GeneralTranslationProvider;
var aggregator = (ProtectedHybridTranslationAggregator)dependencies.HybridTranslationAggregator;
var semanticService = OcrShadowSemanticService.LoadFromApplicationDirectory(AppContext.BaseDirectory);
var orchestrator = new ChatProcessingRouteOrchestrator(
    semanticService,
    dependencies.GeneralTranslationProvider,
    dependencies.HybridTranslationAggregator);
var logs = new List<ControlledShadowLog>();
int invocationOrdinal = 0;
long? vramBytesAfterColdStart = null;

foreach (EvaluationCase item in cases)
{
    ShadowMatchContextOption context = ContextFor(item.Channel);
    IReadOnlyList<OcrRecognitionResult> candidates = new[] { new OcrRecognitionResult(item.RawText, "synthetic-direct") };
    IReadOnlyList<OcrShadowLineResult> fused = semanticService.MatchCandidates(
        candidates,
        OcrShadowSemanticService.AutoSemanticLocale,
        context);
    if (fused.Count != 1)
    {
        logs.Add(ControlledShadowLog.BlockedSynthetic(item, candidates, "synthetic_ocr_line_boundary_unexpected"));
        continue;
    }

    logs.Add(ProcessLine(
        "synthetic_route_v0.2-rc.1",
        item.CaseId,
        item.RawText,
        candidates,
        fused[0],
        item.SourceLocale,
        item.TargetLocale,
        context,
        new ChatProcessingPolicy(
            item.EvaluationAxes.ProcessingRoute,
            new ChatSemanticPolicy(
                item.EvaluationAxes.SemanticExpectation.Mode,
                item.EvaluationAxes.SemanticExpectation.ConceptIds ?? Array.Empty<string>(),
                item.EvaluationAxes.SemanticExpectation.ForbiddenConceptIds ?? Array.Empty<string>())),
        item.RecordOrigin,
        item.FormalEligibility,
        semanticService,
        orchestrator,
        provider,
        aggregator,
        ref invocationOrdinal,
        ref vramBytesAfterColdStart));
}

foreach (OcrFixture fixture in BuildOcrFixtures())
{
    IReadOnlyList<OcrShadowLineResult> fused = semanticService.MatchCandidates(
        fixture.Candidates,
        OcrShadowSemanticService.AutoSemanticLocale,
        fixture.Context);
    foreach (OcrShadowLineResult line in fused)
    {
        logs.Add(ProcessLine(
            "ocr_fixture",
            fixture.Id + ".line-" + line.LineNumber,
            line.Text,
            fixture.Candidates,
            line,
            "en-US",
            "zh-CN",
            fixture.Context,
            policy: null,
            "synthetic_fixture",
            "not_eligible",
            semanticService,
            orchestrator,
            provider,
            aggregator,
            ref invocationOrdinal,
            ref vramBytesAfterColdStart));
    }
}

ValidateLogs(logs);
Directory.CreateDirectory(outputDirectory);
string logPath = Path.Combine(outputDirectory, "qwen3-controlled-shadow-e2e.jsonl");
string reportPath = Path.Combine(outputDirectory, "qwen3-controlled-shadow-e2e-report.md");
File.WriteAllLines(logPath, logs.Select(log => JsonSerializer.Serialize(log, json)), new UTF8Encoding(false));
File.WriteAllText(reportPath, BuildReport(profile, logs, vramBytesAfterColdStart), new UTF8Encoding(false));

Console.WriteLine($"Controlled shadow complete: {logs.Count} audit records, Qwen calls {invocationOrdinal}.");
Console.WriteLine(logPath);
Console.WriteLine(reportPath);

static ControlledShadowLog ProcessLine(
    string sourceKind,
    string caseId,
    string originalInput,
    IReadOnlyList<OcrRecognitionResult> ocrCandidates,
    OcrShadowLineResult fused,
    string sourceLocale,
    string targetLocale,
    ShadowMatchContextOption context,
    ChatProcessingPolicy? policy,
    string recordOrigin,
    string formalEligibility,
    OcrShadowSemanticService semanticService,
    ChatProcessingRouteOrchestrator orchestrator,
    OllamaLocalTranslationProvider provider,
    ProtectedHybridTranslationAggregator aggregator,
    ref int invocationOrdinal,
    ref long? vramBytesAfterColdStart)
{
    if (fused.Fusion.IsAmbiguous)
    {
        return new ControlledShadowLog(
            "controlled_shadow_audit_log",
            "qwen3-controlled-shadow/0.1",
            sourceKind,
            caseId,
            originalInput,
            ocrCandidates,
            fused.Text,
            fused.Sources,
            fused.Fusion,
            ChatProcessingRoutes.HumanReview,
            ChatProcessingRoutes.HumanReview,
            "fusion_ambiguous",
            false,
            null,
            null,
            null,
            null,
            null,
            null,
            Array.Empty<string>(),
            Array.Empty<string>(),
            null,
            "fusion_ambiguous:" + string.Join(',', fused.Fusion.Reasons),
            recordOrigin,
            formalEligibility,
            "synthetic_controlled_shadow_only_not_observation_evidence_or_batch_003_count");
    }

    ChatProcessingResult result = orchestrator.Process(new ChatProcessingRequest(
        fused.Text,
        sourceLocale,
        targetLocale,
        context,
        policy));
    bool modelCalled = result.ProcessingRoute is ChatProcessingRoutes.GeneralTranslation or ChatProcessingRoutes.Hybrid;
    LocalTranslationAttempt? attempt = result.ProcessingRoute == ChatProcessingRoutes.Hybrid
        ? aggregator.LastAttempt
        : result.ProcessingRoute == ChatProcessingRoutes.GeneralTranslation
            ? provider.LastAttempt
            : null;
    int? ordinal = null;
    if (modelCalled && attempt is not null)
    {
        ordinal = ++invocationOrdinal;
        if (ordinal == 1)
        {
            vramBytesAfterColdStart = QueryQwenVramBytes();
        }
    }

    string? failClosedReason = result.HumanReview.RequiresReview
        ? result.HumanReview.Reason
        : result.Status == "hybrid_unavailable"
            ? result.HybridAggregation?.FailureReason
            : result.Status == "general_translation_unavailable"
                ? result.GeneralTranslation?.FailureReason
                : null;
    return new ControlledShadowLog(
        "controlled_shadow_audit_log",
        "qwen3-controlled-shadow/0.1",
        sourceKind,
        caseId,
        originalInput,
        ocrCandidates,
        fused.Text,
        fused.Sources,
        fused.Fusion,
        policy?.ProcessingRoute,
        result.ProcessingRoute,
        result.Status,
        modelCalled,
        ordinal,
        ModelProfile: ControlledShadowQwen3Profile.CandidateProfileId,
        ModelDigest: ControlledShadowQwen3Profile.ExpectedDigest,
        ModelInput: result.ProcessingRoute == ChatProcessingRoutes.Hybrid ? aggregator.LastProtectedInput : attempt?.Input,
        RawModelOutput: attempt?.RawOutput,
        ElapsedMilliseconds: attempt?.ElapsedMilliseconds,
        LockedConceptIds: result.SemanticMatches.Select(match => match.ConceptId).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
        LockedRenderings: result.SemanticRenderings.Select(rendering => rendering.Text).ToArray(),
        FinalShadowOutput: result.OutputText,
        FailClosedReason: failClosedReason,
        RecordOrigin: recordOrigin,
        FormalEligibility: formalEligibility,
        DataBoundary: "synthetic_controlled_shadow_only_not_observation_evidence_or_batch_003_count");
}

static void ValidateCases(IReadOnlyList<EvaluationCase> cases)
{
    if (cases.Count != 150 || cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.GeneralTranslation) != 70 ||
        cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.Hybrid) != 39 ||
        cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.HumanReview) != 31 ||
        cases.Count(item => item.EvaluationAxes.ProcessingRoute == ChatProcessingRoutes.SemanticRendering) != 10)
    {
        throw new InvalidDataException("Controlled shadow needs the frozen 150-case route baseline.");
    }

    if (cases.Any(item => item.RecordOrigin != "synthetic_generation" || item.FormalEligibility != "not_eligible"))
    {
        throw new InvalidDataException("Synthetic data boundary changed.");
    }
}

static void ValidateLogs(IReadOnlyList<ControlledShadowLog> logs)
{
    ControlledShadowLog[] synthetic = logs.Where(log => log.SourceKind == "synthetic_route_v0.2-rc.1").ToArray();
    if (synthetic.Length != 150)
    {
        throw new InvalidDataException($"Expected 150 synthetic audit logs; got {synthetic.Length}.");
    }

    if (synthetic.Count(log => log.ModelCalled) != 109 ||
        synthetic.Count(log => log.ExpectedRoute == ChatProcessingRoutes.HumanReview && log.ModelCalled) != 0 ||
        synthetic.Count(log => log.ExpectedRoute == ChatProcessingRoutes.SemanticRendering && log.ModelCalled) != 0)
    {
        throw new InvalidDataException("Controlled shadow model-call boundary violated.");
    }

    if (synthetic.Any(log => log.ModelCalled && log.ModelProfile != ControlledShadowQwen3Profile.CandidateProfileId) ||
        synthetic.Any(log => log.ModelCalled && log.ModelDigest != ControlledShadowQwen3Profile.ExpectedDigest))
    {
        throw new InvalidDataException("Controlled shadow called an unexpected model profile.");
    }

    if (synthetic.Any(log => log.FailClosedReason is not null && log.FinalShadowOutput is not null))
    {
        throw new InvalidDataException("A fail-closed case exposed final translation text.");
    }
}

static long? QueryQwenVramBytes()
{
    try
    {
        using var client = new HttpClient { BaseAddress = new Uri("http://127.0.0.1:11434/"), Timeout = TimeSpan.FromSeconds(5) };
        using JsonDocument document = JsonDocument.Parse(client.GetStringAsync("api/ps").GetAwaiter().GetResult());
        foreach (JsonElement model in document.RootElement.GetProperty("models").EnumerateArray())
        {
            if (model.TryGetProperty("digest", out JsonElement digest) &&
                digest.GetString() == ControlledShadowQwen3Profile.ExpectedDigest &&
                model.TryGetProperty("size_vram", out JsonElement vram))
            {
                return vram.GetInt64();
            }
        }
    }
    catch
    {
        // This field is observability only; unavailable telemetry never changes
        // a translation result or allows an alternate provider.
    }

    return null;
}

static ShadowMatchContextOption ContextFor(string channel) => channel == "team"
    ? new ShadowMatchContextOption("Synthetic team chat", "lol.global", "in_game_chat", new[] { "lol.global", "lol.eu_or_global" })
    : new ShadowMatchContextOption("Synthetic non-in-game chat", "lol.global", channel);

static IReadOnlyList<OcrFixture> BuildOcrFixtures() => new[]
{
    new OcrFixture(
        "normal_fusion",
        new[] { new OcrRecognitionResult("00:22 top care", "en-US"), new OcrRecognitionResult("00:22 top care", "fr-FR") },
        ContextFor("team")),
    new OcrFixture(
        "same_timestamp_conflict",
        new[] { new OcrRecognitionResult("00:55 top care", "en-US"), new OcrRecognitionResult("00:55 rotate dragon", "fr-FR") },
        ContextFor("team")),
    new OcrFixture(
        "unanchored_boundary",
        new[] { new OcrRecognitionResult("top care", "en-US"), new OcrRecognitionResult("need mid gank", "fr-FR") },
        ContextFor("team")),
    new OcrFixture(
        "repeated_timestamp_message",
        new[] { new OcrRecognitionResult("00:10 no f\n00:20 no f", "en-US"), new OcrRecognitionResult("00:10 no f\n00:20 no f", "fr-FR") },
        ContextFor("team"))
};

static string BuildReport(ControlledShadowQwen3Profile profile, IReadOnlyList<ControlledShadowLog> logs, long? vramBytes)
{
    ControlledShadowLog[] synthetic = logs.Where(log => log.SourceKind == "synthetic_route_v0.2-rc.1").ToArray();
    long[] modelLatencies = synthetic.Where(log => log.ModelCalled && log.ElapsedMilliseconds is not null).Select(log => log.ElapsedMilliseconds!.Value).ToArray();
    long? Percentile(IEnumerable<long> values, double percentile)
    {
        long[] ordered = values.Order().ToArray();
        return ordered.Length == 0 ? null : ordered[(int)Math.Ceiling(ordered.Length * percentile) - 1];
    }

    long? cold = modelLatencies.FirstOrDefault();
    long[] hot = modelLatencies.Skip(1).ToArray();
    var report = new StringBuilder();
    report.AppendLine("# Qwen3 controlled-shadow end-to-end acceptance preparation");
    report.AppendLine();
    report.AppendLine("Gate: ready_for_user_shadow_test (controlled-shadow candidate only; not production default).");
    report.AppendLine();
    report.AppendLine("## Explicit activation");
    report.AppendLine();
    report.AppendLine($"- Activation: `{profile.Activation}`");
    report.AppendLine($"- Profile: `{profile.Profile.ProfileId}`");
    report.AppendLine($"- Tag/digest: `{profile.Profile.ModelTag}` / `{profile.Profile.ModelDigest}`");
    report.AppendLine("- No TranslateGemma or other automatic fallback exists.");
    report.AppendLine();
    report.AppendLine("## End-to-end coverage");
    report.AppendLine();
    report.AppendLine($"- Synthetic route logs: {synthetic.Length}/150; general=70, hybrid=39, human_review=31, semantic_only=10.");
    report.AppendLine($"- Qwen calls: {synthetic.Count(log => log.ModelCalled)}/109 allowed inputs.");
    report.AppendLine($"- Human-review model calls: {synthetic.Count(log => log.ExpectedRoute == ChatProcessingRoutes.HumanReview && log.ModelCalled)}.");
    report.AppendLine($"- Semantic-only model calls: {synthetic.Count(log => log.ExpectedRoute == ChatProcessingRoutes.SemanticRendering && log.ModelCalled)}.");
    report.AppendLine($"- OCR fixture logs: {logs.Count(log => log.SourceKind == "ocr_fixture")}; fusion ambiguity rows are review-only and do not call Qwen.");
    report.AppendLine();
    report.AppendLine("## Runtime observations");
    report.AppendLine();
    report.AppendLine("| Measure | Value |");
    report.AppendLine("| --- | ---: |");
    report.AppendLine($"| Cold-start first model call | {cold} ms |");
    report.AppendLine($"| Hot P50 | {Percentile(hot, 0.50)} ms |");
    report.AppendLine($"| Hot P95 | {Percentile(hot, 0.95)} ms |");
    report.AppendLine($"| Qwen VRAM after cold start | {vramBytes} bytes |");
    report.AppendLine($"| Fail-closed rows | {logs.Count(log => log.FailClosedReason is not null)} |");
    report.AppendLine();
    report.AppendLine("All logs are synthetic/controlled-shadow artifacts and must not be imported as Observation, Evidence, Review or a batch count.");
    return report.ToString();
}

static string ComputeSha256(string path)
{
    using FileStream stream = File.OpenRead(path);
    return Convert.ToHexString(SHA256.HashData(stream));
}

public sealed record OcrFixture(string Id, IReadOnlyList<OcrRecognitionResult> Candidates, ShadowMatchContextOption Context);

public sealed record EvaluationCase(
    [property: JsonPropertyName("case_id")] string CaseId,
    [property: JsonPropertyName("channel")] string Channel,
    [property: JsonPropertyName("source_locale")] string SourceLocale,
    [property: JsonPropertyName("raw_text")] string RawText,
    [property: JsonPropertyName("target_locale")] string TargetLocale,
    [property: JsonPropertyName("record_origin")] string RecordOrigin,
    [property: JsonPropertyName("formal_eligibility")] string FormalEligibility,
    [property: JsonPropertyName("evaluation_axes")] EvaluationAxes EvaluationAxes);

public sealed record EvaluationAxes(
    [property: JsonPropertyName("processing_route")] string ProcessingRoute,
    [property: JsonPropertyName("semantic_expectation")] SemanticExpectation SemanticExpectation);

public sealed record SemanticExpectation(
    [property: JsonPropertyName("mode")] string Mode,
    [property: JsonPropertyName("concept_ids")] IReadOnlyList<string>? ConceptIds,
    [property: JsonPropertyName("forbidden_concept_ids")] IReadOnlyList<string>? ForbiddenConceptIds);

public sealed record ControlledShadowLog(
    string RecordType,
    string SchemaVersion,
    string SourceKind,
    string CaseId,
    string OriginalInput,
    IReadOnlyList<OcrRecognitionResult> OcrCandidates,
    string FusedInput,
    IReadOnlyList<OcrShadowLineSource> OcrSources,
    OcrFusionMetadata Fusion,
    string? ExpectedRoute,
    string ActualRoute,
    string RuntimeStatus,
    bool ModelCalled,
    int? ModelInvocationOrdinal,
    string? ModelProfile,
    string? ModelDigest,
    string? ModelInput,
    string? RawModelOutput,
    long? ElapsedMilliseconds,
    IReadOnlyList<string> LockedConceptIds,
    IReadOnlyList<string> LockedRenderings,
    string? FinalShadowOutput,
    string? FailClosedReason,
    string RecordOrigin,
    string FormalEligibility,
    string DataBoundary)
{
    public static ControlledShadowLog BlockedSynthetic(
        EvaluationCase item,
        IReadOnlyList<OcrRecognitionResult> candidates,
        string reason) => new(
            "controlled_shadow_audit_log", "qwen3-controlled-shadow/0.1", "synthetic_route_v0.2-rc.1", item.CaseId,
            item.RawText, candidates, item.RawText, Array.Empty<OcrShadowLineSource>(),
            new OcrFusionMetadata("ambiguous", 0, new[] { reason }), item.EvaluationAxes.ProcessingRoute,
            ChatProcessingRoutes.HumanReview, reason, false, null, null, null, null, null, null,
            Array.Empty<string>(), Array.Empty<string>(), null, reason, item.RecordOrigin, item.FormalEligibility,
            "synthetic_controlled_shadow_only_not_observation_evidence_or_batch_003_count");
}
