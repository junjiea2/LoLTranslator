# OCR 文本收件箱协议

此目录是 OCR 软件层交给数据层的唯一文本入口。OCR 层只写原始识别文本和最少元数据；数据层负责后续候选匹配、人工标注和复核。

## 文件格式

使用 JSONL，一行一条 `OcrTextInboxRecord`：

- `inbox_id`：不可复用的收件编号。
- `capture_reference`：匿名截图/会话引用，不使用本机绝对路径。
- `captured_at`：采集时间。
- `raw_text`：OCR 原文，不要先改写或翻译。
- `source_language_tag`：OCR 使用或推测的语言标记，例如 `zh-CN`、`en-US`、`ko-KR`。
- `redaction_status`：`redacted`、`unknown` 或 `contains_identifiers`。
- `intake_status`：`new`、`queued` 或 `rejected`。
- `source_ids`：必须指向主数据集中的来源记录。

## 必须遵守

1. 只有 `redaction_status: redacted` 的记录可以转换为人工标注候选。
2. 不写入玩家 ID、召唤师名称、聊天完整上下文或截图绝对路径。
3. 不从收件箱自动生成 `verified` 表达或模板。
4. OCR 软件层不读取或修改主黑话词典；双方通过这个稳定格式协作。

## 数据层后续流程

```text
OCR 原文 -> redacted/new 收件记录 -> ChatAnnotationCandidate
        -> ChatSemanticSuggestion（只读建议） -> 人工填写 Annotation labels
        -> 人工复核 -> verified 数据
```

`ChatSemanticSuggestion` 可以使用 `draft` 词典辅助审核，但其 `RequiresHumanReview` 恒为 `true`。它不等同于标签、翻译结果或已确认黑话。

`ocr-text-inbox.example.jsonl` 是合成示例，不是真实局内截图导出。

## Shadow/runtime 反馈

应用的“保存运行反馈”功能使用单独的本机文件：`%LOCALAPPDATA%\\LoLTranslator\\shadow-runtime-feedback.v0.1.jsonl`。该文件记录 OCR 候选、shadow 上下文、Pack SHA-256、匹配摘要和用户选择的反馈类别，便于数据方向筛选运行中的未识别文本、误匹配、slot 缺失、上下文缺失与 OCR 表面变体。

它不直接符合本目录 `OcrTextInboxRecord` 的来源引用要求，也不是可加载的主数据收件箱。导入数据方向前必须：脱敏、补充可审计的 capture/source reference、拆分为合适的原始文本单元，并作为新的独立 batch 建立 Evidence 与 append-only Review。绝不能把它直接升级为 `verified` 或回写 `0.3.0`。
